/*
Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE
www.jaorsoftware.cu.cc

Clase 31- Árboles Binarios de Búsqueda.

Uno de los más importantes uso de los Árboles Binarios
es para realizar Búsquedas de Datos.

Los Árboles Binarios de Búsqueda, son aquellos que no
tienen elementos repetidos; y que respetan el criterio
numérico ya planteado anteriormente; en el cual,
los hijos derechos tienen un valor mayor que su Nodo Padre;
y los hijos izquierdos, tienen un valor menor que su Padre.

Un Árbol Binario de Búsqueda es una Estructura sobre la cual se
pueden realizar eficientemente las operaciones de Búsqueda, Inserción y
Eliminación.

La definición formal de un Árbol de Búsqueda Binario es la siguiente:

“Para todo nodo T del árbol debe cumplirse que todos los valores de los
nodos del subárbol izquierdo de T deben ser menores al valor del nodo T.
De forma similar, todos los valores de los nodos del subárbol derecho de T
deben ser mayores al valor de nodo T”.

             10                         Nivel 0
        2          14                   Nivel 1
   -2      5            27              Nivel 2
     -9       9      25    31           Nivel 3
                  19          39        Nivel 4
               18               49      Nivel 5
            17                     59   Nivel 6
         16                             Nivel 7

Si observamos en nuestro árbol de ejemplo, todos los valores a la derecha
de 10 son mayores que 10; y todos los valores a la izquierda de 10 son
menores que 10. Este razonamiento lo podemos aplicar para cualquier otro
nodo. Por ejemplo: todos los valores a la derecha del Nodo 27 son mayores que
el; y todos los valores a la izquierda del Nodo 27 son menores que el.

Comparando esta Estructura con las estudiadas anteriormente, podemos
observar lo siguiente:

- En una Fila es posible localizar datos eficientemente si los mismos se
encuentran ordenados, pero las Operaciones de Inserción y
Eliminación resultan costosas; ya que se puede tener espacio desperdiciado
y perder tiempo en hacer recorridos. (Estructura con Memoria Fija)

- En las Listas, las operaciones de Inserción y Eliminación se pueden llevar
a cabo con facilidad, sin embargo la Búsqueda es una Operación bastante costosa
que incluso nos puede llevar a Recorrer todos los elementos de ella para
localizar uno en particular. (Estructura con Memoria Dinámica)

BÚSQUEDA EN UN ÁRBOL BINARIO.
El Algoritmo de Búsqueda de un Árbol Binario; es muy simple y similar al
que utilizamos para insertar un Dato. Comparamos contra el Nodo actual;
iniciando por la raiz; y vemos si este dato es el que buscamos; si no es asi;
preguntamos si es mayor o menor; y dependiendo de la respuesta; navegaremos
en el Árbol hacia su Hijo Izquierdo o Derecho.

El Algoritmo pudiera quedar de la siguiente forma.


   Si Nodo->Dato = Valor a Buscar
      Entonces Retornar; Valor encontrado
   De Otro Modo
      Si Nodo->Dato < Valor a Buscar
         Entonces Llamaremos a la misma función ahora con el Hijo Derecho
      De Otro Modo
         Entonces llamaremos a la misma función ahora con el Hijo Izquierdo

Para complementar la rutina; pudieramos llevar el
control del Nivel en el que estamos y tambien indicar
quien es su Padre, y si es el Hijo Derecho o Izquierdo

*/

// Librerias
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

// Constantes
#define TRUE  1
#define FALSE 0

// Define el Cambio de Línea
#define CR printf("\n")

// Defino la Estructura de los Nodos del Árbol
typedef struct NODO_ARBOL
{
   int    iDato;  // Dato del Nodo
   struct NODO_ARBOL *pIzquierdo;  // Apuntador a Hijo Izquierdo
   struct NODO_ARBOL *pDerecho;    // Apuntador a Hijo Derecho
}nodo_arbol;

// Función para crear un Nodo para el Árbol
nodo_arbol *FnArbolNodoCrea(int xDato)
{
   // Defino una variable de tipo Apuntador Nodo
   nodo_arbol *xNodo;

   // Reservo la Memoria para el Nodo
   xNodo = (nodo_arbol *)malloc(sizeof(nodo_arbol));

   // Verifico que haya podido reservar memoria
   if (xNodo == NULL)
      // Despliega el Mensaje de Error
      printf("Error. No se pudo reservar memoria para el Nodo_Arbol");
   else
   {
      // Asigna la Información al Nodo
      xNodo->iDato      = xDato; // El Dato
      xNodo->pDerecho   = NULL;  // Apunta a Null
      xNodo->pIzquierdo = NULL;  // Apunta a Null
   }

   //Retorna el resultado
   return xNodo;
}

// Función para Insertar un Nodo en el Árbol
void SbArbolInsertaNodo(nodo_arbol **pRaiz, int xDato)
{
    // Definimos un Apuntador a un Nodo Nuevo
    nodo_arbol *pNodoNuevo;

    // Definiendo un Apuntador Auxiliar
    nodo_arbol *pAuxiliar;

    // Variable para saber en que nivel se insertó
    int iNivel=1;
    int iPadre=0;

    // Variable para Indicar el Lado de la Inserción
    char sLado[4]="Der";

    // Variables para saber si se insertó correctamente
    int bHuboInsercion = TRUE;

    // Creamos el Nodo Nuevo
    pNodoNuevo=FnArbolNodoCrea(xDato);

    // Verificamos si está vacío el Árbol
    if (*pRaiz==NULL)
    {
        // Lo Asignamos como raiz; el nuevo nodo
        *pRaiz = pNodoNuevo;

        // Mensaje
        printf("Se ha insertado el Dato:%d como Raiz del Arbol\n",xDato);
    }
    // Si no está vacío entramos a un ciclo
    else
    {
       // Colocamos el Auxiliar apuntando a raiz
       pAuxiliar = *pRaiz;

       // Ciclo
       while (TRUE)
       {
          // Verificamos si es mayor el que quiero insertar
          if (pAuxiliar->iDato < xDato)
              // Verificamos si tiene Hijo Derecho
              if (pAuxiliar->pDerecho!=NULL)
              {
                  // Guardo el Padre
                  iPadre = pAuxiliar->iDato;

                  // Movemos a pAuxiliar al Nodo Derecho
                  pAuxiliar = pAuxiliar->pDerecho;
              }
              else
              {   
                  // No tiene Hijo Derecho; Insertamos
                  pAuxiliar->pDerecho=pNodoNuevo;

                  // Salimos del Ciclo
                  break;
              }
          else
             // Verifica si es Menor el que quiero insertar
             if (pAuxiliar->iDato > xDato)
                // Verificamos si tiene Hijo Izquierdo
                if (pAuxiliar->pIzquierdo!=NULL)
                {
                    // Guardo el Padre
                    iPadre = pAuxiliar->iDato;

                    // Movemos a pAuxiliar al Nodo Izquierdo
                    pAuxiliar = pAuxiliar -> pIzquierdo;
                }
                else
                {   
                    // No tiene Hijo Izquierdo; Insertamos
                    pAuxiliar->pIzquierdo=pNodoNuevo;

                    // Actualizamos el lado para el Mensaje
                    strcpy(sLado,"Izq");

                    // Salimos del Ciclo
                    break;
                 }
             else
             {
                // Se intenta Insertar un Nodo que ya Existe
                bHuboInsercion = FALSE;

                // Sale del Ciclo
                break;
             }

           // Incrementamos el Nivel
           iNivel++;

       }// Fin del Ciclo While

       // Verifica si Inserción Correcta
       if (bHuboInsercion)
          // Mensaje de Inserción
          printf("Se ha insertado el Dato:%02d como Hijo %s de:%02d en el Nivel:%d \n",xDato,sLado,pAuxiliar->iDato,iNivel);
       else
          // Mensaje de Error
          printf("Error. el Dato:%d ya existe como hijo de:%d en el Nivel:%d \n",xDato,iPadre,--iNivel);

    }
}

// Búsqueda Binaria I La mas Sencilla
int FnBoolArbolBinarioBusquedaI(nodo_arbol *pNodo,int xDato)
{
     // Verifica que no sea Null
     if (pNodo==NULL)
        // Finaliza la Función
        return FALSE;
     else
         // Verifica si el Nodo Contiene el Dato
         if (pNodo->iDato==xDato)
            // Finaliza la Función si lo encontro
            return TRUE;
         else
            // Verifica si lo encuentra en el Hijo Derecho
            if (FnBoolArbolBinarioBusquedaI(pNodo->pDerecho,xDato))
               // Retorna True y Finaliza si lo encontro
               return TRUE;
            else
               // Verifica si lo encuentra en el Hijo Izquierdo
               if (FnBoolArbolBinarioBusquedaI(pNodo->pIzquierdo,xDato))
                  // Retorna TRUE y Finaliza si lo encontro
                  return TRUE;
               else
                  // Si no lo encontro en el Hijo Derecho ni en el Izquiero, retorna FALSE
                  return FALSE;
}

// Búsqueda en Árbol Binario II
int FnBoolArbolBinarioBusquedaII(nodo_arbol *pNodo,
                                 int         xDato,
                                 int         iNodoPadre,
                                 int         iNivel,
                                 char        cLado)
{

     // Variable
     char strLado[4];

     // Verifica que no sea Null y que no esté en la raiz
     if (pNodo==NULL && iNivel==0)
     {
        // Mensaje de que nel árbol está vacío
        printf("El Árbol está vacío");

        // El Árbol está vacío
        return FALSE;
     }
     else
     
        
        // Verifica que el Nodo sea Null
        if (pNodo==NULL)
           // Finaliza la Función
           return FALSE;
        else
        {
           printf("Buscando:%d\n",xDato);
           // Verifica que sea el Dato
           if (pNodo->iDato==xDato)
           {
               // Despliega el Mensaje de que lo encontro y el Nivel
               printf("El Dato %d fue encontrado en el Nivel:%d \n",xDato,iNivel);

               // Despliega el Mensaje de su Padre
               if (iNivel==0)
                  printf("El Dato %d No tiene Padre, fue encontrado en la raiz del Árbol \n",xDato);
               else
               {
                  // Verifica que lado es
                  cLado=='D' ? strcpy(strLado,"Der") : strcpy(strLado,"Izq");

                  // Imprime el Padre y el Lado
                  printf("El Padre del Dato es: %d y es Hijo %s \n",iNodoPadre,strLado);
               }

               // Finaliza la Función
               return TRUE;
           }
           else
           {

              // Incrementamos el Nivel
              iNivel++;


              // Verifica si lo encuentra en el Hijo Derecho
              if (FnBoolArbolBinarioBusquedaII(pNodo->pDerecho,xDato,pNodo->iDato,iNivel,'D'))
                 // Retorna True y Finaliza si lo encontro
                 return TRUE;
              else
                 // Verifica si lo encuentra en el Hijo Izquierdo
                 if (FnBoolArbolBinarioBusquedaII(pNodo->pIzquierdo,xDato,pNodo->iDato,iNivel,'I'))
                    // Retorna TRUE y Finaliza si lo encontro
                    return TRUE;
                 else
                    // Si no lo encontro en el Hijo Derecho ni en el Izquiero, retorna FALSE
                    return FALSE;
           }
         }
}

// Búsqueda en Árbol Binario III
int FnBoolArbolBinarioBusquedaIII(nodo_arbol *pNodo,
                                  int         xDato,
                                  int         iNodoPadre,
                                  int         iNivel,
                                  char        cLado)
{

     // Variable
     char strLado[4];

     // Verifica que no sea Null y que no esté en la raiz
     if (pNodo==NULL && iNivel==0)
     {
        // Mensaje de que nel árbol está vacío
        printf("El Árbol está vacío");

        // El Árbol está vacío
        return FALSE;
     }
     else
        // Verifica que el Nodo sea Null
        if (pNodo==NULL)
           // Finaliza la Función
           return FALSE;
        else
        {
           printf("Buscando :%d\n",xDato);
           // Verifica que sea el Dato
           if (pNodo->iDato==xDato)
           {
               // Despliega el Mensaje de que lo encontro y el Nivel
               printf("El Dato %d fue encontrado en el Nivel:%d \n",xDato,iNivel);

               // Despliega el Mensaje de su Padre
               if (iNivel==0)
                  printf("El Dato %d No tiene Padre, fue encontrado en la raiz del Árbol \n",xDato);
               else
               {
                  // Verifica que lado es
                  cLado=='D' ? strcpy(strLado,"Der") : strcpy(strLado,"Izq");

                  // Imprime el Padre y el Lado
                  printf("El Padre del Dato es: %d y es Hijo %s \n",iNodoPadre,strLado);
               }

               // Finaliza la Función
               return TRUE;
           }
           else
           {
              // Incrementamos el Nivel
              iNivel++;

              // Averiguamos hacia donde buscar
              if (pNodo->iDato < xDato)
                 // Verifica si lo encuentra en el Hijo Derecho
                 return FnBoolArbolBinarioBusquedaIII(pNodo->pDerecho,xDato,pNodo->iDato,iNivel,'D');
              else
                 // Verifica si lo encuentra en el Hijo Izquierdo
                 return  FnBoolArbolBinarioBusquedaIII(pNodo->pIzquierdo,xDato,pNodo->iDato,iNivel,'I');
           }
        }
}

// Función que suma los nodos del Arbol
int fnArbolSumaNodos(nodo_arbol *pNodo)
{
   int resultado;
   int sumaDerecha;
   int sumaIzquierda;

   // Verifica que sea null
   if (pNodo==NULL)
      return 0;
   else
   {
      sumaDerecha   = fnArbolSumaNodos(pNodo->pDerecho);
      sumaIzquierda = fnArbolSumaNodos(pNodo->pIzquierdo);
      printf("La Suma Derecha   de %d es:%d\n",pNodo->iDato,sumaDerecha);
      printf("La Suma Izquierda de %d es:%d\n",pNodo->iDato,sumaIzquierda);
      resultado = pNodo->iDato + sumaDerecha + sumaIzquierda;
      printf("Resultado es:%d\n",pNodo->iDato,sumaIzquierda);
   }
}


// Función Principal
int main()
{
    // Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 31 - Arboles Binarios de Busqueda \n\n");

    // Declaro el Apuntador a la raiz.
    nodo_arbol *pRaiz=NULL;

    // Secuencia a Insertar:10,14,2,27,25,31,5,-2,9,----,19,-9,39,49,59
    printf("Creando el Arbol Binario con la siguiente Secuencia:10,14,2,27,25,31,5,-2,9\n");
    SbArbolInsertaNodo(&pRaiz,10);
    SbArbolInsertaNodo(&pRaiz,14);
    SbArbolInsertaNodo(&pRaiz,2);
    SbArbolInsertaNodo(&pRaiz,27);
    SbArbolInsertaNodo(&pRaiz,25);
    SbArbolInsertaNodo(&pRaiz,31);
    SbArbolInsertaNodo(&pRaiz,5);
    SbArbolInsertaNodo(&pRaiz,-2);
    SbArbolInsertaNodo(&pRaiz,9);

    // Deja una Línea
    CR;

    // Mensaje de Búsquedas Simples
    printf("Realizamos Busquedas Simples \n");
    CR;

    // Llamamos a la Función y Desplegamos si lo encontro o no
    FnBoolArbolBinarioBusquedaI(pRaiz,17) ? printf("Si encontro el 17") : printf("No encontro el 17");
    CR;

    // Llamamos a la Función y Desplegamos si lo encontro o no
    FnBoolArbolBinarioBusquedaI(pRaiz,5) ? printf("Si encontro el 5") : printf("No encontro el 5");
    CR;

    // Llamamos a la Función y Desplegamos si lo encontro o no
    FnBoolArbolBinarioBusquedaI(pRaiz,2) ? printf("Si encontro el 2") : printf("No encontro el 2");
    CR;
    CR;

    // Mensaje de Búsquedas con Nivel, Padre y Lado
    printf("Realizamos Busquedas Con Nivel, Padre y Lado \n");
    CR;

    // Busquedas
    FnBoolArbolBinarioBusquedaII(pRaiz,10,-1,0,'R') ? printf("Si encontro el 10") : printf("No encontro el 10");
    getc(stdin);
    FnBoolArbolBinarioBusquedaIII(pRaiz,10,-1,0,'R') ? printf("Si encontro el 10") : printf("No encontro el 10");
    CR;
    getc(stdin);

    CR;
    CR;

    FnBoolArbolBinarioBusquedaII(pRaiz,27,-1,0,'R') ? printf("Si encontro el 27") : printf("No encontro el 27");
    getc(stdin);
    FnBoolArbolBinarioBusquedaIII(pRaiz,27,-1,0,'R') ? printf("Si encontro el 27") : printf("No encontro el 27");
    getc(stdin);
    CR;
    CR;

    FnBoolArbolBinarioBusquedaII(pRaiz,100,-1,0,'R') ? printf("Si encontro el 100") : printf("No encontro el 100");
    getc(stdin);
    FnBoolArbolBinarioBusquedaIII(pRaiz,100,-1,0,'R') ? printf("Si encontro el 100") : printf("No encontro el 100");
    getc(stdin);
    CR;   
    CR;

    // SUma los nodos
    printf("La Suma de los nodos del arbol es:%d\n",fnArbolSumaNodos(pRaiz));

    // Finaliza la aplicación retornando 0
    return 0;
}

