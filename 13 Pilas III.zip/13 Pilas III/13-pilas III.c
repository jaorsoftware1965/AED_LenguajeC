/*
Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE
www.jaorsoftware.com

Clase 13 - Pilas III

Para esta clase,veremos el algoritmo para evaluar una expresión
pero ya considerando precedencia de operadores.

Para poder dar mas profundidad y explicación, utilizaremos la
letra e para indicar la operación de "elevar a potencia" ya que
en C no existe un operador para ello.

Consideraremos que elevar a potencia, tiene mas prioridad que
la multiplicación y la división.

Expresión a evaluar
5 + 6 * 3 e 2

Operadores:+
Operandos :59

5 * 8 - 2 e 4

Operadores:
Operandos :24

*/

// Librerias
#include <stdio.h>
#include <stdlib.h>
#include "string.h"
#include "math.h"

// Definimos True y False
#define TRUE  1
#define FALSE 0

// Definimos el Tamaño de la Pila
#define PILA_TAMANIO   50

// Espacion Blanco
#define ESPACIO_BLANCO 32

// Definimos la estructura de la Pila
typedef struct stcPila
{
    // Variable para manejar el tope actual de la Pila
    int  iPilaTope;

    // El Arreglo para la Pila
    int arrIntPila[PILA_TAMANIO];

}pila;

// Implementamos Inicializar la Pila
void SbPilaInicializa(pila *pPila);

// Implementamos Verificar si la Pila está vacía
int FnIntPilaVacia(pila *pPila);

// Implementamos Verificar si la Pila está llena
int FnIntPilaLlena(pila *pPila);

// Implementamos Obtener cuantos elementos tiene la Pila
int FnIntPilaElementos(pila *pPila);

// Implementamos desplegar el Elemento de la CIma
void SbPilaCima(pila *pPila);

// Implementamos obtener el Elemento de la CIma sin sacarlo
int  FnIntPilaCima(pila *pPila);

// Implementamos Insertar un Elemento en la Pila
void SbPilaPush(pila *pPila,int iElemento);

// Implementamos Sacar un Elemento de la Pila
int FnIntPilaPop(pila *pPila);

// Función que valida si es un dígito
int FnIntDigitoEs(char cCaracter)
{   
   // Valida en cuanto al ASCII de los Numeros
   if (cCaracter>47 && cCaracter < 58)
      return TRUE;
   else
      return FALSE;
}

// Función que valida si es un operador
int FnIntOperadorEs(char cCaracter)
{
   // Variable para el Resultado
   int iResult = FALSE;

   switch(cCaracter)
   {

      case  43:// Suma
      case  45:// Resta
      case  42:// Multiplicación
      case  47:// División
      case 'e':// Exponente
               iResult = TRUE;
               break;
   }

   // Retorna el Resultado
   return (iResult);
}

// Función para determinar Prioridad
int FnIntMayorPrioridad(char cOperador1,char cOperador2)
{
    // Variable para el Resultado
    int iResult;

    switch (cOperador1)
    {

       // Suma o Resta
       case  43:// En Procesaimiento de izquierda a derecha tiene mayor prioridad sobre si mismo
       case  45:if (cOperador2=='+' || cOperador2=='-')
                    iResult=TRUE;
                else
                    iResult=FALSE;
                break;

       case  42:// Tiene mayor prioridad sobre todos excepto "e"
       case  47:if (cOperador2=='e')
                    iResult=FALSE;
                else
                    iResult=TRUE;
                break;

       // Exponente
       case 'e':// Tiene mayor prioridad sobre todos incluyendo que si mismo en procesamiento por izquierda
                iResult=TRUE;
                break;
    }
    // Devuelve el resultado
    return iResult;
}

// Función que evalúa una expresión
int FnIntExpresionEvaluaPrioridad(char *sExpresion)
{
    // Define una pila para para operandos y operadores
    pila xPilaOperandos;
    pila xPilaOperadores;

    // Inicializa Ambas Pilas
    SbPilaInicializa(&xPilaOperandos);
    SbPilaInicializa(&xPilaOperadores);

    // Para el Indice de los caracteres de la Expresión
    int iIndice;

    // para el Resultado
    int iResult=0;

    // para el Operador
    char cOperador;

    // para los Operandos
    int cOperando,cOperando2;

    // Mensaje de Procesamiento
    printf("Analizando Expresión ... \n");

    // Ciclo para analizar la expresión
    for (iIndice=0; iIndice<strlen(sExpresion); iIndice++)
    {
        // Descarta el Espacio en Blanco
        if (sExpresion[iIndice]!=ESPACIO_BLANCO)
        {
            // Verifica que caracter es
            switch (sExpresion[iIndice])
            {
                case  43:// Suma
                case  45:// Resta
                case  42:// Multiplicación
                case  47:// División
                case 'e':// Exponente
                         // Siempre solo hay un operador en la Pila
                         // Verifica si la Pila de Operadores está vacía
                         if (FnIntPilaVacia(&xPilaOperadores))
                            if (FnIntPilaElementos(&xPilaOperandos)>0)
                            {
                               printf("%c es un Operador; se agrega a la Pila de Operadores \n",sExpresion[iIndice]);
                               SbPilaPush(&xPilaOperadores,sExpresion[iIndice]);
                            }
                            else
                            {
                               printf("Error. Operador sin Operando Previo :%c",sExpresion[iIndice]);
                               iResult=-1;
                            }
                         else
                         {
                               printf("Error. Exceso de Operadores :%c",sExpresion[iIndice]);
                               iResult=-1;
                         }

                         break;

                case  48:// 0
                case  49:// 1
                case  50:// 2
                case  51:// 3
                case  52:// 4
                case  53:// 5
                case  54:// 6
                case  55:// 7
                case  56:// 8
                case  57:// 9
                         // Verifica si la Pila de Operadores está vacía
                         if (FnIntPilaVacia(&xPilaOperadores))
                            if (FnIntPilaVacia(&xPilaOperandos))
                                // Agrega el Elemento a la Pila de Operandos
                                SbPilaPush(&xPilaOperandos,sExpresion[iIndice]-48);
                            else
                            {
                                printf("Error. Exceso de Operandos :%c",sExpresion[iIndice]);
                                iResult=-1;
                            }
                         else
                         {
                            // Se agrega para la Funcion con Prioridad
                            // Verifica si ya es el último caracter de la Expresión
                            if (iIndice == strlen(sExpresion)-1)
                            {
                                // Obtiene el Operador
                                cOperador=FnIntPilaPop(&xPilaOperadores);

                                // Obtiene el Operando
                                cOperando=FnIntPilaPop(&xPilaOperandos);

                                // Realiza la operación con los 2 operandos de acuerdo al Operador
                                if (cOperador=='+')
                                   iResult= cOperando + (sExpresion[iIndice]-48);
                                else
                                   if (cOperador=='-')
                                      iResult= cOperando - (sExpresion[iIndice]-48);
                                   else
                                      if (cOperador=='*')
                                         iResult= cOperando * (sExpresion[iIndice]-48);
                                      else
                                         if (cOperador=='/')
                                            iResult= cOperando / (sExpresion[iIndice]-48);
                                         else
                                            iResult= pow(cOperando,sExpresion[iIndice]-48);

                                // Despliega la Operación
                                printf("Se realizó operación: %d %c %d = %d\n",cOperando, cOperador,sExpresion[iIndice]-48,iResult);

                                // Inserta el Operando en la pila
                                SbPilaPush(&xPilaOperandos,iResult);
                                iResult=0;


                                // Ciclo para procesar mientras la pila de operadores no esté vacía
                                while (!FnIntPilaVacia(&xPilaOperadores))
                                {
                                   // Obtiene el Operador
                                   cOperador=FnIntPilaPop(&xPilaOperadores);

                                   // Obtiene el Operando1
                                   cOperando=FnIntPilaPop(&xPilaOperandos);

                                   // Obtiene el Operando2
                                   cOperando2=FnIntPilaPop(&xPilaOperandos);


                                   // Realiza la operación con los 2 operandos de acuerdo al Operador
                                   if (cOperador=='+')
                                      iResult= cOperando2 + cOperando;
                                   else
                                      if (cOperador=='-')
                                         iResult= cOperando2 - cOperando;
                                      else
                                         if (cOperador=='*')
                                            iResult= cOperando2 * cOperando;
                                         else
                                            if (cOperador=='/')
                                               iResult= cOperando2 / cOperando;
                                            else
                                               iResult= pow(cOperando2,cOperando);

                                   // Despliega la Operación
                                   printf("Se realizó operación: %d %c %d = %d\n",cOperando2, cOperador,cOperando,iResult);

                                   // Inserta el Operando en la pila
                                   SbPilaPush(&xPilaOperandos,iResult);
                                   iResult=0;
                                }
                            }
                            else // El Operando analizado no es el último caracter de la expresin
                                  // 5 + 6 t 8
                                  //
                                  // Operadores:+
                                  // Operandos :56
                                  // Verifica si el caracter siguiente es un dígito
                                  if (FnIntDigitoEs(sExpresion[iIndice+1]))
                                  {
                                     printf("Error. Falta un operador antes de:%c\n",sExpresion[iIndice+1]);
                                     iResult=-1;
                                  }
                                  else
                                     // Verifica que el siguiente caracter es un operador
                                     if (FnIntOperadorEs(sExpresion[iIndice+1]))

                                        // Verifica si el operador en la cima tiene mayor prioridad que el que viene
                                        if (FnIntMayorPrioridad(FnIntPilaCima(&xPilaOperadores),sExpresion[iIndice+1]))
                                        {  // Se realiza la operación actual
                                           // Obtiene el Operador
                                           cOperador=FnIntPilaPop(&xPilaOperadores);

                                           // Obtiene el Operando
                                           cOperando=FnIntPilaPop(&xPilaOperandos);

                                           // Realiza la operación con los 2 operandos de acuerdo al Operador
                                           if (cOperador=='+')
                                              iResult= cOperando + (sExpresion[iIndice]-48);
                                           else
                                              if (cOperador=='-')
                                                 iResult= cOperando - (sExpresion[iIndice]-48);
                                              else
                                                 if (cOperador=='*')
                                                    iResult= cOperando * (sExpresion[iIndice]-48);
                                                 else
                                                    if (cOperador=='/')
                                                       iResult= cOperando / (sExpresion[iIndice]-48);
                                                    else
                                                       iResult= pow(cOperando,sExpresion[iIndice]-48);

                                           // Despliega la Operación
                                           printf("Se realizó operación: %d %c %d = %d\n",cOperando, cOperador,sExpresion[iIndice]-48,iResult);

                                           // Inserta el Operando en la pila
                                           SbPilaPush(&xPilaOperandos,iResult);
                                           iResult=0;

                                        }
                                        else
                                        {
                                           // Agrego el Operando a la Pila sin procesarlo
                                           SbPilaPush(&xPilaOperandos,sExpresion[iIndice]-48);

                                           // Agrego el Operador con mayor prioridad a la pila e incremento el iIndice
                                           SbPilaPush(&xPilaOperadores,sExpresion[++iIndice]);

                                        }
                                     else // Caracter No reconocido
                                     {
                                        printf("Error. Caracter No Reconocido :%c",sExpresion[iIndice+1]);
                                        iResult=-1;
                                     }


                         }

                         break;
                default: printf("Error. Caracter no reconocido:%c",sExpresion[iIndice]);
                         iResult=-1;
                         break;

            }// Cierre del switch
        } // Cierre del IF del Espacio en Blanco

        // Verifica que hubo error
        if (iResult==-1)
           break;

    }// Ciclo For
    if (iResult!=-1)
       //if (FnIntPilaElementos(&xPilaOperandos)==1 && FnIntPilaVacia(&xPilaOperadores))
       if (FnIntPilaVacia(&xPilaOperadores))
       {
           iResult = FnIntPilaPop(&xPilaOperandos);
           printf("El resultado de la Expresión %s es:%d \n",sExpresion,iResult);
       }

       else
          printf("Error. Exceso de Operadores:%c \n",FnIntPilaPop(&xPilaOperadores));

    // Retorna el Resultado
    return (iResult);

}



// Función Principal
int main()
{
    // Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 13 - Pilas III\n\n");

   // printf("Evaluando Prioridad entre operadores ...\n");
   // printf("Tiene mayor Prioridad + que + =>%d\n",FnIntMayorPrioridad('+','+'));
   // printf("Tiene mayor Prioridad + que - =>%d\n",FnIntMayorPrioridad('+','-'));
   // printf("Tiene mayor Prioridad + que * =>%d\n",FnIntMayorPrioridad('+','*'));
   // printf("Tiene mayor Prioridad + que / =>%d\n",FnIntMayorPrioridad('+','/'));
   // printf("Tiene mayor Prioridad + que e =>%d\n",FnIntMayorPrioridad('+','e'));
   // printf("Tiene mayor Prioridad - que + =>%d\n",FnIntMayorPrioridad('-','+'));
   // printf("Tiene mayor Prioridad - que - =>%d\n",FnIntMayorPrioridad('-','-'));
   // printf("Tiene mayor Prioridad - que * =>%d\n",FnIntMayorPrioridad('-','*'));
   // printf("Tiene mayor Prioridad - que / =>%d\n",FnIntMayorPrioridad('-','/'));
   // printf("Tiene mayor Prioridad - que e =>%d\n",FnIntMayorPrioridad('-','e'));
   // printf("Tiene mayor Prioridad * que + =>%d\n",FnIntMayorPrioridad('*','+'));
   // printf("Tiene mayor Prioridad * que - =>%d\n",FnIntMayorPrioridad('*','-'));
   // printf("Tiene mayor Prioridad * que * =>%d\n",FnIntMayorPrioridad('*','*'));
   // printf("Tiene mayor Prioridad * que / =>%d\n",FnIntMayorPrioridad('*','/'));
   // printf("Tiene mayor Prioridad * que e =>%d\n",FnIntMayorPrioridad('*','e'));
   // printf("Tiene mayor Prioridad / que + =>%d\n",FnIntMayorPrioridad('/','+'));
   // printf("Tiene mayor Prioridad / que - =>%d\n",FnIntMayorPrioridad('/','-'));
   // printf("Tiene mayor Prioridad / que * =>%d\n",FnIntMayorPrioridad('/','*'));
   // printf("Tiene mayor Prioridad / que / =>%d\n",FnIntMayorPrioridad('/','/'));
   // printf("Tiene mayor Prioridad / que e =>%d\n",FnIntMayorPrioridad('/','e'));
   // printf("Tiene mayor Prioridad e que + =>%d\n",FnIntMayorPrioridad('e','+'));
   // printf("Tiene mayor Prioridad e que - =>%d\n",FnIntMayorPrioridad('e','-'));
   // printf("Tiene mayor Prioridad e que * =>%d\n",FnIntMayorPrioridad('e','*'));
   // printf("Tiene mayor Prioridad e que / =>%d\n",FnIntMayorPrioridad('e','/'));
   // printf("Tiene mayor Prioridad e que e =>%d\n",FnIntMayorPrioridad('e','e'));

    // Evalua la Expresión
    //FnIntExpresionEvaluaCompleta("5+6");

    // Evalua la Expresión con Prioridad
    FnIntExpresionEvaluaPrioridad("5+6*4e2");

    // Evlua expresión
    //FnIntExpresionEvaluaPrioridad("5*8-2e4");

}

// Implementamos Inicializar la Pila
void SbPilaInicializa(pila *pPila)
{
   // Para Inicializa la Pila basta con poner el tope a -1
   // Ya que el primer elemento ocupa la posición 0
   pPila->iPilaTope=-1;

   // Desplegamos Mensaje
   printf("Pila Inicializada ...\n");
}

// Implementamos Verificar si la Pila está vacía
int FnIntPilaVacia(pila *pPila)
{
    if (pPila->iPilaTope==-1)
       return TRUE;
    else
       return FALSE;
}

// Implementamos Verificar si la Pila está llena
int FnIntPilaLlena(pila *pPila)
{
    if (pPila->iPilaTope==PILA_TAMANIO-1)
       return TRUE;
    else
       return FALSE;
}

// Implementamos Obtener cuantos elementos tiene la Pila
int FnIntPilaElementos(pila *pPila)
{
    // Retorna el Tope de la Pila
    return pPila->iPilaTope+1;
}

// Implementamos para Desplegar el Elemento en la Cima
void SbPilaCima(pila *pPila)
{
    // Verificamos si la Pila está vacía
    if (FnIntPilaVacia(pPila))
       printf("La Pila está vacía; no hay elemento Cima\n");
    else
       printf("Pila Cima: %d",pPila->arrIntPila[pPila->iPilaTope]);
}

// Implementamos para Obtener el Elemento en la Cima
int FnIntPilaCima(pila *pPila)
{
    // Verificamos si la Pila está vacía
    if (FnIntPilaVacia(pPila))
       return (-1);
    else
       return(pPila->arrIntPila[pPila->iPilaTope]);
}

// Implementamos Insertar un Elemento en la Pila
void SbPilaPush(pila *pPila,int iElemento)
{
    // Verificamos si la Pila está llena
    if (FnIntPilaLlena(pPila))
       printf("La Pila está llena y no es posible agregar el elemento:%d\n",iElemento);
    else
    {
       // Incrementamos el tope de la pila
       pPila->iPilaTope++;

       // Agrega el Elemento a la Pila
       pPila->arrIntPila[pPila->iPilaTope]=iElemento;

       // Colocamos el dato en la Pila
       //printf("Se ha agregado el elemento %d a la Pila \n",iElemento);
    }
}

// Implementamos Sacar un Elemento de la Pila
int FnIntPilaPop(pila *pPila)
{
    // Verificamos si la Pila está vacía
    if (FnIntPilaVacia(pPila))
    {
       printf("La Pila está vacía no es posible sacar elementos\n");
       return pPila->iPilaTope;
    }
    else
    {

       // Colocamos el dato en la Pila
       //printf("Se ha sacado un elemento de la Pila %d \n",pPila->arrIntPila[pPila->iPilaTope]);
       // Agrega el Elemento a la Pila
       return(pPila->arrIntPila[pPila->iPilaTope--]);
    }

}

