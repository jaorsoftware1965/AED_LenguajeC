/*
Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE
www.jaorsoftware.cu.cc

Clase 32 - Arbol Binario Eliminacion.

Ya hemos visto el Proceso de Insercion y el Proceso de Búsqueda
en un Arbol Binario.

Ahora vamos a analizar e implementar el Proceso de Eliminacion.
El Proceso de eliminar un nodo de un Arbol Binario, es una tarea
un poco mas compleja y la cual contempla, diferentes circunstancias
las cuales analizaremos una por una.

Arbol Binario Ejemplo

             10                         Nivel 0
        2          14                   Nivel 1
   -2      5            27              Nivel 2
     -9       9      25    31           Nivel 3
                  19          39        Nivel 4
               18               49      Nivel 5
            17                     59   Nivel 6
          16                            Nivel 7


ELIMINAR UN NODO HOJA.
Este es la situacion mas simple; en la cual queremos eliminar un
nodo Hoja; es decir; un nodo que no tiene hijos.
Para el Arbol mostrado serían los nodos -9,9,16 y 59.

En este caso, lo único que se tiene que hacer es eliminar
la referencia al Nodo y Liberar la Memoria.
Los nodos posibles son el 16,59,-9 y 9.

ELIMINAR UN NODO QUE TIENE UN SOLO HIJO.

    10                14
       14          13    27
    13    27              
           ....

Este caso tambien es muy sencillo. Cuando el nodo que se
desea eliminar, tiene un solo Hijo, sin importar si es
el derecho o el izquierdo; lo único que se tiene que
hacer es:
a)  pasar el dato del Hijo al Nodo a Eliminar(Modificar)
b)  pasar los apuntadores derecho e izquierdo del Nodo Hijo al Nodo
    a eliminar
c)  liberar el nodo Hijo.

ELIMINAR UN NODO CUANDO TIENE 2 HIJOS.
Este es el caso mas complejo. Para eliminar un nodo con 2
hijos se tienen 2 opciones.

1) Colocar en lugar del Nodo a Eliminar; el Hijo con Menor
valor de su Lado Derecho; es decir su último descendiente
izquierdo. Para el caso del ejemplo; si quisieramos eliminar
el 10; tendríamos que colocar en su lugar el 1.
Si quisieramos eliminar el 27, tendriamos que colocar el 31

2) Colocar en lugar del Nodo a Eliminar; el Hijo con Mayor
valor de su Lado Izquierdo; es decir su último descendiente
derecho. Para el caso del ejemplo, si quisieramos eliminar
el 10; tendríamos que colocar en su lugar el 9.
Si quisiéramos eliminar el 27, tendriamos que colocar el 25

Para ambos casos, el proceso correcto
a) Es SUSTITUIR el valor de Nodo a Eliminar con el Valor del
   Nodo que lo va a sustituir.
b) Colocar el Apuntador Derecho (o Izquierdo segun 1 o 2)del
   Nodo a Eliminar(el que sustituye) al apuntador a
   Eliminar(el Sustituido)
c) Hacer que su Padre Apunte al Apuntador Derecho según el caso


*/

// Librerias
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define TRUE  1
#define FALSE 0

// Define el Cambio de Línea
#define CR printf("\n")

// Defino la Estructura de los Nodos del Arbol
typedef struct NODO_ARBOL
{
   int    iDato;  // Dato del Nodo
   struct NODO_ARBOL *pIzquierdo;  // Apuntador a Hijo Izquierdo
   struct NODO_ARBOL *pDerecho;    // Apuntador a Hijo Derecho
}nodo_arbol;

// Funcion para Eliminar un NODO
int FnBoolArbolBinarioEliminaNodo(nodo_arbol **pNodo,int xDato)
{
    // Para buscar el Máximo Valor Izquierdo o el Mínimo Valor Derecho
    nodo_arbol *pNodoAuxActual;
    nodo_arbol *pNodoAuxPadre;
    nodo_arbol *pNodoEliminar;


   // Verificamos si es null
   if (*pNodo == NULL)
   {
      // Devuelve Falso
      return FALSE;
   }
   else
   {
      // Mensaje
      printf("Nodo Actual     :%d \n",(*pNodo)->iDato);
      printf("Direcccion Nodo :%p \n",(*pNodo));
      printf("Direcccion Nodo :%x \n",(*pNodo));
      getc(stdin);

      // Verifica si es el dato a Eliminar
      if ((*pNodo)->iDato == xDato)
      {
         // Mensaje
         printf("Es el dato a Eliminar:%d \n",(*pNodo)->iDato);

         // Verifica si es Hoja
         if ((*pNodo)->pDerecho==NULL && (*pNodo)->pIzquierdo==NULL)
         {
			//      14
			// Null    Null
			 
            // Mensaje
            printf("Se elimina Nodo Hoja:%d \n",(*pNodo)->iDato);

            // Solo hay que apuntar a Null
            *pNodo=NULL;

            // liberar el Nodo
            free(*pNodo);

            // Retornar TRUE
            return TRUE;
         }
         else
             // Verifica si tiene un Solo Hijo, el Derecho
             if ((*pNodo)->pIzquierdo==NULL)
             {
                //     14
                // Null    20
				
                // Mensaje de que tiene un solo Hijo, el Derecho
                printf("Tiene un solo hijo, el Derecho:%d \n",(*pNodo)->pDerecho->iDato);

                // Colocamos el Dato del Hijo en el Nodo a Eliminar(Modificar)
                (*pNodo)->iDato = (*pNodo)->pDerecho->iDato;

                // Mensaje de que tiene un solo Hijo, el Derecho
                printf("El Hijo Derecho:%d ocupo su lugar \n",(*pNodo)->iDato);

                // Obtengo el Nodo a Eliminar
                pNodoEliminar = (*pNodo)->pDerecho;

                // Colocamos los apuntadores tal y como los tenga el Hijo
                (*pNodo)->pDerecho   = pNodoEliminar->pDerecho;
                (*pNodo)->pIzquierdo = pNodoEliminar->pIzquierdo;


                // Liberamos la Memoria del Nodo Hijo Derecho
                free(pNodoEliminar);

                // Devolvemos TRUE
                return TRUE;

             }
             else
                 // Verifica si tiene un Solo Hijo, el Izquierdo
                 if ((*pNodo)->pDerecho==NULL)
                 {
                    //    10
                    //  2
                    // Mensaje de que tiene un solo Hijo, el Derecho
                    printf("Tiene un solo hijo, el Izquierdo:%d \n",(*pNodo)->pIzquierdo->iDato);

                    // Colocamos el Dato del Hijo en el Nodo a Eliminar(Modificar)
                    (*pNodo)->iDato = (*pNodo)->pIzquierdo->iDato;

                    // Mensaje de que tiene un solo Hijo, el Derecho
                    printf("El Hijo Izquierdo:%d ocupo su lugar \n",(*pNodo)->iDato);

                    // Obtengo el Nodo a Eliminar
                    pNodoEliminar = (*pNodo)->pIzquierdo;


                    // Colocamos los apuntadores tal y como los tenga el Hijo
                    (*pNodo)->pDerecho   = pNodoEliminar->pDerecho;
                    (*pNodo)->pIzquierdo = pNodoEliminar->pIzquierdo;

                    // Liberamos la Memoria del Nodo Hijo Izquierdo
                    free(pNodoEliminar);

                    // Devolvemos TRUE
                    return TRUE;

                 }
                 else
                 {
                    // Tiene 2 Hijos
                    //             10                         Nivel 0
                    //        2          14                   Nivel 1
                    //   -2      5            27              Nivel 2
                    //     -9       9      25    31           Nivel 3
                    //                  19          39        Nivel 4
                    //               18               49      Nivel 5
                    //            17                     59   Nivel 6
                    //         16                             Nivel 7
                    printf("El Dato a Eliminar tiene 2 Hijos \n");

                    // Obtenemos el Valor Menor de sus descendientes izquierdos

                    // Obtiene el Nodo Actual Como Padre
                    pNodoAuxPadre=(*pNodo);

                    // Navega hacia la Derecha
                    pNodoAuxActual=(*pNodo)->pDerecho;

                    // Ciclo para buscar el Valor Mínimo de sus descendientes Derechos
                    while (pNodoAuxActual->pIzquierdo)
                    {
                          // Guarda el Actual como Padre
                          pNodoAuxPadre = pNodoAuxActual;

                          // Navega hacia la izquierda
                          pNodoAuxActual = pNodoAuxActual->pIzquierdo;

                    }

                    // Encontro el Dato Final lo intercambia con el Nodo a Eliminar
                    (*pNodo)->iDato = pNodoAuxActual->iDato;

                    // Dejamos de Apuntar al Nodo Eliminado
                    if (pNodoAuxPadre == (*pNodo))
                       pNodoAuxPadre->pDerecho=pNodoAuxActual->pDerecho;
                    else
                       pNodoAuxPadre->pIzquierdo=pNodoAuxActual->pDerecho;

                    // Liberamos el Nodo Actual que es el que se elimina
                    free(pNodoAuxActual);
                 }
      }
      else
         // Verifica si el Dato del nodo actual, es menor que el dato a Eliminar
         if ((*pNodo)->iDato < xDato)
            // Navega hacia la Derecha
            FnBoolArbolBinarioEliminaNodo(&(*pNodo)->pDerecho,xDato);
         else
            // Navega hacia la Izquierda
            FnBoolArbolBinarioEliminaNodo(&(*pNodo)->pIzquierdo,xDato);

   }


}

// Funcion para crear un Nodo para el Arbol
nodo_arbol *FnArbolNodoCrea(int xDato)
{
   // Defino una variable de tipo Apuntador Nodo
   nodo_arbol *xNodo;

   // Reservo la Memoria para el Nodo
   xNodo = (nodo_arbol *)malloc(sizeof(nodo_arbol));

   // Verifico que haya podido reservar memoria
   if (xNodo == NULL)
      // Despliega el Mensaje de Error
      printf("Error. No se pudo reservar memoria para el Nodo_Arbol");
   else
   {
      // Asigna la Informacion al Nodo
      xNodo->iDato      = xDato; // El Dato
      xNodo->pDerecho   = NULL;  // Apunta a Null
      xNodo->pIzquierdo = NULL;  // Apunta a Null
   }

   //Retorna el resultado
   return xNodo;
}

// Funcion para Insertar un Nodo en el Arbol
void SbArbolInsertaNodo(nodo_arbol **pRaiz, int xDato)
{
    // Definimos un Apuntador a un Nodo Nuevo
    nodo_arbol *pNodoNuevo;

    // Definiendo un Apuntador Auxiliar
    nodo_arbol *pAuxiliar;

    // Variable para saber en que nivel se inserto
    int iNivel=1;
    int iPadre=0;

    // Variable para Indicar el Lado de la Insercion
    char sLado[4]="Der";

    // Variables para saber si se inserto correctamente
    int bHuboInsercion = TRUE;

    // Creamos el Nodo Nuevo
    pNodoNuevo=FnArbolNodoCrea(xDato);

    // Verificamos si está vacío el Arbol
    if (*pRaiz==NULL)
    {
        // Lo Asignamos como raíz; el nuevo nodo
        *pRaiz = pNodoNuevo;

        // Mensaje
        printf("Se ha insertado el Dato:%d como Raiz del Arbol\n",xDato);
    }
    // Si no está vacío entramos a un ciclo
    else
    {
       // Colocamos el Auxiliar apuntando a Raíz
       pAuxiliar = *pRaiz;

       // Ciclo
       while (TRUE)
       {
          // Verificamos si es mayor el que quiero insertar
          if (pAuxiliar->iDato < xDato)
              // Verificamos si tiene Hijo Derecho
              if (pAuxiliar->pDerecho!=NULL)
              {
                  // Guardo el Padre
                  iPadre = pAuxiliar->iDato;

                  // Movemos a pAuxiliar al Nodo Derecho
                  pAuxiliar = pAuxiliar->pDerecho;
              }
              else
              {   
                  // No tiene Hijo Derecho; Insertamos
                  pAuxiliar->pDerecho=pNodoNuevo;

                  // Salimos del Ciclo
                  break;
              }
          else
             // Verifica si es Menor el que quiero insertar
             if (pAuxiliar->iDato > xDato)
                // Verificamos si tiene Hijo Izquierdo
                if (pAuxiliar->pIzquierdo!=NULL)
                {
                    // Guardo el Padre
                    iPadre = pAuxiliar->iDato;

                    // Movemos a pAuxiliar al Nodo Izquierdo
                    pAuxiliar = pAuxiliar -> pIzquierdo;
                }
                else
                {   
                    // No tiene Hijo Izquierdo; Insertamos
                    pAuxiliar->pIzquierdo=pNodoNuevo;

                    // Actualizamos el lado para el Mensaje
                    strcpy(sLado,"Izq");

                    // Salimos del Ciclo
                    break;
                 }
             else
             {
                // Se intenta Insertar un Nodo que ya Existe
                bHuboInsercion = FALSE;

                // Sale del Ciclo
                break;
             }

           // Incrementamos el Nivel
           iNivel++;

       }// Fin del Ciclo While

       // Verifica si Insercion Correcta
       if (bHuboInsercion)
          // Mensaje de Insercion
          printf("Se ha insertado el Dato:%02d como Hijo %s de:%02d en el Nivel:%d \n",xDato,sLado,pAuxiliar->iDato,iNivel);
       else
          // Mensaje de Error
          printf("Error. el Dato:%d ya existe como hijo de:%d en el Nivel:%d \n",xDato,iPadre,--iNivel);

    }
}

// Imprimir N Espacios
void SbEspaciosImprime(int iNumero)
{
   int iCuenta;
   for (iCuenta=0;iCuenta<=iNumero;iCuenta++)
       printf(" ");
}

// Recorre el Arbol
void SbArbolRecorreNivelLado(nodo_arbol *pNodo,int iNivel,char cLado)
{

     // Verifica que no sea Null
     if (pNodo==NULL)
        // Finaliza la Funcion
        return;
     else
     {
        // Imprime los Espacios de acuerdo al Nivel
        SbEspaciosImprime(iNivel*3);

        // Imprime el Contenido del Nodo
        printf("%c-%d Nivel %d \n",cLado,pNodo->iDato,iNivel);

        // Incrementamos el Nivel
        iNivel++;

        // Llama a misma Funcion con el Hijo Izquierdo
        SbArbolRecorreNivelLado(pNodo->pIzquierdo,iNivel,'I');
        SbArbolRecorreNivelLado(pNodo->pDerecho,iNivel,'D');
     }
}


// Cuenta los Nodos del Arbol
int FnIntArbolNodos(nodo_arbol *pNodo)
{

     // Para devolver el Resultado
     int iHijosDerechos=0;
     int iHijosIzquierdos=0;

     // Verifica que no sea Null
     if (pNodo==NULL)
        // Finaliza la Funcion
        return 0;
     else
     {

        // Obtiene los Hijos Derechos
        iHijosDerechos=FnIntArbolNodos(pNodo->pDerecho);

        // Obtiene los Hijos Izquierdos
        iHijosIzquierdos=FnIntArbolNodos(pNodo->pIzquierdo);

        // Retorno el Resultado
        return 1 + iHijosDerechos + iHijosIzquierdos;
     }
}




// Funcion Principal
int main()
{
    // Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 32 - Arboles Binarios Eliminacion \n\n");

    // Declaro el Apuntador a la Raíz.
    nodo_arbol *pRaiz=NULL;

    // Secuencia a Insertar:10,14,2,27,25,31,5,-2,9,----,19,-9,39,49,59
    printf("Creando el Arbol Binario \n");

    // Insertamos la Secuencia
    SbArbolInsertaNodo(&pRaiz,10);
    SbArbolInsertaNodo(&pRaiz,2);
    SbArbolInsertaNodo(&pRaiz,14);
    SbArbolInsertaNodo(&pRaiz,27);
    SbArbolInsertaNodo(&pRaiz,25);
    SbArbolInsertaNodo(&pRaiz,31);
    SbArbolInsertaNodo(&pRaiz,5);
    SbArbolInsertaNodo(&pRaiz,9);
    SbArbolInsertaNodo(&pRaiz,-2);
    SbArbolInsertaNodo(&pRaiz,19);
    SbArbolInsertaNodo(&pRaiz,18);
    SbArbolInsertaNodo(&pRaiz,17);
    SbArbolInsertaNodo(&pRaiz,16);
    SbArbolInsertaNodo(&pRaiz,-9);
    SbArbolInsertaNodo(&pRaiz,39);
    SbArbolInsertaNodo(&pRaiz,49);
    SbArbolInsertaNodo(&pRaiz,59);
    SbArbolInsertaNodo(&pRaiz,13);
    SbArbolInsertaNodo(&pRaiz,12);
    SbArbolInsertaNodo(&pRaiz,11);

    // Desplegamos el Arbol y Nodos
    printf("Desplegando el Arbol y Nodos\n");
    SbArbolRecorreNivelLado(pRaiz,0,'R');
    printf("El Arbol tiene: %d Nodos",FnIntArbolNodos(pRaiz));
    CR;

    // Eliminamos el 59
    FnBoolArbolBinarioEliminaNodo(&pRaiz,59);
    
    // Eliminamos el 17 que tiene un hijo
    FnBoolArbolBinarioEliminaNodo(&pRaiz,17);

    // Eliminamos el 27
    FnBoolArbolBinarioEliminaNodo(&pRaiz,27);

    SbArbolRecorreNivelLado(pRaiz,0,'R');
    printf("El Arbol tiene: %d Nodos",FnIntArbolNodos(pRaiz));
    CR;


    // Eliminamos el 10
    FnBoolArbolBinarioEliminaNodo(&pRaiz,10);


    // Deja una Línea
    CR;

    // Desplegamos el Arbol y Nodos
    printf("Desplegando el Arbol\n");
    SbArbolRecorreNivelLado(pRaiz,0,'R');
    printf("El Arbol tiene: %d Nodos",FnIntArbolNodos(pRaiz));
    CR;


    // Finaliza la aplicacion retornando 0
    return 0;
}
