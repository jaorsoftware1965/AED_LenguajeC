/*
Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE
www.jaorsoftware.com

Clase 11 - Pilas

Una Pila es un Conjunto Ordenado de Elementos en el cual se
pueden agregar y eliminar datos desde un extremo de la
pila, el cual es llamado "el tope" de la pila.

Las Pilas se conocen también como estructuras LIFO (Last-in,
first-out, último en entrar-primero en salir); ya que solo pueden
colocarse o eliminarse nuevos Elementos en el Tope de la Pila;
lo que produce que "el primero elemento en entrar, es el último
en salir"; y viceversa; "el primero en salir, es el último en
entrar".

Se considera que es una Estructura Ordenada de Elementos; porque
en el Orden en que entran los Elementos; es el Orden INVERSO en
el que salen.

Ejemplo
1) Inicializamos la Pila
   PILA ->
2) Inserto el Elemento "A".
   PILA -> A
3) Inserto el Elemento "B".
   PILA -> A, B
4) Inserto el Elemento "Z".
   PILA -> A, B, Z
5) Inserto el Elemento "9"
   PILA -> A, B, Z, 9

Hasta este momento se han insertado 4 Elementos; si los "sacamos"
de la Pila; saldrán en el Orden Inverso en el que entraron.

1) Saco el Elemento en el tope de la Pila:9
   PILA -> A, B, Z
2) Saco el Elemento en el topo de la Pila:Z
   PILA -> A, B
3) Saco el Elemento en el tope de la Pila:B
   PILA -> A
4) Saco el Elemento en el tope de la Pila:A
   PILA ->

Del Proceso anteriormente explicado, podemos deducir que hay
funciones que se realizan en una Pila: Insertar(PUSH) y Sacar
(POP) Elementos de la Pila.

Tambien es deducible que hay un ESTADO que debemos de conocer
y es saber: Si la Pila, está vacía; o cuantos elementos hay
en la Pila; para que cuando sepamos que la Pila está vacía o
que tiene 0 Elementos; entonces no Podemos SACAR elementos;
porque está vacía; ya no hay.

Por lo general; a las Pilas se les establece un TAMAÑO o Número
de elementos que es posible que la PILA tenga. En cuanto se
haya llegado a ese número de Elementos; entonces ya no es posible
agregar un elemento mas; porque la Pila se encuentra llena.

Es importante establecer, cual es el último elemento que se ha
agregado; o sea; el que se encuentra en el tope de la Pila.

Las funciones que deben implementarse para el manejo de una
Pila, son los siguientes:

1) Insertar (PUSH). Inserta un elemento en la Pila.
2) Sacar (POP). Sacar un elemento de la Pila.
3) Pila Vacia. Verificar si la Pila está vacía.
4) Pila Llena. Comprobar si la Pila está llena.
5) Limpiar. Eliminar todos los elementos de la Pila.
6) Elementos. Obtener cuantos elementos hay en la Pila
7) Cima. Obtener el Elemento del Tope de la Pila sin sacarlo.

*/

// Librerias
#include <stdio.h>
#include <stdlib.h>

// Definimos True y False
#define TRUE  1
#define FALSE 0

// Definimos el Tamaño de la Pila
#define PILA_TAMANIO 50

// Definimos la estructura de la Pila
typedef struct stcPila
{
    // Variable para manejar el tope actual de la Pila
    int  iPilaTope;

    // El Arreglo para la Pila
    int arrIntPila[PILA_TAMANIO];

}pila;

// Implementamos Inicializar la Pila
void SbPilaInicializa(pila *pPila);

// Implementamos Verificar si la Pila está vacía
int FnIntPilaVacia(pila *pPila);

// Implementamos Verificar si la Pila está llena
int FnIntPilaLlena(pila *pPila);

// Implementamos Obtener cuantos elementos tiene la Pila
int FnIntPilaElementos(pila *pPila);

// Implementamos desplegar el Elemento de la CIma
void SbPilaCima(pila *pPila);

// Implementamos obtener el Elemento de la CIma sin sacarlo
int  FnIntPilaCima(pila *pPila);

// Implementamos Insertar un Elemento en la Pila
void SbPilaPush(pila *pPila,int iElemento);

// Implementamos Sacar un Elemento de la Pila
int FnIntPilaPop(pila *pPila);


// Función Principal
int main()
{
    // Desplegamos Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 11 - Pilas \n\n");

    // Definimos una variable de pila
    pila xPila;
    int iElemento;

    // Inicializamos la Pila
    SbPilaInicializa(&xPila);

    // Verificamos si la Pila está vacía
    if (FnIntPilaVacia(&xPila))
       printf("La Pila SI está vacía \n");
    else
       printf("La Pila NO está vacía \n");

    // Verificamos si la Pila está llena
    if (FnIntPilaLlena(&xPila)) 
       printf("La Pila SI está llena \n");
    else
       printf("La Pila NO está llena \n");

    // Cuantos Elementos tiene la Pila
    printf("Elementos en la pila:%d \n",FnIntPilaElementos(&xPila));

    // Obtenemos la Cima de la Pila
    SbPilaCima(&xPila);
    printf("\n");

    // Agregamos un Elemento a la Pila
    SbPilaPush(&xPila,34);

    // Verificamos si la Pila está vacía
    if (FnIntPilaVacia(&xPila))
       printf("La Pila SI está vacía \n");
    else
       printf("La Pila NO está vacía \n");

    // Verificamos si la Pila está llena
    if (FnIntPilaLlena(&xPila)) 
       printf("La Pila SI está llena \n");
    else
       printf("La Pila NO está llena \n");

    // Cuantos Elementos tiene la Pila
    printf("Elementos en la pila:%d \n",FnIntPilaElementos(&xPila));


    // Obtenemos la Cima de la Pila
    SbPilaCima(&xPila);
    printf("\n\n");


    // Agregamos un Elemento a la Pila
    SbPilaPush(&xPila,45);

    // Verificamos si la Pila está vacía
    if (FnIntPilaVacia(&xPila))
       printf("La Pila SI está vacía \n");
    else
       printf("La Pila NO está vacía \n");

    // Verificamos si la Pila está llena
    if (FnIntPilaLlena(&xPila)) 
       printf("La Pila SI está llena \n");
    else
       printf("La Pila NO está llena \n");

    // Cuantos Elementos tiene la Pila
    printf("Elementos en la pila:%d \n",FnIntPilaElementos(&xPila));


    // Obtenemos la Cima de la Pila
    SbPilaCima(&xPila);
    printf("\n\n");

    // Sacamos un Elemento de la Pila
    printf("Sacamos de la Pila el Elemento:%d \n",FnIntPilaPop(&xPila));

    // Verificamos si la Pila está vacía
    if (FnIntPilaVacia(&xPila)) 
       printf("La Pila SI está vacía \n");
    else
       printf("La Pila NO está vacía \n");

    // Verificamos si la Pila está llena
    if (FnIntPilaLlena(&xPila)) 
       printf("La Pila SI está llena \n");
    else
       printf("La Pila NO está llena \n");

    // Cuantos Elementos tiene la Pila
    printf("Elementos en la pila:%d \n",FnIntPilaElementos(&xPila));

    // Obtenemos la Cima de la Pila
    SbPilaCima(&xPila);
    printf("\n\n");

    // Agregamos 5 Elementos a la Pila
    SbPilaPush(&xPila,103);
    SbPilaPush(&xPila,104);
    SbPilaPush(&xPila,105);
    SbPilaPush(&xPila,106);
    SbPilaPush(&xPila,107);

    // Verificamos si la Pila está vacía
    if (FnIntPilaVacia(&xPila)) 
       printf("La Pila SI está vacía \n");
    else 
       printf("La Pila NO está vacía \n");

    // Verificamos si la Pila está llena
    if (FnIntPilaLlena(&xPila)) 
       printf("La Pila SI está llena \n");
    else
       printf("La Pila NO está llena \n");

    // Cuantos Elementos tiene la Pila
    printf("Elementos en la pila:%d \n",FnIntPilaElementos(&xPila));

    // Obtenemos la Cima de la Pila
    SbPilaCima(&xPila);
    printf("\n\n");

    // Sacamos un Elemento de la Pila
    printf("Sacamos de la Pila el Elemento:%d \n",FnIntPilaPop(&xPila));
    printf("Sacamos de la Pila el Elemento:%d \n",FnIntPilaPop(&xPila));
    printf("Sacamos de la Pila el Elemento:%d \n",FnIntPilaPop(&xPila));
    printf("Sacamos de la Pila el Elemento:%d \n",FnIntPilaPop(&xPila));
    printf("Sacamos de la Pila el Elemento:%d \n",FnIntPilaPop(&xPila));
    printf("Sacamos de la Pila el Elemento:%d \n",FnIntPilaPop(&xPila));
    printf("\n\n");

    // Verificamos si la Pila está vacía
    if (FnIntPilaVacia(&xPila)) 
       printf("La Pila SI está vacía \n");
    else
       printf("La Pila NO está vacía \n");

    // Verificamos si la Pila está llena
    if (FnIntPilaLlena(&xPila)) 
       printf("La Pila SI está llena \n");
    else
       printf("La Pila NO está llena \n");

    // Cuantos Elementos tiene la Pila
    printf("Elementos en la pila:%d \n",FnIntPilaElementos(&xPila));

    // Obtenemos la Cima de la Pila
    SbPilaCima(&xPila);
    printf("\n\n");

    // Finalizamos
    return 0;
}

// Implementamos Inicializar la Pila
void SbPilaInicializa(pila *pPila)
{
   // Para Inicializa la Pila basta con poner el tope a -1
   // Ya que el primer elemento ocupa la posición 0
   pPila->iPilaTope=-1;

   // Desplegamos Mensaje
   printf("Pila Inicializada ...\n");
}

// Implementamos Verificar si la Pila está vacía
int FnIntPilaVacia(pila *pPila)
{
    if (pPila->iPilaTope==-1)
       return TRUE;
    else
       return FALSE;
}

// Implementamos Verificar si la Pila está llena
int FnIntPilaLlena(pila *pPila)
{
    if (pPila->iPilaTope==PILA_TAMANIO-1)
       return TRUE;
    else
       return FALSE;
}

// Implementamos Obtener cuantos elementos tiene la Pila
int FnIntPilaElementos(pila *pPila)
{
    // Retorna el Tope de la Pila
    return pPila->iPilaTope+1;
}

// Implementamos para Desplegar el Elemento en la Cima
void SbPilaCima(pila *pPila)
{
    // Verificamos si la Pila está vacía
    if (FnIntPilaVacia(pPila))
       printf("La Pila está vacía; no hay elemento Cima\n");
    else
       printf("Pila Cima: %d",pPila->arrIntPila[pPila->iPilaTope]);
}

// Implementamos para Obtener el Elemento en la Cima
int FnIntPilaCima(pila *pPila)
{
    // Verificamos si la Pila está vacía
    if (FnIntPilaVacia(pPila))
       return (-1);
    else
       return(pPila->arrIntPila[pPila->iPilaTope]);
}

// Implementamos Insertar un Elemento en la Pila
void SbPilaPush(pila *pPila,int iElemento)
{
    // Verificamos si la Pila está llena
    if (FnIntPilaLlena(pPila))
       printf("La Pila está llena y no es posible agregar el elemento:%d\n",iElemento);
    else
    {
       // Incrementamos el tope de la pila
       pPila->iPilaTope++;

       // Agrega el Elemento a la Pila
       pPila->arrIntPila[pPila->iPilaTope]=iElemento;

       // Colocamos el dato en la Pila
       //printf("Se ha agregado el elemento %d a la Pila \n",iElemento);
    }
}

// Implementamos Sacar un Elemento de la Pila
int FnIntPilaPop(pila *pPila)
{
    // Verificamos si la Pila está vacía
    if (FnIntPilaVacia(pPila))
    {
       printf("La Pila está vacía no es posible sacar elementos\n");
       return pPila->iPilaTope;
    }
    else
    {

       // Colocamos el dato en la Pila
       //printf("Se ha sacado un elemento de la Pila %d \n",pPila->arrIntPila[pPila->iPilaTope]);
       // Agrega el Elemento a la Pila
       return(pPila->arrIntPila[pPila->iPilaTope--]);
    }

}
