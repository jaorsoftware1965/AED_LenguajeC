/*
Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE
www.jaorsoftware.com
  
Clase 23 - Listas Circulares

Toca el tema ahora a otro tipo de Listas Llamadas Circulares.
El Detalle que hace a una Lista Circular; es que su ultimo
elemento apunta al primer elemento de la Lista; de esta forma
se cierra el circulo; y todos los elementos apuntan a un
elemento siguiente.

Para el Manejo de la Lista Circular; se hace uso únicamente del
Apuntador COLA; el cual apunta al elemento FINAL de la Lista y
desde el cual sabemos que con su apuntador SIGUIENTE; podemos
acceder al Elemento FRENTE de la Lista.

Para las Caracteristicas base de la Lista Circular; el Insertar
un Elemento se realiza en la Parte Frente de la Lista; y la Eliminacion
se realiza en el Final de la Lista; lo cual a este diseño le
dara las caracteristicas de una FILA; es decir; una Estructura
FIFO; donde el Primero en Entrar; es el Primero en Salir.

Ejemplo:
1-2-3-4-5.... El primero en entrar fue el 1 y sera el primero en salir
ya que vamos insertando al final y eliminamos del frente.

INSERTAR CUANDO LA LISTA CIRCULAR ESTa VACiA
-Se crea el Nodo
-Se hace que Cola Apunte a este Nodo
-Se hace que el Nodo Apunte a si mismo (seria igual que a cola)

GRaFICAMENTE

       Cola
        |
        |
      Nodo1
  -->|Val|P|--->
  |            |
  <-------------

 INSERTAR CUANDO LA LISTA CIRCULAR NO ESTa VACiA
 - Se crea el Nodo
 - Este Nuevo Nodo apunta  Cola-pSiguiente que es el frente
 - Cola-pSiguiente apunte al Nuevo Nodo
 - Cola apunta al Nuevo Nodo

      Cola
       |
       |
     Nodo1         NodoNvo
 -->|Val|P|----    |Val|P|
 |            |
 --------------

                      Cola
                       |
                       |P
     Nodo1         NodoNvo
 -->|Val|P|------->|Val|P|--
 |                         |
 ---------------------------

                           Cola
                            |
                            |
      Nodo1               NodoNvo
  -->|Val|P|------------>|Val|P|-->
  |                                |
  ------------------------<--------


ELIMINAR CUANDO LISTA TIENE UN SOLO ELEMENTO
Para saber que es un solo elemento; pCola debe estar
apuntando a si mismo (Cola = Cola-Siguiente); y lo único que se hace
es liberar la memoria; y colocar el Apuntador a NULL.

ELIMINAR CUANDO LISTA TIENE MAS DE UN ELEMENTO.

- Obtenemos la Referencia del Frente a través de la Cola
  con un Apuntador Auxiliar: pAux = pCola-pSiguiente. (Frente)

- Hacemos que pCola-pSiguiente Apunte a pAux-pSiguiente
- pCola-pSiguiente = pCola-Siguiente->pCola-Siguiente
- Liberamos pAux


Aux =  Al 8

                    Cola
                     |
                     |
     Nodo1         NodoNvo
 -->| 8 |P|------->| 9 |P|---
 |                          |
 ----------------------------


   pAux          Cola
    |             |
    |             |
  Nodo1         NodoNvo
 |Val|P|   ---->|Val|P|--
           |            |
           --------------

                                 Cola
                                   |
                   Fte             |
                  Nodo2        NodoNvo
               ----->| 9 |P|----->| 7 |P|---
              |                           |
              ------------------------------

      pAux                       Cola
       |                           |
       |                           |
     Nodo1         Nodo2        NodoNvo
    |Val|P|   ---->|Val|P|----->|Val|P|---
              |                          |
              ----------------------------


DESPLEGAR LA LISTA
El Despliegue de la Lista Circular; se inicia desde
el Frente; y finaliza cuanto la pCola apunta a si
mismo.

INICIALIZAR LA LISTA.
Eliminar todos los Elementos de la Lista.

*/

#include <stdlib.h>
#include <stdio.h>

#define TRUE  1
#define FALSE 0

// Define la Estructura para los Nodos
struct stcNodo
{
   int iDato;
   struct stcNodo *pSiguiente;
};

// Define el tipo de acuerdo a la Estructura
typedef struct stcNodo nodo;


// Funcion para verificar si una Lista Enlazada esta vacia
int FnIntListaVacia(nodo *pCabeza)
{
   // Verifica si esta apuntando a Null
   if (pCabeza==NULL)
   {
      printf("La Lista esta vacia \n");
      return TRUE;
   }
   else
   {
      printf("La Lista no esta vacia \n");
      return FALSE;
   }
}
// Funcion para crear un Nodo
nodo *FnNodoCrea(int xDato)
{
   // Defino una variable de tipo Apuntador Nodo
   nodo *xNodo;

   // Reservo la Memoria para el Nodo
   xNodo = (nodo *)malloc(sizeof(nodo));

   
   // Verifico que haya podido reservar memoria
   if (xNodo == NULL)
      // Despliega el Mensaje de Error
      printf("Error. No se pudo reservar memoria para el Nodo");
   else
   {
      // Asigna la Informacion al Nodo
      xNodo->iDato      = xDato; // El Dato
      xNodo->pSiguiente = NULL;  // Apunta a Null
   }

   //Retorna el resultado
   return xNodo;
}

// Funcion para Insertar un Elemento en el Final
void SbListaCircularInsertar(nodo **pCola, int xDato)
{

    // Definimos un Apuntador a un Nodo
    nodo *pNodoNuevo;

    // Crea un Nuevo Nodo apuntando a Null
    pNodoNuevo=FnNodoCrea(xDato);

    // Verifica si esta vacia ( Mandamos con pCola en lugar de pCabeza)
    if (FnIntListaVacia(*pCola))
    {
        // El Nodo Nuevo apunta a si mismo
        pNodoNuevo->pSiguiente = pNodoNuevo;

        // Cabeza y Cola apuntan a este Primer Nodo
        *pCola=pNodoNuevo;

        // Mensaje
        printf("Insercion al Final con Lista Circular Vacia, el elemento %d en direccion %p \n\n",xDato,pNodoNuevo);
    }
    else
    {

        // Este Nuevo Nodo Sigueinte apunta  Cola-pSiguiente
        pNodoNuevo->pSiguiente = (*pCola)->pSiguiente;

        // Cola-pSiguiente apunte al Nuevo Nodo
        (*pCola)->pSiguiente = pNodoNuevo;

        //- Cola apunta al Nuevo Nodo
        *pCola=pNodoNuevo;

        // Mensaje
        printf("Insercion al Final de la Lista Circular, el elemento %d en direccion %p \n\n",xDato,pNodoNuevo);
    }


}

// Funcion para Eliminar un Elemento en el Frente
nodo FnNodoListaCircularElimina(nodo **pCola)
{

    // Definimos un Apuntador a un Nodo
    nodo *pAux;
    nodo xNodo;

    // Inicializa
    xNodo.iDato=-1;
    xNodo.pSiguiente=NULL;


    // Verifica si esta vacia ( Mandamos con pCola en lugar de pCabeza)
    if (FnIntListaVacia(*pCola))
    {
        // Mensaje
        printf("La Lista Circular esta vacia, no es posible eliminar Elementos \n\n");
    }
    else
    {

        // Verificamos que sea un único elemento
        if (*pCola==(*pCola)->pSiguiente)
        {
           // Obtenemos la informacion del Nodo
           xNodo.iDato      = (*pCola)->iDato;
           xNodo.pSiguiente = (*pCola)->pSiguiente;

           // Hay un solo elemento
           free (*pCola);
           *pCola = NULL;

           printf("Eliminacion del Único elemento en la Fila Circular: %d que apuntaba a:%p \n\n",xNodo.iDato,xNodo.pSiguiente);

        }
        else
        {
           // Hay mas de un Elemento en la Lista Circular
           // Obtenemos la Referencia del Frente a través de la Cola
           // con un Apuntador Auxiliar: pAux = pCola-pSiguiente.
           pAux = (*pCola)->pSiguiente; // EL Frente OJO

           // Obtenemos la informacion del Nodo
           //xNodo.iDato      = pAux->iDato; 
           //xNodo.pSiguiente = pAux->pSiguiente;
           xNodo.iDato      = (*pCola)->pSiguiente->iDato;
           xNodo.pSiguiente = (*pCola)->pSiguiente->pSiguiente;

           // Hacemos que pCola-pSiguiente Apunte a pAux-pSiguiente
           //(*pCola)->pSiguiente = pAux->pSiguiente;//ojo
           (*pCola)->pSiguiente = (*pCola)->pSiguiente->pSiguiente;

           // Liberamos pAux
           free(pAux);

           printf("Eliminacion del Frente de la Fila Circular: %d que apuntaba a:%p \n\n",xNodo.iDato,xNodo.pSiguiente);
        }
    }

    // Retorna el Nodo
    return xNodo;
}


// Funcion para desplegar los Elementos de la Fila Circular
void SbListaCircularDespliega(nodo *pCola)
{
    // Para Contar los Elementos
    char iContar=0;
    nodo *pAuxiliar;

    // Verificamos que esté vacia
    if (FnIntListaVacia(pCola))
    {
       // Mensaje de Lista Vacia
       printf("La Lista Circular se encuentra vacia; no hay valores que desplegar");
    }
    else
    {
        // Primero asigna a pAuxiliar el Primer Elemento;el Frente
        pAuxiliar = pCola->pSiguiente;

        // Desplegando los Elementos de la lista
        printf("Desplegando los Elementos de la Lista ...\n");

        // Ciclo para desplegar los Elementos de la Lista
        while (pCola!=pAuxiliar)
        {
          // Despliega la informacion del Nodo
          printf("Elemento:%d Valor:%d  en direccion:%p que apunta a:%p \n",++iContar,pAuxiliar->iDato,pAuxiliar,pAuxiliar->pSiguiente);

          // Mueve cabeza al siguiente elemento
          pAuxiliar = pAuxiliar->pSiguiente;
        }

        // Despliega la informacion del Nodo Final
        printf("Elemento:%d Valor:%d  en direccion:%p que apunta a:%p \n",++iContar,pAuxiliar->iDato,pAuxiliar,pAuxiliar->pSiguiente);

    }
    // Deja una Linea
    printf("\n");

}

// Funcion para desplegar los Elementos de la Lista Circular
void SbListaCircularInicializa(nodo **pCola)
{
    // Declaro una variable de Nodo
    nodo xNodo;

    // Mensaje
    printf("Eliminando elementos de la Fila Circular ...\n");

    // Ciclo que verifica que la pila no esté vacia
    while (!FnIntListaVacia(*pCola))
    {
        // Llama a la funcion que elimina
        xNodo =  FnNodoListaCircularElimina(pCola);
        //printf("%d %p\n",xNodo.iDato,xNodo.pSiguiente);
    }
    
    // Deja una Linea
    printf("Todos los Elementos de la Lista Circular han sido Eliminados \n\n");
}


// Funcion Principal
int main()
{
    // Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 23 - Listas Circulares \n\n");

    // Apuntadores Cabeza y Cola
    nodo *pCola=NULL;

    // Variable Nodo para Eliminar
    nodo xNodo;

    // Inserta un Elemento
    SbListaCircularInsertar(&pCola,30);

    // Despliega la Lista Circular
    SbListaCircularDespliega(pCola);

    // Elimina
    xNodo = FnNodoListaCircularElimina(&pCola);
    printf("xNodo.iDato      :%d \n",xNodo.iDato);
    printf("xNodo.pSiguiente :%p \n\n",xNodo.pSiguiente);

    // Despliega la Lista Circular
    SbListaCircularDespliega(pCola);

    // Inserta un Elemento
    SbListaCircularInsertar(&pCola,22);

    // Despliega la Lista Circular
    SbListaCircularDespliega(pCola);

    // Inserta un Elemento
    SbListaCircularInsertar(&pCola,40);

    // Despliega la Lista Circular
    SbListaCircularDespliega(pCola);

    // Elimina
    xNodo = FnNodoListaCircularElimina(&pCola);
    printf("xNodo.iDato      :%d \n",xNodo.iDato);
    printf("xNodo.pSiguiente :%p \n\n",xNodo.pSiguiente);

    // Inserta un Elemento
    SbListaCircularInsertar(&pCola,45);

    // Despliega la Lista Circular
    SbListaCircularDespliega(pCola);

    // Elimina
    xNodo = FnNodoListaCircularElimina(&pCola);
    printf("xNodo.iDato      :%d \n",xNodo.iDato);
    printf("xNodo.pSiguiente :%p \n\n",xNodo.pSiguiente);

    // Despliega la Lista Circular
    SbListaCircularDespliega(pCola);

    // Elimina
    xNodo = FnNodoListaCircularElimina(&pCola);
    printf("xNodo.iDato      :%d \n",xNodo.iDato);
    printf("xNodo.pSiguiente :%p \n\n",xNodo.pSiguiente);

    // Despliega la Lista Circular
    SbListaCircularDespliega(pCola);

    //Elimina
    xNodo = FnNodoListaCircularElimina(&pCola);
    printf("xNodo.iDato      :%d \n",xNodo.iDato);
    printf("xNodo.pSiguiente :%p \n\n",xNodo.pSiguiente);

    // Despliega la Lista Circular
    SbListaCircularDespliega(pCola);


    // Inserta un Elemento
    SbListaCircularInsertar(&pCola,40);

    // Inserta un Elemento
    SbListaCircularInsertar(&pCola,50);

    // Inserta un Elemento
    SbListaCircularInsertar(&pCola,60);

    // Despliega la Lista Circular
    SbListaCircularDespliega(pCola);

    // Elimina todos los Elementos
    SbListaCircularInicializa(&pCola);

    // Despliega la Lista Circular
    SbListaCircularDespliega(pCola); // Erroneo

    // Inserta un Elemento
    SbListaCircularInsertar(&pCola,60);


    return 0;

}


