/*
Curso de Algoritmos y Estructura de Datos en C


Clase 01 - Apuntadores.

Un apuntador es una variable que contiene una dirección de memoria. Esta dirección
puede ser la posición de otra variable en la memoria; por este motivo suele decirse
que un apuntador es una variable que apunta a otra variable.

La sintaxis de la declaración de una variable apuntador es:
tipo *nombre_variable_apuntador;

El tipo sirve para conocer el tipo de datos del cual se guardará la dirección de
memoria a la cual "apunta" la variable. Esto es fundamental para poder leer el valor
que almacena la zona de memoria apuntada por la variable puntero y para poder
realizar ciertas operaciones aritméticas sobre los mismos.

El símbolo * sirve para indicar que es una variable apuntador.

Algunos ejemplos de declaración de variables apuntador son:

int   *piContador;   // Apuntador a tipo integer;
char  *pcLetra;      // Apuntador a tipo char;
float *pfDescuento;  // Apuntador a tipo float

Existen dos operadores especiales de los punteros, el operador * y el operador &.
El Operador * ya lo vimos que se utiliza para indicar que una variable es un apuntador.
El Operador & se utiliza para obtener la dirección de una variable de memoria.
Así, si declaramos:

int  iEdad  = 64;  // Variable de Tipo Integer
int *piEdad = &iEdad;     // Apuntador a Integer

int iOtraEdad=0;  // Otra Variable Integer
int *piOtraEdad;  // Otro Apuntador a Integer

Y hacemos:
piEdad = &iEdad;

La variable puntero piEdad contendrá la dirección de memoria de la variable iEdad.
Observe que cuando vamos a asignar la dirección de memoria de iEdad; la variable
apuntador se utiliza sin *.

El operador * tambien es utilizado para obtener el valor de la variable apuntador.
Lo podríamos utilizar de la siguiente forma:


Asignación de punteros.
Es posible asignar el valor de una variable de tipo puntero a otra variable de
tipo puntero.
Para asignar un puntero a otro, se hace directamente; sin operador. Ejemplo:

piOtraEdad = piEdad;

Con la anterior acción piOtraEdad tambien contiene la dirección de piEdad;

*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 01 - Apuntadores \n\n");

    // Variables Integer
    int  iEdad      = 64;
    int  iOtraEdad  = 89;

    // Apuntadores a integer
    int *piEdad     = &iEdad;
    int *piOtraEdad = &iOtraEdad;

    // Desplegamos los valores
    printf("Valores Iniciales\n");
    printf("El valor de iEdad .....................:%d \n",iEdad);
    printf("El valor de iEdad .....................:%c \n",iEdad);
    printf("La Dirección de iEdad .................:%p \n",&iEdad);
    printf("La Dirección en piEdad: ...............:%p \n",piEdad);
    printf("El Valor en la Dirección en piEdad ....:%d \n",*piEdad);
    printf("La Dirección en piOtraEdad.............:%p \n",piOtraEdad);
    printf("El Valor en la Dirección en piOtraEdad.:%d \n\n",*piOtraEdad);


    // Asignamos la Dirección de iEdad a piEdad
    piEdad=&iEdad;

    // Obtenemos la Edad desde el Apuntador
    iOtraEdad = *piEdad;

    // Igualamos los Apuntadores
    piOtraEdad = piEdad;

    printf("Apuntadores Modificados\n");
    printf("El valor de iEdad .....................:%d \n",iEdad);
    printf("La Dirección de iEdad .................:%p \n",&iEdad);
    printf("La Dirección en piEdad: ...............:%p \n",piEdad);
    printf("El Valor en la Dirección en piEdad ....:%d \n",*piEdad);
    printf("La Dirección en piOtraEdad.............:%p \n",piOtraEdad);
    printf("El Valor en la Dirección en piOtraEdad :%d \n\n",*piOtraEdad);

    // Modificamos la Edad
    iEdad = 89;

    printf("Edad Modificada\n");
    printf("El valor de iEdad .....................:%d \n",iEdad);
    printf("El Valor en la Dirección en piEdad ....:%d \n",*piEdad);
    printf("El Valor en la Dirección en piOtraEdad :%d \n\n",*piOtraEdad);

    // Modificamos la Edad
    *piEdad = 90;

    printf("Edad Modificada desde Apuntador \n");
    printf("El valor de iEdad .....................:%d \n",iEdad);
    printf("El Valor en la Dirección en piEdad ....:%d \n",*piEdad);
    printf("El Valor en la Dirección en piOtraEdad :%d \n\n",*piOtraEdad);

    // Modificamos a una dirección que ignoramos
    //piEdad = 90;
    //printf("Dirección Modificada Directamente \n");
    //printf("La Dirección en piEdad: ...............:%p \n",piEdad);

    //
    return 0;
}


