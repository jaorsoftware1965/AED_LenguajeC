/*
Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE
www.jaorsoftware.com

Clase 06 - Arreglos de Punteros.

Es posible definir arreglos y matrices de punteros de la 
siguiente forma:

int  *piEdades[5];
int  *pimatEdades[2][2];

En el primer caso; estamos definiendo un arreglo de punteros 
a enteros y en el segundo caso se esta definiendo una matriz 
de punteros a enteros.

*/

// Librerias
#include <stdio.h>
#include <stdlib.h>

int main()
{
    // Desplegamos Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 06 - Arreglos de Punteros \n\n");

    // Declaramos Variables
    int iEdadMaria=15;
    int iEdadJuan =34;
    int iEdadJesus=45;
    int iEdadJose =24;
    int iEdadSonia=20;

    // Declaramos un vector de apuntadores a integer
    int *piEdades[5];
    piEdades[0]=&iEdadMaria;
    piEdades[1]=&iEdadJuan;
    piEdades[2]=&iEdadJesus;
    piEdades[3]=&iEdadJose;
    piEdades[4]=&iEdadSonia;

    int *pEdad,**ppEdad;

    // Despleando los valores del Vector de Apuntadores
    printf("Valores Iniciales\n");
    printf("El Valor-Dirección de piEdades[0] : %p\n",piEdades[0]);
    printf("El Valor-Contenido de piEdades[0] : %d\n",*piEdades[0]);
    printf("El Valor-Dirección de piEdades[1] : %p\n",piEdades[1]);
    printf("El Valor-Dirección de piEdades[1] : %d\n",*piEdades[1]);
    printf("El Valor-Dirección de piEdades[2] : %p\n",piEdades[2]);
    printf("El Valor-Contenido de piEdades[2] : %d\n",*piEdades[2]);
    printf("El Valor-Dirección de piEdades[3] : %p\n",piEdades[3]);
    printf("El Valor-Dirección de piEdades[3] : %d\n",*piEdades[3]);
    printf("El Valor-Dirección de piEdades[4] : %p\n",piEdades[4]);
    printf("El Valor-Contenido de piEdades[4] : %d\n\n",*piEdades[4]);

    printf("Valores Referenciados\n");
    iEdadJuan =57;
    printf("El Valor-Dirección de piEdades[1] desde piEdades[0] : %p\n",piEdades[0]-1);
    printf("El Valor-Contenido de piEdades[1] desde piEdades[0] : %d\n\n",*(piEdades[0]-1));

    pEdad = &piEdades;
    ppEdad = &piEdades;

    printf("Valores Referenciados por apuntador de apuntadores\n");
    printf("El Valor-Dirección de piEdades[0] pEdad  : %p\n",*(pEdad+1));
    printf("El Valor-Dirección de piEdades[0] pEdad  : %d\n",*(int *)*(pEdad+1));
    printf("El Valor-Dirección de piEdades[0] ppEdad : %p\n",*(ppEdad+1));
    printf("El Valor-Dirección de piEdades[0] ppEdad : %d\n\n",**(ppEdad+1));

    // Definimos matriz de Apuntadores
    int *pimatEdades[2][2];
    pimatEdades[0][0]=&iEdadMaria; //15
    pimatEdades[0][1]=&iEdadJose;  //24
    pimatEdades[1][0]=&iEdadJesus; //45
    pimatEdades[1][1]=&iEdadJuan;  //57

    pEdad = &pimatEdades;
    ppEdad = &pimatEdades;

    printf("Valores de la Matriz \n");
    printf("El Valor de pimatEdades[0][0] desde pEdad  : %p\n",  pimatEdades[0][0]);
    printf("El Valor de pimatEdades[0][1] desde pEdad  : %p\n",  pimatEdades[0][1]);
    printf("El Valor de pimatEdades[1][0] desde pEdad  : %p\n",  pimatEdades[1][0]);
    printf("El Valor de pimatEdades[1][1] desde pEdad  : %p\n\n",pimatEdades[1][1]);

    printf("El Valor de pimatEdades[0][0] desde pEdad  : %d\n",  *pimatEdades[0][0]);
    
    printf("El Valor de pimatEdades[0][0] desde pEdad  : %p\n",    pimatEdades[0][0]-1);
    printf("El Valor de pimatEdades[0][0] desde pEdad  : %d\n",  *(pimatEdades[0][0]-1));
    
    printf("El Valor de pimatEdades[0][1] desde pEdad  : %d\n",  *pimatEdades[0][1]);
    printf("El Valor de pimatEdades[1][0] desde pEdad  : %d\n",  *pimatEdades[1][0]);
    printf("El Valor de pimatEdades[1][1] desde pEdad  : %d\n\n",*pimatEdades[1][1]);

    printf("Valores Referenciados por apuntador de apuntadores\n");
    printf("El Valor de pimatEdades[0][0] desde pEdad  : %d\n",  *(int *)*(pEdad+0));
    printf("El Valor de pimatEdades[0][1] desde pEdad  : %d\n",  *(int *)*(pEdad+1));
    printf("El Valor de pimatEdades[1][0] desde pEdad  : %d\n",  *(int *)*(pEdad+2));
    printf("El Valor de pimatEdades[1][1] desde pEdad  : %d\n\n",*(int *)*(pEdad+3));

    printf("El Valor de pimatEdades[0][0] desde ppEdad : %d\n",  **(ppEdad+0));
    printf("El Valor de pimatEdades[0][1] desde ppEdad : %d\n",  **(ppEdad+1));
    printf("El Valor de pimatEdades[1][0] desde ppEdad : %d\n",  **(ppEdad+2));
    printf("El Valor de pimatEdades[1][1] desde ppEdad : %d\n\n",**(ppEdad+3));

    // Ejercicio
    for (int i=0; i<5; i++)     
    {   
        printf("Direccion de Almacenaje: %p \n", &piEdades[i]);         
        printf("Contenido de arreglo   : %p \n", piEdades[i]);         
        printf("Contenido apunta       : %d\n\n", *piEdades[i]);     
    }

    for (int i=0; i<2; i++)     
        for (int j=0; j<2; j++)   
        {
            printf("Direccion de Almacenaje: %p \n", &pimatEdades[i][j]);         
            printf("Contenido de arreglo   : %p \n",  pimatEdades[i][j]);         
            printf("Contenido apunta       : %d\n\n",*pimatEdades[i][j]);     
        }
     
    return 0;
}
