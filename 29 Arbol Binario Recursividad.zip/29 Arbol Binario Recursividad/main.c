/*
Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE
www.jaorsoftware.cu.cc

Clase 29- Árboles Binarios Recursividad

Recursividad. Es la capacidad que tiene una función
de llamarse a si misma. Lo anterior significa que
dentro de la función existirá una o mas llamadas
a la misma función.

¿Cuando Usar Recursividad?
Cuando existe un Proceso Repetitivo; que una misma
función puede hacer.

Juan va a contar las Sillas de un Cuarto.

FnJuanCuentaSillas(Salón1) = 4 + FnJuanCuentaSillas(Salón2) = 
                             4 + 18

FnJuanCuentaSillas(Salón2) = 5 + FnJuanCuentaSillas(Salón3) = 
                             5 + 13

FnJuanCuentaSillas(Salón3) = 7 + FnJuanCuentaSillas(Salón4) = 
                             7 + 6

FnJuanCuentaSillas(Salón4) = 2 + FnJuanCuentaSillas(Salón5) = 
                             2 + 4

FnJuanCuentaSillas(Salón5) = 4

  Salón1   Salón2   Salón3  Salón4  Salón5
  --------------------------------------------
| h      |  h h   | h h h | h h    | h h h |
| h h    |  h h   | h h h |        | h     |
  h      }  h     } h     }        }       |
--------------------------------------------
                                    

Factorial de un Número
!5 = 5 X 4 X 3 X 2 X 1
!4 =     4 X 3 X 2 X 1
!3 =         3 X 2 X 1
!2 =             2 X 1
!1 =                 1
!0 =                 1

Podemos Expresarlo Recursivamente así:
!5 = 5 x !4
!4 = 4 X !3
!3 = 3 x !2
!2 = 2 x !1
!1 = 1

Veamos un Ejemplo Real
Gustavo es una persona a la que se le pregunta cual es el factorial de un Número
y el solo sabe contestar el resultado EXACTO, cuando se le pregunta cual es
el Factorial de 1 o de 0; a lo cual contesta que es 1.

Para todas las demás respuestas Gustavo siempre contesta; que el Factorial del
Número que le indicas es ese mismo Número multiplicado por el Factorial del
Numero menor que le siga; es decir de Numero-1.

FnGustavoFactorial(5)=5 x FnGustavoFactorial(4) = 5 x 24 = 120
FnGustavoFactorial(4)=4 x FnGustavoFactorial(3) = 4 x 6 = 24
FnGustavoFactorial(3)=3 x FnGustavoFactorial(2) = 3 x 2 = 6
FnGustavoFactorial(2)=2 x FnGustavoFactorial(1) = 2 x 1 = 2
FnGustavoFactorial(1)=1

Con una Función Podemos Expresarlo Así:
FnFactorial(5)= 5 x FnFactorial(4); = 5 x 24 = 120
FnFactorial(4)= 4 x FnFactorial(3); = 4 x 6 = 24
FnFactorial(3)= 3 x FnFactorial(2); = 3 x 2 = 6
FnFactorial(2)= 2 x FnFactorial(1); = 2 x 1 = 2
FnFactorial(1)= 1;


*/
// Librerias
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

// Define el Cambio de Línea
#define CR printf("\n")

// Función Factorial
int FnIntFactorial(int xDato)
{
   // Variable de Resultado
   int iResult=0;

   printf("Resolviendo factorial de:%d\n",xDato);

   // Verificamos que sea 0 o 1
   if (xDato==0 || xDato==1)
   {
      // retorna 1; aqui finaliza la recursividad
      iResult = 1;
      printf("Factorial de %d es : %d \n",xDato,iResult);      
   }
   else
   {
      iResult = xDato * FnIntFactorial(xDato-1);
      printf("Factorial de %d es : %d \n",xDato,iResult);      
   }

   // Se llama así mismo con el xDato-1
   return iResult;
}

// Función Factorial
void FnIntFactorial2(int xDato, int valorPrevio)
{
   // Variable de Resultado
   int iResult=0;
   
   // Verificamos que sea 0 o 1
   if (xDato==0 || xDato==1)
   {
      // retorna 1; aqui finaliza la recursividad
      iResult = 1 * valorPrevio;
      printf("%d\n",iResult);      
   }
   else
   {
      FnIntFactorial2(xDato-1,xDato*valorPrevio);      
   }
}

void fnSumarDigitosEnCadena(char cadena[],int valorPrevio)
{
   // Variables
   int resultado = 0;
   char aux[20];
   int lonCad;
   //static int llamada=0;
   //printf("Llamada %d cadena:%s\n", ++llamada, cadena);
   

   // Obtenemos la longitud de la cadena
   lonCad = strlen(cadena);

   // Verificamos si es un solo digito
   if (lonCad==1)
   {
      // Ejemplo: "9"
      // Obtenemos el Resultado 
      resultado = cadena[0] - 48;
      resultado = resultado + valorPrevio;      

      // Mensaje   
      printf("La Suma de la Cadena es:%d\n",resultado);
   }
   else
   {
      // Ejemplo "980987"      
      resultado = cadena[lonCad-1] - 48;

      // Obtener la subcadena
      strncpy(aux,cadena,lonCad-1);
      aux[lonCad-1]='\x0';

      // Llamo la recursividad
      fnSumarDigitosEnCadena(aux,resultado+valorPrevio);
   }
}

// Función Principal
int main()
{
    
   //  // Mensaje de la Clase
   //  printf("Curso de Algoritmos y Estructuras de Datos en C \n");
   //  printf("Clase 29 - Árboles Binarios Recursividad \n\n");

   //  // Imprime el Mensaje y llama a la función
   FnIntFactorial(8);

   //fnSumarDigitosEnCadena("987",0);
   printf("Factorial de 5 es:\n");
   FnIntFactorial2(8,1);


    // Finaliza la aplicación retornando 0
    return 0;
}



