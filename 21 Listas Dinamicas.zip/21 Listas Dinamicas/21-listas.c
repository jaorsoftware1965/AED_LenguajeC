/*
Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE
www.jaorsoftware.com

Clase 21 - Listas Enlazadas

La Definición más sencilla de una Lista Enlazada, es decir simplemente
que es una Estructura Dinámica de Datos. Punto.

Una Lista Enlazada es una colección o secuencia de elementos
dispuestos uno detrás de otro, en la que cada elemento se conecta
al siguiente por un «enlace» o «puntero». A cada uno de estos
elementos se le conoce como NODO.

Cada uno de estos elementos esta compuesto de 2 partes:
Una parte corresponde al Valor o información del Nodo, y la
otra es un apuntador que apunta al siguiente elemento de la lista.

El Primer NODO de la lista se le conoce como el NODO FRENTE; y
para IDENTIFICARLO se utiliza un apuntador el cual
es conocido como CABEZA.

El Último NODO de la lista se el conoce como el NODO FINAL; y
para identificarlos se utiliza un apuntador el cual es conocido
como COLA. Este apuntador, NO es indispensable; y en algunos
textos al respecto del tema, no se hace mencion a el. Para
esta primera aplicación nosotros no lo utilizaremos.

Cuando una lista no tiene elementos, se le conoce como
Lista Vacía o Lista Nula.

Cuando un Nodo de la lista es el ultimo; es decir que no
tiene Siguiente; su apuntador vale o apunta a NULL.
Cuando veamos la aplicación, veremos que el Lenguaje despliega
la palabra "nil").

A diferencia de los Arreglos, los NODOS de una lista, no se encuentran
en Memoria Consecutiva; sino de acuerdo a como se vayan creando
y a la memoria disponible.

GRÁFICAMENTE

     Cabeza                                          Cola
       |                                               |
       |                                               |
      Val  P      Val  P      Val  P      Val  P      Val  P
     |Info|-|--->|Nodo|-|--->|Nodo|-|--->|Nodo|-|--->|Nodo|-|---> nil
     --Nodo--

OPERACIONES CON LISTAS.

Inserción o Eliminación
A diferencia de las PILAS y las FILAS; las Listas Enlazadas no
tienen un orden especifico para Insertar o Eliminar Elementos.
Los Elementos pueden ser insertados o eliminados al Final; al Frente;
o en cualquier otro lugar de la Lista. Para este caso; nosotros
implementaremos la Inserción y Eliminación por el Frente; lo cual
hará que la Lista se comporte como una FILA; es decir; siguiendo
la lógica FIFO; First In First Out; Primero en Entrar; Primero en Salir.

Para insertar un Elemento como Frente en la Cabeza de la Lista,
simplemente se hace que el Nuevo elemento apunte a donde Cabeza
se encuentre apuntando; y que Cabeza apunte al Nuevo Elemento.

     Cabeza                                          Cola
       |                                               |
       |                                               |
      Val  P      Val  P      Val  P      Val  P      Val  P
     |  5  |-|--->|Nodo|-|--->|Nodo|-|--->|Nodo|-|--->|Nodo|-|--->nil

  Cabeza                                          Cola
    |                                              |
    |                                              |
  Val P      Val  P      Val  P      Val  P      Val  P      Val  P
 |Nvo|-|--->|  5 |-|--->|Nodo|-|--->|Nodo|-|--->|Nodo|-|--->|Nodo|-|--->nil


Para eliminar un Elemento como Frente, de la Cabeza de la lista,
simplemente se hace que Cabeza apunte al siguiente elemento al
que apuntaba el elemento que estaba apuntando; y se debe de liberar
la memoria del Nodo eliminado.

        Cabeza                                          Cola
       |                                               |
                  |                                               |
      Val  P      Val  P      Val  P         Val  P      Val  P
     |72|-|--->|27|-|--->|25|-|--->nill   |Nodo|-|--->|Nodo|-|--->nil

                  Cabeza                               Cola
                    |                                   |
      free          |                                   |
      Val  P      Val  P      Val  P      Val  P      Val  P
     |Nodo|-|    |Nodo|-|--->|Nodo|-|--->|Nodo|-|--->|Nodo|-|--->nil



Recorrido de la Lista.
El Recorrido de la Lista del Frente al Final; se realizará iniciando
por el Elemento que apunta Cabeza; y de este se obtiene el Siguiente;
y así sucesivamente hasta que siguiente apunte a NULL

Buscar un Elemento.
Realiza una busqueda de un Elemento en la lista de acuerdo a su
información. Utiliza la misma lógica de Recorrido; solo que hace una
comparación con respecto al elemento que se encuentra buscando.

En base a toda la anterior información; para poder Implementar una
Lista Enlazada; necesitaremos lo siguiente:

Nodo.
Una Estructura para definir el nodo, en el cual se establezca el
tipo de información que va a manejar y el apuntador al nodo
siguiente.

Cabeza.
Un apuntador que apunte al Primer Elemento o Frente de la Lista.

ListaVacia(). Función para verificar que una lista está vacía

CrearNodo(). Función para crear un Nodo

Insertar(). Función para insertar un Elemento como Frente.

Eliminar(). Función para Eliminar un Elemento que está como Frente.

Recorrido(). Esta función desplegará los elementos de la Lista
del Frente al Final y devolverá la cantidad de nodos.

Busca(). Busca un Elemento en la Lista.

*/

// Librerias
#include <stdlib.h>
#include <stdio.h>

// Constantes
#define TRUE  1
#define FALSE 0

// Define la Estructura para los Nodos
struct stcNodo
{
   int iDato;
   struct stcNodo *pSiguiente;
};

// Define el tipo de acuerdo a la Estructura
typedef struct stcNodo nodo;

// Función para verificar si una Lista Enlazada está vacía
int FnIntListaVacia(nodo *pCabeza)
{
   // Verifica si está apuntando a Null
   if (pCabeza==NULL)
   {
      printf("La Lista está vacía \n");
      return TRUE;
   }
   else
   {
      printf("La Lista no está vacía \n");
      return FALSE;
   }
}

// Función para crear un Nodo
nodo *FnNodoCrea(int xDato)
{
   // Defino una variable de tipo Apuntador Nodo
   nodo *xNodo;

   // Reservo la Memoria para el Nodo
   xNodo = (nodo *)malloc(sizeof(nodo));

   
   // Verifico que haya podido reservar memoria
   if (xNodo == NULL)
      // Despliega el Mensaje de Error
      printf("Error. No se pudo reservar memoria para el Nodo");
   else
   {
      // Asigna la Información al Nodo
      xNodo->iDato      = xDato; // El Dato
      xNodo->pSiguiente = NULL;  // Apunta a Null
   }

   //Retorna el resultado
   return xNodo;
}


// Función para Insertar un Elemento en la Lista
void SbListaInsertar(nodo **pCabeza, int xDato)
{
    // Definimos un Apuntador a un Nodo
    nodo *pNodoNuevo;

    // Crea un Nuevo Nodo apuntando a Null
    pNodoNuevo = FnNodoCrea(xDato);

    // Verifica si está vacía
    if (FnIntListaVacia(*pCabeza))
    {
       // Cabeza apunta a este Primer Nodo
       *pCabeza = pNodoNuevo;

       // Mensaje
       printf("Se ha Insertado el elemento %d en el frente estando la Lista Vacía \n\n",xDato);
    }
    else
    {
       // Hacemos que el Nuevo Nodo apunte al Primer Elemento que es el que apunta Cabeza
       pNodoNuevo->pSiguiente = *pCabeza;

       // Hacemos que Cabeza apunte al Nuevo Nodo
       *pCabeza = pNodoNuevo;

       // Mensaje
       printf("Se ha Insertado el elemento %d en el frente de la Lista \n\n",xDato);
    }


}


// Función para desplegar los Elementos
nodo FnNodoListaElimina(nodo **pCabeza)
{
    // Nodo a Retornar
    nodo xNodo;
    nodo *pNodoEliminar;

    // Inicializa el Nodo
    xNodo.iDato=-1;
    xNodo.pSiguiente=NULL;

    // Verifica que no esté vacía
    if(FnIntListaVacia(*pCabeza))

      // Despliega la información del Nodo
      printf("La Lista está vacía; no hay elementos para eliminar \n\n");

    else
    {
      // Obtengo la Información del dato a Eliminar
      pNodoEliminar = *pCabeza;

      // Obtener la Información del Nodo a Eliminar
      xNodo.iDato      = pNodoEliminar->iDato;
      xNodo.pSiguiente = pNodoEliminar->pSiguiente;

      // Libero la Memoria del NODO a eliminar
      free(pNodoEliminar);

      // Despliega la información del Nodo
      printf("Se eliminó Elemento:%d en dirección:%p que apuntaba a dirección:%p \n\n",xNodo.iDato,pNodoEliminar,xNodo.pSiguiente);

      // Mueve cabeza al siguiente elemento
      //*pCabeza = (*pCabeza)->pSiguiente;
      *pCabeza = xNodo.pSiguiente;

    }

    // Retorna el Nodo
    return (xNodo);

}


// Función para desplegar los Elementos
void SbListaDespliega(nodo *pCabeza)
{
    // Para Contar los Elementos
    char iContar=0;

    // Desplegando los Elementos de la lista
    printf("Desplegando los Elementos de la Lista ...\n");

    // Ciclo para desplegar los Elementos de la Lista
    while (pCabeza!=NULL)
    {
      // Despliega la información del Nodo
      printf("Elemento:%d Valor:%d  en dirección:%p que apunta a:%p \n",++iContar,pCabeza->iDato,pCabeza,pCabeza->pSiguiente);

      // Mueve cabeza al siguiente elemento
      pCabeza = pCabeza->pSiguiente;
    }

    // Deja una Línea
    printf("\n");

}

// Función para Buscar un Elementos
int FnIntListaBuscaNodo(nodo *pCabeza,int xDato)
{
    // Variable para Contar
    char iContar=0;

    // Variable para el Resultado
    int iResult = FALSE;

    // Desplegando los Elementos de la lista
    printf("Buscando Elemento en la Lista ...\n");

    // Ciclo para desplegar los Elementos de la Lista
    while (pCabeza!=NULL)
    {
      // Incrementa el contador
      iContar++;

      // Verificamos que tenga el Elemento a buscar
      if (pCabeza->iDato==xDato)
      {
         // Asigna que lo ha encontrado
         iResult=TRUE;

         // Rompe el Ciclo
         break;

      }
      else
        // Mueve cabeza al siguiente elemento
        pCabeza = pCabeza->pSiguiente;

    }

    // Verifica si lo encontró
    if (iResult)
       printf("El Elemento fue encontrado en la posición: %d \n",iContar);
    else
       printf("El Elemento NO fue encontrado \n",iContar);

    // Deja una Línea
    printf("\n");

}

// Función Principal
int main()
{
    // Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 21 - Listas Enlazadas \n\n");

    // Variable Nodo para Eliminar
    nodo xNodo;

    // Apuntadores CABEZA
    nodo *pCabeza=NULL;
    printf("El tamaño en bytes de pCabeza:%d \n\n",sizeof(pCabeza));

    // Inserta un Elemento en la Lista
    SbListaInsertar(&pCabeza,20);

    // Despliega la Lista
    SbListaDespliega(pCabeza);

    // Elimina el Único Elemento
    xNodo = FnNodoListaElimina(&pCabeza);

    // Despliega la Lista
    SbListaDespliega(pCabeza);

    // Inserta un Elemento en la Lista
    SbListaInsertar(&pCabeza,25);

    // Despliega la Lista
    SbListaDespliega(pCabeza);

    // Inserta un Elemento en la Lista
    SbListaInsertar(&pCabeza,27);

    // Despliega la Lista
    SbListaDespliega(pCabeza);

    // Inserta un Elemento en la Lista
    SbListaInsertar(&pCabeza,72);

    // Despliega la Lista
    SbListaDespliega(pCabeza);

    // Buscando un Elemento
    FnIntListaBuscaNodo(pCabeza,72);


    // Elimina un Elemento
    FnNodoListaElimina(&pCabeza);

    // Elimina el Único Elemento
    xNodo = FnNodoListaElimina(&pCabeza);

    // Imprimir la información de xNodo
    printf("xNodo  ==> %d %p \n",xNodo.iDato,xNodo.pSiguiente);

    // Elimina el Único Elemento
    xNodo = FnNodoListaElimina(&pCabeza);

    // Imprimir la información de xNodo
    printf("xNodo  ==> %d %p \n",xNodo.iDato,xNodo.pSiguiente);

    // Elimina el Único Elemento
    xNodo = FnNodoListaElimina(&pCabeza);


    // Finaliza
    return 0;

}
