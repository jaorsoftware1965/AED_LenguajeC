/*
Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE


Clase 05 - Apuntadores void y NULL

Existen dos tipos de punteros especiales muy utilizados en 
el tratamiento de los programas en C y que son los punteros 
void y null (nulo).

Es posible tambien declarar un apuntador al "tipo" void.

Un puntero nulo no apunta a ninguna parte -dato válido- 
en particular, es decir, «un puntero nulo no direcciona 
ningún dato válido en memoria». 

Un puntero nulo se utiliza para proporcionar a un
programa un medio de conocer cuando una variable puntero 
no direcciona a un dato válido.

Para declarar un puntero nulo se utiliza la macro NULL, 
definida en los archivos de cabecera STDEF.H ,STDIO.H, 
STDLIB.H y STRING.H. 

Se debe incluir uno o más de estos archivos de cabecera
antes de que se pueda utilizar la macro NULL .

Ahora bien, se puede definir NULL en la parte superior 
de su programa ( o en un archivo de cabecera personal) 
con la línea

#define NULL O

Una forma de inicializar una variable puntero a nulo es:
char *p = NULL;

Algunas funciones C también devuelven el valor NULL si se 
encuentra un error; en las cuales es posible utilizar este 
valor NULL para verificar un resultado.

Se pueden realizar comparaciones con el valor NULL para 
averiguar si una función o proceso ha fallado .

if (p != NULL) . . .

Otra forma de declarar un puntero nulo es asignar un valor 
de O. Por ejemplo, int *ptr = (int *) 0;

El modelo (casting) anterior, variable puntero, no es necesario, 
ya que hay una conversión estándar de O a una variable puntero.

int *ptr = O ;

*/

// Incluimos libreria
#include <stdio.h>
#include <stdlib.h>

int main()
{
    // Desplegamos Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 05 - Apuntadores void y NULL \n\n");

    // Apuntador a void
    void *pvApuntador;
    char  cLetra  = 'A',*pcLetra;
    int   iDigito =  8, *piDigito;

    // Apuntador le paso la dirección de una variable char
    pvApuntador = &cLetra;
    printf("Apuntadores a void\n");
    printf("1) La dirección a que apunta pvApuntador..:%p\n",pvApuntador);
    printf("1a) La dirección a que apunta pvApuntador..:%c\n",*(char *)pvApuntador);
    printf("2a) La dirección a que apunta pvApuntador..:%d\n",*(char *)pvApuntador);
    
    // Paso el Apuntador void al Apuntador CHar
    pcLetra = pvApuntador;
    printf("2) La Direccion de pcLetra  .......:%p\n",pcLetra);
    printf("3) El Valor de pcLetra      .......:%c\n\n",*pcLetra);

    // HAgo qu ele Apuntador void apunte a integer
    pvApuntador = &iDigito;
    printf("4) La dirección a que apunta pvApuntador..:%p\n",pvApuntador);
    
    piDigito = pvApuntador;
    printf("5) La direccion de piDigito             ..:%p\n",piDigito);
    printf("6) El valor de piDigito  ............  ...:%d\n\n",*piDigito);

    // Colocando el Valor de Null
    pvApuntador = NULL;
    printf("7) La direccion a que apunta pvApuntador ..:%p\n",pvApuntador);

    if (pvApuntador == NULL)
       printf("8) Sin apuntar \n");

    int *ptr1 = (int *) 1235679;
    //printf("x) El Contenido en Integer de la direccion 0:%p\n", ptr1);
    //printf("x) El Contenido en Integer de la direccion 0:%d\n",*ptr1);
    //*ptr1 = 1;
    printf("x) El Contenido en Integer de la direccion 1:%p\n", ptr1);
    printf("x) El Contenido en Integer de la direccion 1:%d\n",*ptr1);
    if (ptr1 == NULL)
       printf("9) Sin apuntar ptr1 \n");


    int *ptr2 = 0;
    if (ptr2 == NULL)
       printf("A) Sin apuntar ptr2 \n");

    return 0;    
}


