/*
Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE
www.jaorsoftware.com

Clase 22 - Listas Enlazadas II

Para esta clase, veremos como podemos Implementar el Poder Insertar
y Eliminar Elementos, al Final de la Lista, y en Medio de la Lista.
Para poder hacer esto agregaremos el apuntador COLA; el cual
apuntará al elemento Final de la Lista

Nota.Sólo puede insertarse un elemento después de cierto nodo,
no antes de él. Esto se debe a que no hay un modo de avanzar
de un cierto nodo a su predecesor en una lista lineal,
sin tener que recorrer la lista desde el principio.


INSERTAR AL FINAL DE LA LISTA ENLAZADA.

Antes de Insertar al Final, hay que aclarar que cuando la Lista
enlazada esté vacía y se inserte el Primer Elemento; el apuntador
COLA apuntará a este, al igual que CABEZA

Para insertar al Final, lo que tenemos que hacer es primeramente
crear el Nodo; posteriormente; hacer que el Nodo al que esta
apuntando Cabeza, o sea; el Final; su pSiguente apunte a este nuevo
Nodo; y finalmente que COLA; tambien apunte a este Nuevo Nodo.


GRÁFICAMENTE

  Cabeza                                      Cola
    |                                           |
    |                                           |
 |Val|P|--->|Val|P|--->|Val|P|--->|Val|P|--->|Val|P|--->nil

GRÁFICAMENTE

  Cabeza                                                 Cola
    |                                                     |
    |                                                     |
 |Val|P|--->|Val|P|--->|Val|P|--->|Val|P|--->|10|P|--->|Val|P|--->nil


INSERTAR EN MEDIO DE LA LISTA ENLAZADA.

Para insertar en medio de la Lista Enlazada, nos moveremos a través de la
Lista con CABEZA; el cual pasaremos por valor; hasta que encontremos
el Elemento o la Posición en la cual queremos insertar el Nuevo Elemento.

Una vez que ya lo encontramos; verificamos que SEA EL ULTIMO; y de ser
así entonces llamamos a INSERTAR FINAL.

Si no es el último, entonces; creamos el Nodo Nuevo; hacemos que apunte
a donde esta el Nodo encontrado que indica la posición a insertar; y a
este mismo nodo encontrado lo hacemos que apunte al Nuevo Nodo.


GRÁFICAMENTE
                                |89|P
                      Cabeza    |   |            Cola
                         |      |   |             |
                         |      |   |             |
 |Val|P|--->|Val|P|--->|5|P|--->|    |200|P|--->|Val|P|--->nil
 

GRÁFICAMENTE insertamos despues del 2

            Cabeza                                        Cola
               |                                           |
               |                                           |
  Nodo1      Nodo2     NodoNvo     Nodo3      Nodo4      Nodo5      Nodo6
 |Val|P|--->|Val|P|--->|Val|P|--->|Val|P|--->|Val|P|--->|Val|P|--->|Val|P|--->nil


NodoNuevo --> Cabeza-->PSiguiente es decir a 3
pCabeza-->pSiguiente-->NodoNuevo

ELIMINAR AL FINAL DE LA LISTA ENLAZADA.

- Para Eliminar al Final de la Lista, debemos de ir Moviendo el
  Apuntador Cabeza, hacia adelante; hasta que encontremos un
  NODO el cual su apuntador Siguiente, apunte a la misma dirección
  que COLA. Una vez que lo hayamos encontrado:
- Liberaremos la Memoria de COLA
- Haremos que COLA apunte  al NODO que apuntaba CABEZA
- Y haremos que este NODO su Apuntador pSiguiente apunte a NULL.

GRÁFICAMENTE

  Cabeza                                      Cola
    |                                           |
    |                                           |
  Nodo1      Nodo2      Nodo3      Nodo4      Nodo5
 |Val|P|--->|Val|P|--->|Val|P|--->|Val|P|--->|Val|P|--->nil

                                   Cabeza      Cola
                                     |          |
                                     |          |
  Nodo1      Nodo2      Nodo3      Nodo4      Nodo5
 |Val|P|--->|Val|P|--->|Val|P|--->|Val|P|--->|Val|P|--->nil

                                   Cola
                                     |
                                     |             free
  Nodo1      Nodo2      Nodo3      Nodo4           Nodo5
 |Val|P|--->|Val|P|--->|Val|P|--->|Val|P|--->nil  |Val|P|


ELIMINAR EN MEDIO DE LA LISTA ENLAZADA.

Para Eliminar en medio de la Lista, debemos de ir Moviendo el
Apuntador Cabeza, hacia adelante; hasta que encontremos el NODO
que queremos Eliminar; y deberemos de ir guardando la dirección
del anterior nodo. Como es posible que modifiquemos la dirección
de Cabeza, utilizaremos un Apuntador ACTUAL para movernos a través
de la Lista.

Hay Varias Circunstancias para este caso

a) Cuando hay un Solo elemento
   Simplemente se libera la Memoria y Cabeza y Cola apuntan a NULL
b) Cuando el elemento a Eliminar es el Final; se realiza el método
   ya visto anteriormente
c) Cuando el elemento a Eliminar está en el frente; se realiza lo
   ya visto en la clase anterior.
d) Cuando el Elemento no es único; no está al final y no está al
   frente.


GRÁFICAMENTE

  Cabeza                                      Cola
    |                                           |
    |                                           |
  Nodo1      Nodo2      Nodo3      Nodo4      Nodo5
 |Val|P|--->|Val|P|--->|Val|P|--->|Val|P|--->|Val|P|--->nil


GRÁFICAMENTE deseamos eliminar el Nodo 3

  Cabeza    Anterior    Actual                Cola
    |          |          |                     |
    |          |          |                     |
  Nodo1      Nodo2      Nodo3      Nodo4      Nodo5
 |Val|P|--->|Val|P|--->|Val|P|--->|Val|P|--->|Val|P|--->nil

Siplemente tenemos que hacer que:
Anterior->pSiguiente apunte a Actual->pSiguiente
free(Actual);


GRÁFICAMENTE deseamos eliminar el Nodo 3

  Cabeza    Anterior               Cola
    |          |                    |
    |          |                    |  
 |Val|P|--->|Val|P|--->|Val|P|--->|Val|P|--->|Val|P|--->nil


*/

// Librerias
#include <stdlib.h>
#include <stdio.h>

// Constantes
#define TRUE  1
#define FALSE 0

// Define la Estructura para los Nodos
struct stcNodo
{
   int iDato;
   struct stcNodo *pSiguiente;
};

// Define el tipo de acuerdo a la Estructura
typedef struct stcNodo nodo;

// Función para verificar si una Lista Enlazada está vacía
int FnIntListaVacia(nodo *pCabeza)
{
   // Verifica si está apuntando a Null
   if (pCabeza==NULL)
   {
      printf("La Lista está vacía \n");
      return TRUE;
   }
   else
   {
      printf("La Lista no está vacía \n");
      return FALSE;
   }
}

// Función para crear un Nodo
nodo *FnNodoCrea(int xDato)
{
   // Defino una variable de tipo Apuntador Nodo
   nodo *xNodo;

   // Reservo la Memoria para el Nodo
   xNodo = (nodo *)malloc(sizeof(nodo));

   
   // Verifico que haya podido reservar memoria
   if (xNodo == NULL)
      // Despliega el Mensaje de Error
      printf("Error. No se pudo reservar memoria para el Nodo");
   else
   {
      // Asigna la Información al Nodo
      xNodo->iDato      = xDato; // El Dato
      xNodo->pSiguiente = NULL;  // Apunta a Null
   }

   //Retorna el resultado
   return xNodo;
}

// Función para desplegar los Elementos
void SbListaDespliega(nodo *pCabeza)
{
    // Para Contar los Elementos
    char iContar=0;

    // Desplegando los Elementos de la lista
    printf("Desplegando los Elementos de la Lista ...\n");

    // Ciclo para desplegar los Elementos de la Lista
    while (pCabeza!=NULL)
    {
      // Despliega la información del Nodo
      printf("Elemento:%d Valor:%d  en dirección:%p que apunta a:%p \n",++iContar,pCabeza->iDato,pCabeza,pCabeza->pSiguiente);

      // Mueve cabeza al siguiente elemento
      pCabeza = pCabeza->pSiguiente;
    }

    // Deja una Línea
    printf("\n");

}

// Función para Insertar un Elemento en la Lista Al Final
void SbListaInsertarFinal(nodo **pCabeza,nodo **pCola, int xDato)
{

    // Definimos un Apuntador a un Nodo
    nodo *pNodoNuevo;
    nodo *pAux;

    // Crea un Nuevo Nodo apuntando a Null
    pNodoNuevo=FnNodoCrea(xDato);

    // Verifica si está vacía
    if (FnIntListaVacia(*pCabeza))
    {

       // Cabeza y Cola apuntan a este Primer Nodo
       *pCabeza = pNodoNuevo;
       *pCola   = pNodoNuevo;

       // Mensaje
       printf("Se ha Insertado el elemento %d en el frente estando la Lista Vacía \n\n",xDato);
    }
    else
    {

       //Hacer que el Nodo al que esta apuntando Cabeza,su pSiguente apunte a este nuevo
       //(*pCola)->pSiguiente = pNodoNuevo;
       pAux = *pCola;
       pAux->pSiguiente = pNodoNuevo;

       //COLA; tambien apunte a este Nuevo Nodo.
       *pCola = pNodoNuevo;

       // Mensaje
       printf("Se ha Insertado el elemento %d en el final de la Lista \n\n",xDato);
    }


}

// Función para Insertar en Medio de la Lista despues de un dato
void SbListaInsertarDespues(nodo *pCabeza,nodo **pCola, int xDatoDespuesDe, int xDatoInsertar)
{

    // Definimos un Apuntador a un Nodo
    nodo *pNodoNuevo;

    // Para Contar los Elementos
    char iContar=0;

    // Para indicar si encontró el elemento
    char iResult = FALSE;

    // Desplegando los Elementos de la lista
    printf("Buscando Elemento para Insertar Despues de el ...\n");

    // Ciclo para buscar en los elementos de la lista
    while (pCabeza!=NULL)
    {

      // Incrementa el contador
      iContar++;

      // Verificamos que tenga el Elemento a buscar
      if (pCabeza->iDato==xDatoDespuesDe)
      {
         // Asigna que lo ha encontrado
         iResult=TRUE;

         // Crea un Nuevo Nodo apuntando a Null
         pNodoNuevo=FnNodoCrea(xDatoInsertar);

         // Verifica que sea el Elemento final
         if (pCabeza==*pCola)
         {
            // Código de Insertar al Final
            //Hacer que el Nodo al que esta apuntando Cola,su pSiguente apunte a este nuevo
            (*pCola)->pSiguiente = pNodoNuevo;

            //COLA; tambien apunte a este Nuevo Nodo.
            *pCola = pNodoNuevo;

            // Mensaje
            printf("Se ha Insertado el elemento %d en el final de la Lista despues de:%d \n\n",xDatoInsertar,xDatoDespuesDe);
         }
         else
         {
            // hacemos que el Nvo Nodo apunte a donde esta el Nodo encontrado que indica la posición a insertar;
            pNodoNuevo->pSiguiente = pCabeza->pSiguiente;

            // y a este mismo nodo encontrado lo hacemos que apunte al Nuevo Nodo.
            pCabeza->pSiguiente=pNodoNuevo;

            // Mensaje
            printf("Se ha Insertado el elemento: %d en la Lista, despues de: %d \n\n",xDatoInsertar,xDatoDespuesDe);
         }

         // Rompe el Ciclo
         break;
      }
      else
        // Mueve cabeza al siguiente elemento
        pCabeza = pCabeza->pSiguiente;

    }

    // Verifica que no encontró para desplegar mensaje correspondiente
    if (!iResult)
       // Deja una Línea
       printf("El Elemento a Buscar %d para insertar despues, no fue encontrado \n",xDatoDespuesDe);

    // Deja una Linea
    printf("\n");



}

// Función para Eliminar al Final
nodo FnNodoListaEliminaFinal(nodo **pCabeza,nodo **pCola)
{
    // Nodo a Retornar
    nodo xNodo;
    nodo *pNodoAuxiliar;

    // Inicializa el Nodo
    xNodo.iDato=-1;
    xNodo.pSiguiente=NULL;

    // Verifica que no esté vacía
    if(FnIntListaVacia(*pCabeza))

      // Despliega la información del Nodo
      printf("La Lista está vacía; no hay elementos para eliminar \n\n");

    else
    {


      // Verifica que haya un solo elemento
      if(*pCabeza==*pCola)
      {
         // Obtengo la Información del dato a Eliminar
         pNodoAuxiliar = *pCabeza;

         // Obtener la Información del Nodo a Eliminar
         xNodo.iDato      = pNodoAuxiliar->iDato;
         xNodo.pSiguiente = pNodoAuxiliar->pSiguiente;

         // Libero la Memoria del NODO a eliminar
         free(pNodoAuxiliar);

         // Coloca a Null ambos
         *pCola   = NULL;
         *pCabeza = NULL;

         // Despliega la información del Nodo
         printf("Se ha Eliminado del Final el único elemento que había:%d en dirección:%p que apuntaba a:%p \n\n",xNodo.iDato,pNodoAuxiliar,xNodo.pSiguiente);


      }
      else
      {
         //Igualo Nodo Auxiliar a Cabeza para Busqueda
         pNodoAuxiliar = *pCabeza;

         // Ciclo que busca un Elemento que pSiguiente sea igual a Cola
         while (pNodoAuxiliar->pSiguiente != *pCola)
         {
            // Recorre
            pNodoAuxiliar=pNodoAuxiliar->pSiguiente;
         }

         // Obtener la Información del Nodo a Eliminar
         //xNodo.iDato      = pNodoAuxiliar->iDato;
         //xNodo.pSiguiente = pNodoAuxiliar->pSiguiente;
         xNodo.iDato      = (*pCola)->iDato;
         xNodo.pSiguiente = (*pCola)->pSiguiente;


         // Liberaremos la Memoria del COLA
         free(*pCola);

         // Haremos que COLA apunte a al NODO que apuntaba igual que COLA
         *pCola = pNodoAuxiliar;

         // haremos que este NODO su Apuntador pSiguiente apunte a NULL.
         pNodoAuxiliar->pSiguiente=NULL;

         // Despliega la información del Nodo Eliminado
         printf("Se ha liberado del Final el elemento:%d en dirección:%p que apuntaba a:%p \n\n",xNodo.iDato,pNodoAuxiliar,xNodo.pSiguiente);

      }

    }

    // Retorna el Nodo
    return (xNodo);

}


// Función para Eliminar Un Elemento de la Lista
nodo FnNodoListaEliminaDato(nodo **pCabeza,nodo **pCola,int xDato)
{
    // Nodo a Retornar
    nodo xNodo;
    nodo *pNodoAnterior=NULL;
    nodo *pNodoActual;
    nodo *pNodoEliminar;

    // Variable para el Resultado
    int iResult=FALSE;

    // Inicializa el Nodo
    xNodo.iDato=-1;
    xNodo.pSiguiente=NULL;

    // Verifica que no esté vacía
    if(FnIntListaVacia(*pCabeza))

      // Despliega la información del Nodo
      printf("La Lista está vacía; no hay elementos para eliminar \n\n");

    else
    {

         //Igualo Nodo Actual a Cabeza para Busqueda
         pNodoActual = *pCabeza;

         // Ciclo que buscar el Elemento del que despues se va a borrar
         while (pNodoActual != NULL)
         {
            // Pregunto si este es el nodo que deseo eliminar
            if (pNodoActual->iDato==xDato)
            {

               // Obtengo los datos el Elemento a Eliminar
               pNodoEliminar    = pNodoActual;
               xNodo.iDato      = pNodoEliminar->iDato;
               xNodo.pSiguiente = pNodoEliminar->pSiguiente;
               
               // Libero la memoria
               //free(pNodoEliminar);ojo

               // Verifico si es el único Elemento
               if (pNodoActual==*pCabeza && pNodoActual==*pCola)
               {
                   // Inicializo Cabeza y Cola
                   *pCabeza=NULL;
                   *pCola=NULL;

                   // Mensaje
                   printf("Se eliminó el único Elemento %d en dirección:%p que apuntaba a:%p \n",xNodo.iDato,pNodoEliminar,xNodo.pSiguiente);
               }
               else
                   // Verificamos si es el ElementoFinal
                   if(pNodoActual==*pCola)
                   {

                      // Haremos que COLA apunte a al NODO anterior
                      *pCola = pNodoAnterior;

                      // haremos que este NODO Anterior su Apuntador pSiguiente apunte a NULL.
                      pNodoAnterior->pSiguiente=NULL;

                      // Despliega la información del Nodo Eliminado
                      printf("Se ha Eliminado del Final el elemento:%d en dirección:%p que apuntaba a:%p \n\n",xNodo.iDato,xNodo.pSiguiente);

                   }
                   else
                      // Verificamos si es el Elemento del Frente
                      if (pNodoActual==*pCabeza)
                      {

                          // Despliega la información del Nodo
                          printf("Se eliminó del Frente el Elemento:%d en dirección:%p que apuntaba a dirección:%p \n\n",xNodo.iDato,pNodoEliminar,xNodo.pSiguiente);

                          // Mueve cabeza al siguiente elemento
                          //*pCabeza = (*pCabeza)->pSiguiente;
                          *pCabeza = xNodo.pSiguiente;

                      }
                      else
                      {
                          // El Elemento a Eliminar no es único, no está en el Frente ni en el final
                          pNodoAnterior->pSiguiente = pNodoActual->pSiguiente;//Ojo


                          // Despliega la información del Nodo
                          printf("Se eliminó de Enmedio el Elemento:%d en dirección:%p que apuntaba a dirección:%p \n\n",xNodo.iDato,pNodoEliminar,xNodo.pSiguiente);
                      }

               // Variable para indicar que si lo encontró
               iResult=TRUE;
               break;

            }
            else
            {
               // Guardo la Dirección Actual como Anterior
               pNodoAnterior=pNodoActual;

               // Muevo el Nodo Actual
               pNodoActual=pNodoActual->pSiguiente;
            }
         }

         // Verifica si no lo encontró para desplegar mensaje
         if (!iResult)
            printf("No se encontró un elemento con el Dato indicado %d \n",xDato);

         // Deja una Línea
         printf("\n");
    }

    // Retorna el Nodo
    return (xNodo);

}

// Función Principal
int main()
{
    // Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 22 - Listas Enlazadas \n\n");

    // Apuntadores Cabeza y Cola
    nodo *pCabeza;
    nodo *pCola;
    pCabeza = NULL;
    pCola   = NULL;

    // Variable Nodo para Eliminar
    nodo xNodo;

    // Inserta un Elemento en la Lista
    SbListaInsertarFinal(&pCabeza,&pCola,20);

    // Despliega la Lista
    SbListaDespliega(pCabeza);

    // Inserta un Elemento en la Lista
    SbListaInsertarFinal(&pCabeza,&pCola,30);

    // Despliega la Lista
    SbListaDespliega(pCabeza);


    // Inserta un Elemento en la Lista
    SbListaInsertarFinal(&pCabeza,&pCola,40);

    // Despliega la Lista
    SbListaDespliega(pCabeza);

    // Inserta un Elemento en la Lista despues del 20
    SbListaInsertarDespues(pCabeza,&pCola,20,25);

    // Despliega la Lista
    SbListaDespliega(pCabeza);

    // Inserta un Elemento en la Lista despues del 20
    SbListaInsertarDespues(pCabeza,&pCola,40,55);

    // Despliega la Lista
    SbListaDespliega(pCabeza);

    // Elimina de la Cola
    xNodo=FnNodoListaEliminaFinal(&pCabeza,&pCola);
    printf("xNodo Valor:%d \n",xNodo.iDato);
    printf("xNodo Valor:%p\n",xNodo.pSiguiente);

    // Despliega la Lista
    SbListaDespliega(pCabeza);

    // Elimina de la Cola
    FnNodoListaEliminaFinal(&pCabeza,&pCola);

    // Elimina de la Cola
    FnNodoListaEliminaFinal(&pCabeza,&pCola);

    // Elimina de la Cola
    FnNodoListaEliminaFinal(&pCabeza,&pCola);

    // Elimina de la Cola
    FnNodoListaEliminaFinal(&pCabeza,&pCola);

    // Despliega la Lista
    SbListaDespliega(pCabeza);

    // Inserta un Elemento en la Lista al Final
    SbListaInsertarFinal(&pCabeza,&pCola,55);

    // Despliega la Lista
    SbListaDespliega(pCabeza);

    // Eliminamos Dato con un Único elemento
    FnNodoListaEliminaDato(&pCabeza,&pCola,55);

    // Inserta un Elemento en la Lista
    SbListaInsertarFinal(&pCabeza,&pCola,65);

    // Inserta un Elemento en la Lista
    SbListaInsertarFinal(&pCabeza,&pCola,75);

    // Inserta un Elemento en la Lista
    SbListaInsertarFinal(&pCabeza,&pCola,85);

    // Inserta un Elemento en la Lista
    SbListaInsertarFinal(&pCabeza,&pCola,87);

    // Inserta un Elemento en la Lista
    SbListaInsertarFinal(&pCabeza,&pCola,93);

    // Inserta un Elemento en la Lista
    SbListaInsertarFinal(&pCabeza,&pCola,95);

    // Eliminamos Dato la Final
    FnNodoListaEliminaDato(&pCabeza,&pCola,95);

    // Despliega la Lista
    SbListaDespliega(pCabeza);

    // Eliminamos Dato del Frente
    FnNodoListaEliminaDato(&pCabeza,&pCola,65);

    // Despliega la Lista
    SbListaDespliega(pCabeza);

    // Eliminamos Dato del Frente
    FnNodoListaEliminaDato(&pCabeza,&pCola,85);

    // Despliega la Lista
    SbListaDespliega(pCabeza);

    // Finaliza
    return 0;

}

