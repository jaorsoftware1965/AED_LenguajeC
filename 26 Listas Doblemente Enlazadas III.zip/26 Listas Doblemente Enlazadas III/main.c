/*
Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE
www.jaorsoftware.com

Clase 26 - Listas Doblemente Enlazadas III

En esta Clase finalizaremos ya el Tema de las Listas Doblemente
Enlazadas.

Para esta ocasión, veremos como Insertar un Elemento antes
o despues de un elemento específico; recordemos que anteriormente
solo podíamos insertar un elemento despues; y no antes; ya que
no teníamos una referencia al Nodo anterior; que ahora si tenemos.

Tambien veremos como eliminar un Elemento específico de acuerdo
a su valor.

INSERTAR DESPUES DE.
Para realizar una inserción "despues de"; deberemos de localizar
el elemento primeramente; y una vez encontrado insertaremos
el Nuevo Nodo despues de el.

1) Cuando se va a Insertar al Final
Es decir que nos piden insertar despues del Último elemento
entonces llamamos a la rutina insertar al Final.
Esto lo sabremos cuando realizamos la busqueda del elemento con
pAux y pAux = Cola

2) Cuando se va a insertar despues de un elemento que NO es
el último

Los Pasos a seguir son los siguientes.

a) Crear el Nuevo Nodo
b) Localizar el Elemento utilizando pAux
c) NuevoNodo->Siguiente = pAux->Siguiente
d) NuevoNodo->Anterior  = pAux
e) pAux->Siguiente->Anterior = NodoNuevo
f) pAux->Siguiente = NvoNodo

GRÁFICAMENTE.
      CABEZA                  aux                   COLA
         |                     |     m               |
         |                                           |
nil<--|PAnter|<--|PAnter|<--|PAnter|<--|PAnter|<--|PAnter|
      |Valor1|   |Valor2|   |Valor3|   |Valor4|   |Valor5|
      |PSigte|-->|PSigte|-->|PSigte|-->|PSigte|-->|PSigte|-->nil
         5          10         15        20          25
                     |                    |
      CABEZA                  pAux                           COLA
         |                     b|                              |
         |                      |         a                    |
       Nodo1       Nodo2      Nodo3  d  NodoNvo e  Nodo4      Nodo5
nil<--|PAnter|<--|PAnter|<--|PAnter|<--|PAnter|<--|PAnter|<--|PAnter|
      |Valor1|   |Valor2|   |Valor3|   |Valor3|   |Valor4|   |Valor5|
      |PSigte|-->|PSigte|-->|PSigte|-->|PSigte|-->|PSigte|-->|PSigte|-->nil
                                     f          c

INSERTAR ANTES DE.
Para realizar una inserción "antes de"; tambien deberemos de localizar
el elemento primeramente; y una vez encontrado insertaremos
el Nuevo Nodo antes de el.

1) Cuando se va a Insertar al Frente
Es decir que nos piden insertar antes del Primer elemento
entonces llamamos a la rutina insertar al Frente.
Esto lo sabemos cuando realizamos la busqueda del elemento con
pAux y pAux = Cabeza

2) Cuando se va a insertar despues de un elemento que NO es
el primero

Los Pasos a seguir son los siguientes.

a) Crear el Nuevo Nodo
b) Localizar el Elemento utilizando pAux
c) NuevoNodo->Anterior   = pAux->Anterior
d) NuevoNodo->Siguiente  = pAux
e) pAux->Anterior->Siguiente = NodoNuevo
f) pAux->Anterior = NvoNodo

GRÁFICAMENTE.
      CABEZA                  paux                  COLA
         |                m     |                     |
         |                      |                     |
nil<--|PAnter|<--|PAnter|<--|PAnter|<--|PAnter|<--|PAnter|
      |Valor1|   |Valor2|   |Valor3|   |Valor4|   |Valor5|
      |PSigte|-->|PSigte|-->|PSigte|-->|PSigte|-->|PSigte|-->nil

      CABEZA                                       pAux       COLA
         |                                          b|          |
         |                                           |          |
       Nodo1       Nodo2      Nodo3  c  NodoNvo  f Nodo4      Nodo5
nil<--|PAnter|<--|PAnter|<--|PAnter|<--|PAnter|<--|PAnter|<--|PAnter|
      |Valor1|   |Valor2|   |Valor3|   |Valor3|   |Valor4|   |Valor5|
      |PSigte|-->|PSigte|-->|PSigte|-->|PSigte|-->|PSigte|-->|PSigte|-->nil
                                     e          d

ELIMINAR UN ELEMENTO.

Para eliminar un Elemento, primeramente verificamos si el elemento
a eliminar está en el Frente o en el Final de la Lista, para lo cual
llamaremos a la rutina correspondiente que ya se encuentra diseñada.

Lo anterior lo realizaremos buscando el Elemento a eliminar con el
apuntador pAux; y al encontrarlo; verificaremos si es igual a COLA;
lo cual significará que es el último; y si es igual a CABEZA; será
el Primero.

Si verificamos que pAux=CABEZA=COLA; podremos eliminar sin llamar
a ninguna rutina; ya que sería el único elemento; y lo haremos
liberando pAux, o CABEZA o COLA; y haciendo que
estos 2 últimos apunten a NULL.

Los pasos a seguir cuando se elimina un elemento del medio, son los
siguientes:

a) Buscar el Elemento con pAux
a1) xNodo guardo el dato y los apuntadores
b)  Liberar pAux  
c)  pAux-Anterior-Siguiente = pAux-Siguiente // Error
    XNodoAnterior-pSIfgueinte = xNodod-pSiguiente
c)  pAux-Anterior-Siguiente = xNodoAux->pSiguiente 
    xNodoSiguiente->Anterior = bBodoAux->pAnterior

d)pAux-Siguiente-Anterior=pAux-Anterior // Error
d)pAux-Siguiente-Anterior=xNodo->pAnteriro // Error

                             xNodo
GRÁFICAMENTE.                  |
      CABEZA                                       COLA
         |                                           |
         |                                           |
       Nodo1       Nodo2                Nodo4      Nodo5
nil<--|PAnter|<--|PAnter|<-------------|PAnter|<--|PAnter|
      |Valor1|   |Valor2|   |Valor3|   |Valor4|   |Valor5|
      |PSigte|-->|PSigte|------------->|PSigte|-->|PSigte|-->nil

      CABEZA                 pAux                  COLA
         |                    b|                     |
         |                     |                     |
       Nodo1       Nodo2     d          Nodo4      Nodo5
nil<--|PAnter|<--|PAnter|<-------------|PAnter|<--|PAnter|
      |Valor1|   |Valor2|         c    |Valor4|   |Valor5|
      |PSigte|-->|PSigte|------------->|PSigte|-->|PSigte|-->nil


*/

// Librerias
#include <stdlib.h>
#include <stdio.h>

// Constantes
#define TRUE  1
#define FALSE 0


// Define la Estructura para los Nodos
struct stcNodo
{
   int iDato;
   struct stcNodo *pSiguiente;
   struct stcNodo *pAnterior;
};

// Define el tipo de acuerdo a la Estructura
typedef struct stcNodo nodo;

// Funcion para crear un Nodo
nodo *FnNodoCrea(int xDato)
{
   // Defino una variable de tipo Apuntador Nodo
   nodo *xNodo;

   // Reservo la Memoria para el Nodo
   xNodo = (nodo *)malloc(sizeof(nodo));

   
   // Verifico que haya podido reservar memoria
   if (xNodo == NULL)
      // Despliega el Mensaje de Error
      printf("Error. No se pudo reservar memoria para el Nodo");
   else
   {
      // Asigna la Informacion al Nodo
      xNodo->iDato      = xDato; // El Dato
      xNodo->pSiguiente = NULL;  // Apunta a Null
      xNodo->pAnterior  = NULL;
   }

   //Retorna el resultado
   return xNodo;
}

// Funcion para verificar si una Lista Enlazada esta vacia
int FnIntListaVacia(nodo *pCabeza)
{
   // Verifica si esta apuntando a Null
   if (pCabeza==NULL)
   {
      printf("La Lista esta vacia \n");
      return TRUE;
   }
   else
   {
      printf("La Lista no esta vacia \n");
      return FALSE;
   }
}
// Función para Insertar un Elemento al Frente de la Lista Doblemente Enlazada
void SbListaDobleInsertarFrente(nodo **pCabeza, int xDato)
{

    // Definimos un Apuntador a un Nodo

    //a) Crear el Nodo Nuevo con el Valor Correspondiente.
    nodo *pNodoNuevo;

    // Crea un Nuevo Nodo apuntando a Null
    pNodoNuevo=FnNodoCrea(xDato);

    // Verifica si está vacía ( Mandamos con pCola en lugar de pCabeza)
    if (FnIntListaVacia(*pCabeza))
    {
        // b) Siguiente y anterior apunta a NULL
        //pNodoNuevo->pSiguiente = NULL;
        //pNodoNuevo->pAnterior = NULL;

        // c) Hacer que Cabeza apunte al Nodo Nuevo.
        *pCabeza=pNodoNuevo;

        // Mensaje
        printf("Inserción Lista Doblemente Enlazada Vacía; Elemento %d en dirección %p \n\n",xDato,pNodoNuevo);
    }
    else
    {
        // b) Hacer que CABEZA->Anterior apunte al Nuevo Nodo
        (*pCabeza)->pAnterior = pNodoNuevo;

        // c) Hacer que el Nuevo Nodo->Siguiente Apunte al Nodo que apunta Cabeza
        pNodoNuevo->pSiguiente = *pCabeza;

        // d) Hacer que el Nuevo Nodo->Anterior apunte a NULL
        pNodoNuevo->pAnterior = NULL;

        // e) Hacer que CABEZA Apunte al Nvo Nodo
        *pCabeza = pNodoNuevo;

        // Mensaje
        printf("Inserción Inicio Lista Doblemente Enlazada Elemento %d en dirección %p \n\n",xDato,pNodoNuevo);
    }
}

// Función para Eliminar un Elemento del Frente de la Lista Doble
nodo FnNodoListaDobleEliminaFrente(nodo **pCabeza)
{
    // apuntador Auxiliar
    nodo* pAux;

    // Definimos un Apuntador a un Nodo
    nodo xNodo;

    // Inicializa
    xNodo.iDato=-1;
    xNodo.pSiguiente=NULL;
    xNodo.pAnterior=NULL;

    // Verifica si está vacía ( Mandamos con pCola en lugar de pCabeza)
    if (FnIntListaVacia(*pCabeza))
    {
        // Mensaje
        printf("La Lista Doblemente Enlazada está vacía, no es posible eliminar Elementos \n\n");
    }
    else
    {
        // Obtenemos la información del Nodo a Eliminar
        xNodo.iDato      = (*pCabeza)->iDato;
        xNodo.pSiguiente = (*pCabeza)->pSiguiente;
        xNodo.pAnterior  = (*pCabeza)->pAnterior;
        
        // Guardamos el Apuntador
        pAux = (*pCabeza)->pSiguiente;

        // a) Liberar el Nodo a que apunta CABEZA
        free(*pCabeza); 

        // b) Cabeza apunta ahora a Cabeza->Siguiente
        //*pCabeza = (*pCabeza)->pSiguiente; // Error
        *pCabeza = pAux;                     // CORREGIDO

        // c) Cabeza->Anterior = NULL
        if (*pCabeza!=NULL)
           (*pCabeza)->pAnterior = NULL;

        // Mensaje
        printf("Eliminación Frente Lista Doblemente Enlazada Elemento:%d Sigte:%p Anter:%p \n\n",xNodo.iDato,xNodo.pSiguiente,xNodo.pAnterior);

    }

    // Retorna el Nodo
    return xNodo;
}


// Función para Insertar un Elemento al Final de la Lista Doblemente Enlazada
void SbListaDobleInsertarFinal(nodo **pCabeza,nodo **pCola, int xDato)
{

    //a) Crear el Nodo Nuevo con el Valor Correspondiente.
    nodo *pNodoNuevo;

    // Crea un Nuevo Nodo apuntando a Null
    pNodoNuevo=FnNodoCrea(xDato);

    // Verifica si está vacía ( Mandamos con pCola en lugar de pCabeza)
    if (FnIntListaVacia(*pCabeza))
    {
        // b) Siguiente y anterior apunta a NULL
        pNodoNuevo->pSiguiente = NULL;
        pNodoNuevo->pAnterior = NULL;

        // c) Hacer que Cabeza apunte al Nodo Nuevo.
        *pCabeza=pNodoNuevo;

        // d) Hacer que Cola apunte tambien al Nodo Nuevo.
        *pCola=pNodoNuevo;

        // Mensaje
        printf("Inserción Lista Doblemente Enlazada Vacía; Elemento %d en dirección %p \n\n",xDato,pNodoNuevo);
    }
    else
    {
        // b) Hacer que el Nodo Nuevo->Siguiente  = nil
        pNodoNuevo->pSiguiente = NULL;

        // c) Hacer que el Nodo Nuevo->Anterior  = COLA
        pNodoNuevo->pAnterior = *pCola;

        // d) Hacer que COLA->Siguiente apunte al Nodo Nuevo
        (*pCola)->pSiguiente = pNodoNuevo;

        // e) Hacer que COLA apunte al Nuevo Nodo
        *pCola = pNodoNuevo;

        // Mensaje
        printf("Inserción Final Lista Doblemente Enlazada Elemento %d en dirección %p \n\n",xDato,pNodoNuevo);
    }
}


// Fue necesario definir la Función Externa para que no marcara error
nodo FnNodoListaDobleEliminaFrente(nodo **pCabeza);

// Fue necesario definir la Función Externa para que no marcara error
nodo FnNodoListaDobleEliminaFinal(nodo **pCabeza,nodo **pCola);

// Función para Insertar un Elemento en la Lista Doblemente Enlazada
void SbListaDobleInsertar(nodo **pCabeza,nodo **pCola,int xDatoInsertar,int xDatoReferencia,int iInsertarDespuesDe)
{
    // Variable para determinar si encontró el elemento
    // Apuntador auxiliar para localizar el Nodo
    nodo *pAux;

    // Verifica si está vacía ( Mandamos con pCola en lugar de pCabeza)
    if (FnIntListaVacia(*pCabeza))
    {
        // Mensaje
        printf("La Lista está vacía; no es posible localizar el Elemento \n\n");
    }
    else
    {
        // Búsqueda a partir de Cabeza
        pAux = *pCabeza;

        // Ciclo para buscar el dato
        //b) Localizar el Elemento utilizando pAux
        while (pAux != NULL)
        {
           // Verifica si es el dato
           if (pAux->iDato == xDatoReferencia)
               // Sale del Ciclo
               break;
           else
               // Se Mueve al Siguiente
               pAux=pAux->pSiguiente;

        }

        // Si pAux != NULL es que si lo encontró
        if (pAux)
        {
           //a) Crear el Nodo Nuevo con el Valor Correspondiente.
           nodo *pNodoNuevo;

           // Crea un Nuevo Nodo apuntando a Null
           pNodoNuevo=FnNodoCrea(xDatoInsertar);

           // Verifica que tipo de Inserción es
           if (iInsertarDespuesDe)
           {
              // Inserción es Despues de
              // Verifica si está en el Último elemento
              if (pAux==*pCola)
                 // Llama a Función que Inserta en el Frente
                 SbListaDobleInsertarFinal(&(*pCabeza),&(*pCola),xDatoInsertar);
              else
              {
                 // c) NuevoNodo->Siguiente = pAux->Siguiente
                 pNodoNuevo->pSiguiente = pAux->pSiguiente;

                 // d) NuevoNodo->Anterior  = pAux
                 pNodoNuevo->pAnterior = pAux;

                 // e) pAux->Siguiente->Anterior = NodoNuevo
                 pAux->pSiguiente->pAnterior=pNodoNuevo;

                 // f) pAux->Siguiente = NvoNodo
                 pAux->pSiguiente=pNodoNuevo;

                 // Mensaje descriptivo
                 printf("Inserción Despues De; Elemento %d en dirección %p \n\n",xDatoInsertar,pNodoNuevo);
              }

           }
           else
           {
              // Inserción Antes de
              // Verifica si está en el Primer elemento
              if (pAux==*pCabeza)
                 // Llama a Función que Inserta en el Frente
                 SbListaDobleInsertarFrente(&(*pCabeza),xDatoInsertar);
              else
              {
                 // c) NuevoNodo->Anterior = pAux->Anterior
                 pNodoNuevo->pAnterior=pAux->pAnterior;

                 // d) NuevoNodo->Siguiente  = pAux
                 pNodoNuevo->pSiguiente = pAux;

                 // e) pAux->Anterior->Siguiente = NodoNuevo
                 pAux->pAnterior->pSiguiente=pNodoNuevo;

                 // f) pAux->Anterior = NvoNodo
                 pAux->pAnterior = pNodoNuevo;

                 // Mensaje descriptivo
                 printf("Inserción Antes De; Elemento %d en dirección %p \n\n",xDatoInsertar,pNodoNuevo);
              }
           }
        }
    }
}

// Función para Eliminar un Elemento Específico
nodo FnNodoListaDobleElimina(nodo **pCabeza,nodo **pCola,int xDato)
{

    // Declaramos el Apuntador Auxiliar para buscar el Elemento
    nodo *pAux;

    // Definimos un Apuntador a un Nodo
    nodo xNodo;

    // Inicializa
    xNodo.iDato=-1;
    xNodo.pSiguiente=NULL;
    xNodo.pAnterior=NULL;

    // Verifica si está vacía ( Mandamos con pCola en lugar de pCabeza)
    if (FnIntListaVacia(*pCabeza))
    {
        // Mensaje
        printf("La Lista Doblemente Enlazada está vacía, no es posible eliminar Elementos \n\n");
    }
    else
    {

        // Asignamos a pAux = CABEZA
        pAux = *pCabeza;

        // Ciclo para buscar el Elemento a Eliminar
        //a)Buscar el Elemento con pAux
        while (pAux!=NULL)
        {
            // Verificamos que encontramos el Nodo
            if (pAux->iDato==xDato)
                // Salimos del Ciclo si lo encontramos
                break;
            else
               // Se mueve al Siguiente
               pAux=pAux->pSiguiente;
        }

        // Verifica si encontró el dato
        if (pAux!=NULL)
        {
            // Encontró el dato
            // Obtengo la información del Nodo a ser Eliminado
            xNodo.iDato      = pAux->iDato;
            xNodo.pSiguiente = pAux->pSiguiente;
            xNodo.pAnterior  = pAux->pAnterior;

            // Verifica si es el único elemento
            if (pAux==*pCabeza && pAux==*pCola)
            {
               // Es el único elemento
               free(pAux);

               // Asigna a Null Cola y Cabeza
               *pCabeza=NULL;
               *pCola=NULL;

               // Mensaje
               printf("Eliminación del Único Elemento Lista Doblemente Enlazada:%d Sigte:%p Anter:%p \n\n",xNodo.iDato,xNodo.pSiguiente,xNodo.pAnterior);
            }
            else
               // Verifica si es el elemento del Frente
               if (pAux==*pCabeza)
                  // Llama a la Rutina correspondiente
                  xNodo=FnNodoListaDobleEliminaFrente(&(*pCabeza));
               else
                  // Verifica si es el elemento del Final
                  if (pAux==*pCola)
                     //Llama a la rutina correspondiente
                     xNodo=FnNodoListaDobleEliminaFinal(&(*pCabeza),&(*pCola));
                  else
                  {
                      // Es un elemento de enmedio
                      // b)Liberar pAux //
                      free(pAux);

                      // c)pAux-Anterior-Siguiente=pAux-Siguiente
                      // EL mismo ERROR en la siguiente
                      //pAux->pAnterior->pSiguiente=pAux->pSiguiente;
                      //pAux->pAnterior->pSiguiente=xNodo.pSiguiente;//Error
                      xNodo.pAnterior->pSiguiente=xNodo.pSiguiente;

                      // d)pAux-Siguiente-Anterior=pAux-Anterior
                      //pAux->pSiguiente->pAnterior=pAux->pAnterior;
                      //pAux->pSiguiente->pAnterior=xNodo.pAnterior;
                      xNodo.pSiguiente->pAnterior=xNodo.pAnterior;

                      // Mensaje
                      printf("Eliminación de enmedio Lista Doblemente Enlazada:%d Sigte:%p Anter:%p \n\n",xNodo.iDato,xNodo.pSiguiente,xNodo.pAnterior);

                  }
        }
        else
           // Mensaje
           printf("El Elemento no fue encontrado en la Lista \n\n");
    }
    // Retorna el Nodo
    return xNodo;
}
// Función para Eliminar un Elemento del Final de la Lista Doble
nodo FnNodoListaDobleEliminaFinal(nodo **pCabeza,nodo **pCola)
{

    // Definimos un Apuntador a un Nodo
    nodo xNodo;

    // Inicializa
    xNodo.iDato=-1;
    xNodo.pSiguiente=NULL;
    xNodo.pAnterior=NULL;

    // Verifica si está vacía ( Mandamos con pCola en lugar de pCabeza)
    if (FnIntListaVacia(*pCabeza))
    {
        // Mensaje
        printf("La Lista Doblemente Enlazada está vacía, no es posible eliminar Elementos \n\n");
    }
    else
    {
        // Obtenemos la información del Nodo a Eliminar
        xNodo.iDato      = (*pCola)->iDato;
        xNodo.pSiguiente = (*pCola)->pSiguiente;
        xNodo.pAnterior  = (*pCola)->pAnterior;

        // Verificamos que sea el único elemento
        if (*pCola == *pCabeza)
        {
            // a) Liberar el Nodo a que apunta CABEZA o COLA
            free(*pCabeza);

            // Establecemos en NULL ambos
            *pCabeza = NULL;
            *pCola = NULL;

        }
        else
        {
            // a) Liberar la Memoria de COLA
            free(*pCola);

            // b) Hacer que Cola apunte a Cola->Anterior
            //*pCola = (*pCola)->pAnterior; // Error
            *pCola = xNodo.pAnterior;

            // c) Hacer que Cola->Siguiente apunte a NULL
            (*pCola)->pSiguiente = NULL;
        }
        // Mensaje
        printf("Eliminación Final Lista Doblemente Enlazada Elemento:%d Sigte:%p Anter:%p \n\n",xNodo.iDato,xNodo.pSiguiente,xNodo.pAnterior);
    }
    // Retorna el Nodo
    return xNodo;
}

// Función para desplegar los Elementos en Orden Normal e Inverso
void SbListaDobleDespliegaFull(nodo *pCabeza,nodo *pCola,int iOrdenNormal)
{
    // Para Contar los Elementos
    char iContar=0;

    // Verificamos que esté vacía
    if (FnIntListaVacia(pCabeza))
    {
       // Mensaje de Lista Vacía
       printf("La Lista Doblemente Enlazada se encuentra vacía; no hay valores que desplegar");
    }
    else
    {
        // Desplegando los Elementos de la lista
        printf("Desplegando los Elementos de la Lista ");

        // Verifica el Orden
        if (iOrdenNormal)
        {
            // Despliega el Orden
            printf("en orden normal \n");

            // Ciclo para desplegar los Elementos de la Lista
            while (pCabeza!=NULL)
            {
               // Despliega la información del Nodo
               printf("Elemento:%d Valor:%d en dirección:%p pSigte:%p pAnter:%p \n",++iContar,pCabeza->iDato,pCabeza,pCabeza->pSiguiente,pCabeza->pAnterior);

               // Mueve cabeza al siguiente elemento
               pCabeza = pCabeza->pSiguiente;
            }
         }
         else
         {
            // Despliega el Orden
            printf("en orden inverso \n");

            // Ciclo para desplegar los Elementos de la Lista
            while (pCola!=NULL)
            {
               // Despliega la información del Nodo
               printf("Elemento:%d Valor:%d en dirección:%p pSigte:%p pAnter:%p \n",++iContar,pCola->iDato,pCola,pCola->pSiguiente,pCola->pAnterior);

               // Mueve cabeza al siguiente elemento
               pCola = pCola->pAnterior;
            }

         }
    }
    // Deja una Línea
    printf("\n");

}

// Función para Vueltas
void SbVueltasLista(nodo *pCabeza,
                    nodo *pCola,
                    int   vueltas)
{
   // Nodo auxiliar
   nodo* pAux;
   int   adelante=1;

   // Asigna el Auxiliar
   pAux = pCabeza;

   printf("Imprimiendo %d vueltas en la Lista\n");

   // Ciclo
   while (vueltas>0)
   {
      // Verifico si voy adelante
      if (adelante==1)
      {
         printf("Vuelta %d \n",vueltas);
         while(pAux!=pCola)
         {
            printf("[%d] ",pAux->iDato);
            pAux = pAux->pSiguiente;
         }
         printf("[%d]\n",pAux->iDato);

         // Cambia a atras         
         adelante = 0;
      }
      else
      {
         while(pAux!=pCabeza)
         {
            printf("[%d] ",pAux->iDato);
            pAux = pAux->pAnterior;
         }
         // Imprime el Ultimo
         printf("[%d]\n",pAux->iDato);

         // Cambia a adelante
         adelante = 1;
        
         // Decremento vuelta
         vueltas--;
      }       
   }
   printf("Se finalizaron la Vueltas ...\n");
}

// Función Principal
int main()
{
    // Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 26 - Listas Doblemente Enlazadas III\n\n");

    // Declaramos apuntadores de Cabeza y Cola
    nodo *pCabeza=NULL;
    nodo *pCola=NULL;

    // Variable Nodo para Eliminar
    nodo xNodo;

    // Insertamos 3 elementos
    SbListaDobleInsertarFinal(&pCabeza,&pCola,10);
    SbListaDobleInsertarFinal(&pCabeza,&pCola,20);
    SbListaDobleInsertarFinal(&pCabeza,&pCola,30);

    // Vueltas
    SbVueltasLista(pCabeza,pCola,10);

    // Desplegamos
    SbListaDobleDespliegaFull(pCabeza,pCola,TRUE);

    // Insertamos Antes en Medio
    SbListaDobleInsertar(&pCabeza,&pCola,15,20,FALSE);

    // Insertamos Despues en Medio
    SbListaDobleInsertar(&pCabeza,&pCola,25,20,TRUE);

    // Desplegamos
    SbListaDobleDespliegaFull(pCabeza,pCola,TRUE);

    // Insertamos Antes del Frente
    SbListaDobleInsertar(&pCabeza,&pCola,5,10,FALSE);

    // Insertamos Despues del Final
    SbListaDobleInsertar(&pCabeza,&pCola,35,30,TRUE);

    // Desplegamos
    SbListaDobleDespliegaFull(pCabeza,pCola,TRUE);

    // Intentamos Eliminar un Elemeno que no existe
    xNodo = FnNodoListaDobleElimina(&pCabeza,&pCola,75);

    // Eliminamos de enmedio
    xNodo = FnNodoListaDobleElimina(&pCabeza,&pCola,15);

    // Desplegamos Información del Nodo Eliminado
    printf("Información del Nodo:%d Sigte:%p Anter:%p\n",xNodo.iDato,xNodo.pSiguiente,xNodo.pAnterior);

    // Desplegamos
    SbListaDobleDespliegaFull(pCabeza,pCola,TRUE);

    // Eliminamos del Frente
    xNodo = FnNodoListaDobleElimina(&pCabeza,&pCola,5);

    // Desplegamos Información del Nodo Eliminado
    printf("Información del Nodo:%d Sigte:%p Anter:%p\n",xNodo.iDato,xNodo.pSiguiente,xNodo.pAnterior);

    // Eliminamos del Final
    xNodo = FnNodoListaDobleElimina(&pCabeza,&pCola,35);

    // // Desplegamos Información del Nodo Eliminado
    printf("Información del Nodo:%d Sigte:%p Anter:%p\n",xNodo.iDato,xNodo.pSiguiente,xNodo.pAnterior);

    // Desplegamos
    SbListaDobleDespliegaFull(pCabeza,pCola,TRUE);

    // Eliminamos del Frente
    xNodo = FnNodoListaDobleElimina(&pCabeza,&pCola,20);

    // Eliminamos del Frente
    xNodo = FnNodoListaDobleElimina(&pCabeza,&pCola,25);

    // Eliminamos del Frente
    xNodo = FnNodoListaDobleElimina(&pCabeza,&pCola,30);

    // Eliminamos del Frente
    xNodo = FnNodoListaDobleElimina(&pCabeza,&pCola,10);

    // Desplegamos
    SbListaDobleDespliegaFull(pCabeza,pCola,TRUE);

    // Insertamos 3 elementos
    SbListaDobleInsertarFinal(&pCabeza,&pCola,11);
    SbListaDobleInsertarFinal(&pCabeza,&pCola,22);
    SbListaDobleInsertarFinal(&pCabeza,&pCola,33);

    // SbVueltasLista(3);
    //11-22-33
    //11-22-33
    //11-22-33

    // Desplegamos
    SbListaDobleDespliegaFull(pCabeza,pCola,TRUE);

    // Finaliza la aplicación retornando 0
    return 0;
}
