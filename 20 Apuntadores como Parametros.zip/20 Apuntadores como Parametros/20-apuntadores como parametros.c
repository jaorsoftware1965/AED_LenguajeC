/*
Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE
www.jaorsoftware.com

Clase 20 - Apuntadores como parámetros

El manejo de Apuntadores como parámetros en el desarrollo de
Estructuras de Gestión Dinámica de Datos, es prácticamente
indispensable; para la construcción de un código óptimo.

En esta clase veremos como utilizar apuntadores y pasarlos
como parámetros.

*/

// Libreria 
#include <stdlib.h>
#include <stdio.h>

// Función por valor
void SbTest0(int xDato)
{
   printf("El valor de xDato : %d\n",xDato);
   xDato++;
   printf("El valor de xDato : %d\n",xDato);
   return;
}


// Función por referencia
void SbTest1(int* pInteger)
{
  // VAriable entera
  static int x = 10;

  // Desplegamos el valor de la Dirección
  printf("El valor de la dirección del Apuntador es:%p \n",pInteger);

  // Desplegamos el valor que contiene la dirección
  printf("El valor que contiene la dirección del Apuntador es:%d \n",*pInteger);

  // Modificamos el contenido
  *pInteger = 20;

  // Desplegamos el valor que contiene la dirección
  printf("El valor Modificado que contiene la dirección del Apuntador es:%d \n\n",*pInteger);

  pInteger = &x;

  // Desplegamos el valor de la Dirección
  printf("El valor de la dirección del Apuntador es:%p \n",pInteger);

  // Desplegamos el valor que contiene la dirección
  printf("El valor que contiene la dirección del Apuntador es:%d \n",*pInteger);


  // Retornamos
  return;

}

// Función con un apuntador de apuntador
void SbTest2(int** pInteger)
{
  static int xInteger=50;

  // Imprimo la información que trae pInteger
  printf("Valor - dirección de  pInteger  :%p \n"  , pInteger);
  printf("Valor - dirección de *pInteger  :%p \n"  ,*pInteger);
  printf("Valor             de **pInteger :%d \n\n",**pInteger);

  *pInteger=&xInteger;

  // Imprimo la información que trae pInteger
  printf("Valor - dirección de  pInteger  :%p \n"  ,pInteger);
  printf("Valor - dirección de *pInteger  :%p \n"  ,*pInteger);
  printf("Valor             de **pInteger :%d \n\n",**pInteger);


  // Retornamos
  return;

}

// Función Principal
int main()
{
    // Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 20 - Apuntadores como Parámetros \n\n");

    // Declara una variable apuntador a Entero
    int  xEntero = 10;
    int* pEntero = &xEntero;
    // Demostrar parametros por valor
    SbTest0(xEntero);

    // Desplgamos el valor de las la Variable
    printf("Valor de xEntero              :%d \n",xEntero);
    printf("Dirección de xEntero          :%p \n\n",&xEntero);

    printf("Valor - dirección  de pEntero :%p \n",pEntero);
    printf("Valor de Dirección de pEntero :%d \n",*pEntero);
    printf("Dirección de pEntero          :%p \n\n",&pEntero);

    // Pasando la dirección de la variable como parámetro
    SbTest1(&xEntero);

    // Desplegamos el valor de las la Variable
    printf("Valor de xEntero              :%d \n",xEntero);
    printf("Dirección de xEntero          :%p \n\n",&xEntero);

    printf("Valor - dirección  de pEntero :%p \n",pEntero);
    printf("Valor de Dirección de pEntero :%d \n",*pEntero);
    printf("Dirección de pEntero          :%p \n\n",&pEntero);

    //Modificamos el valor de la Variable
    xEntero = 30;

    // Pasando la dirección de la variable como parámetro
    SbTest1(pEntero);

    // Desplegamos el valor de las la Variable
    printf("Valor de xEntero              :%d \n",xEntero);
    printf("Dirección de xEntero          :%p \n\n",&xEntero);

    printf("Valor - dirección  de pEntero :%p \n",pEntero);
    printf("Valor de Dirección de pEntero :%d \n",*pEntero);
    printf("Dirección de pEntero          :%p \n\n",&pEntero);

    // Volvemos a Modificar
    xEntero = 10;

    //Llamamos de Nuevo
    SbTest2(&pEntero);

    printf("Valor - dirección  de pEntero :%p \n"  ,pEntero);
    printf("Valor de Dirección de pEntero :%p \n"  ,*pEntero);
    printf("Valor de Dirección de pEntero : %d \n"  ,*pEntero); 
    printf("Dirección de pEntero          :%p \n\n",&pEntero);

    // Finaliza
    return 0;

}

