/*
Curso de Algoritmos y Estructura de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE
www.jaorsoftware.com

Clase 03 - Apuntadores y Arreglos
gcc "03-apuntadores y arreglos.c"

Los Apuntadores aunque no son arreglos, es posible manejarlos como si
lo fueran, ya que al contener una dirección; es posible desplazarse
a través de los elementos a los que apunte, agregando un valor a su
dirección, el cual pudieramos llamar "offset o desplazamiento" y que
en cierta forma, funcionaría como el índice de un Arreglo.

Para manejar un apuntador que acceda a un arreglo, NO SE INDICA UN
TIPO DE APUNTADOR ESPECIAL; sino un apuntador al TIPO DE DATO del cual
esté declarado el Arreglo.

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    // Desplegamos Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 03 - Apuntadores y Arreglos \n\n");

    // Declaramos Variables
    int  iaEdades[10]={10,20,30,40,50,60,70,80,90,100};
    int* piEdades;
    piEdades = &iaEdades[0];

    // Desplegamos los valores
    printf("Valores Iniciales\n");
    printf("La Edad 0 desde el Arreglo ....:%d \n",iaEdades[0]);
    printf("La Edad 0 desde el Apuntador ..:%d \n",*piEdades);
    printf("La Edad 1 desde el Arreglo ....:%d \n",iaEdades[1]);
    printf("La Edad 1 desde el Apuntador ..:%d \n",*(piEdades+1));
    printf("La Edad 2 desde el Arreglo ....:%d \n",iaEdades[2]);
    printf("La Edad 2 desde el Apuntador ..:%d \n\n",*(piEdades+2));

    // Modificamos la dirección del Apuntador
    piEdades = &iaEdades[4];

    printf("Acceso una vez que la dirección del Apuntador se modificó \n");
    printf("La Edad 4 desde el Arreglo ....:%d \n",iaEdades[4]);
    printf("La Edad 4 desde el Apuntador ..:%d \n",*piEdades);
    printf("La Edad 3 desde el Arreglo ....:%d \n",iaEdades[3]);
    printf("La Edad 3 desde el Apuntador ..:%d \n",*(piEdades-1));
    printf("La Edad 5 desde el Arreglo ....:%d \n",iaEdades[5]);
    printf("La Edad 5 desde el Apuntador ..:%d \n\n",*(piEdades+1));

    // Modificamos la Edad desde el Apuntador
    *piEdades = 123;
    printf("La Edad 4 desde el Arreglo ....:%d \n",iaEdades[4]);
    printf("La Edad 4 desde el Apuntador ..:%d \n\n",*piEdades);


    // Arreglos de Cadenas
    char  caNombres[5][10]={"00-Juan","01-Jose","02-Maria","03-Daniel","04-Edith"};
    char* pcNombres;
    pcNombres = &caNombres[0][0];
    char x='X';

    printf("Longitud en Bytes de Char:%d\n",sizeof(x));
    
    printf("Dirección Inicial desde el Vector    ....:%p \n",&caNombres);
    printf("Dirección Inicial desde el Apuntador ....:%p \n",pcNombres);

    // Desplegamos los valores
    printf("Nombres Iniciales\n");
    printf("El Nombre 0 desde el Arreglo ....:%s \n",caNombres[0]);    
    printf("El Nombre 0 desde el Apuntador...:%c \n",*pcNombres);
    printf("El Nombre 0 desde el Apuntador...:%p \n",pcNombres);
    printf("El Nombre 0 desde el Apuntador...:%s \n",pcNombres);
    printf("El Nombre 1 desde el Arreglo ....:%s \n",caNombres[1]);
    printf("El Nombre 1 desde el Apuntador...:%s \n",pcNombres+(1*10));
    printf("El Nombre 2 desde el Arreglo ....:%s \n",caNombres[2]);
    printf("El Nombre 2 desde el Apuntador...:%s \n\n",pcNombres+(2*10));


    // Modificamos la dirección del Apuntador
    pcNombres = &caNombres[2][0];

    // Desplegamos Nombres una vez que apuntador se ha movido del Inicio
    printf("El Nombre 2 desde el Arreglo ....:%s \n",caNombres[2]);
    printf("El Nombre 2 desde el Apuntador...:%s \n",pcNombres);
    printf("El Nombre 1 desde el Arreglo ....:%s \n",caNombres[1]);
    printf("El Nombre 1 desde el Apuntador...:%s \n",pcNombres-(1*10));
    printf("El Nombre 3 desde el Arreglo ....:%s \n",caNombres[3]);
    printf("El Nombre 3 desde el Apuntador...:%s \n\n",pcNombres+(1*10));

    // Modificamos el Nombre desde el Apuntador
    *pcNombres ='M';
    *(pcNombres+1) ='o';
    *(pcNombres+2) ='i';
    *(pcNombres+3) ='s';
    *(pcNombres+4) ='e';
    *(pcNombres+5) ='s';
    *(pcNombres+6) ='\0';
    strcpy(pcNombres, "tests");

    printf("El Nombre 2 desde el Arreglo ....:%s \n",caNombres[2]);
    printf("El Nombre 2 desde el Apuntador...:%s \n",pcNombres);
    printf("El Primer Caracter 2 desde el Apuntador...:%c \n",*pcNombres);

    // Haz un Ciclo For para imprimir el arreglo de cadenas
    // desde el apuntador
    
    return 0;
}

