/*
Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE
www.jaorsoftware.com

Clase 15 - Filas(Colas)

En esta clase continuaremos viendo Estructuras de Datos
y ahora toca el turno a las Filas o Colas.

Una Fila es un conjunto ordenado de elementos del
que pueden sacarse elementos de un extremo, llamado la
parte delantera o frente de la Fila; y en el que
pueden insertarse elementos del otro extremo;
llamado la parte posterior de la fila o final.

Las Filas son conocidas como estructuras FIFO; de las siglas
en Ingles que significan:"First In First Out"; que significa:
"Primero en Entrar Primero en Salir".

Veamos el siguiente ejemplo:

FILA CON 5 ELEMENTOS

Índices->  0 1 2 3 4
FILA   -> |5|6|7|8|9|

Frente ->  0
Final  ->  4

La Fila anterior tiene 5 elementos, en donde el 5 fue el
primero en entrar y está al Frente de la Fila; y el 9
fué el último en entrar y está al final de la Fila.
El Frente está referenciando a la posición 0 y el
final está referenciando a la posición 4.

Ahora veamos como se va llenando la Fila.
Inicialmente, cuando la Fila está vacía, el frente y el
final tienen valor -1. ( A null en caso de usar apuntadores)

Frente -> -1
Final  -> -1
FILA      | | | | | |

Cuando entra el primer elemento; tanto el frente como
el final, refieren a la posición 0; ya que el final y el
frente son el mismo elemento.

Frente -> 0
Final  -> 0
FILA     |10| | | | |

Cuando entra el otro elemento; entonces el frente sigue
referenciando al primer elemento y final; refiere al último
que entró.

Frente -> 0
Final  -> 1
FILA      |10|21| | | |

Este proceso se repite al seguir entrando elementos; el
frente no cambia; y el final, se modifica para referenciar
al último elemento que ingresa.

Cuando se ha llegado al número de elementos que puede
tener la Fila; entonces se dice que la fila está llena.

Frente -> 0
Final  -> 4
FILA     |10|21|12|08|43|

En las Filas, siempre podemos de poder detectar, cual es
el elemento que está en el frente de la fila, y cual es
el elemento que está al final de la Fila.

Cuando un elemento de la Fila es removido del frente,
existen 2 métodos para realizar esta operación. En
esta clase veremos el primero método.

PRIMER MÉTODO.
Cada vez que se saca un elemento de FILA, se hace el recorrido
de los restantes hacia adelante.

Frente -> 0
Final  -> 4
FILA      |10|21|12|08|43|

Frente -> 0
Final  -> 3
FILA      |21|12|08|43| |   Sacamos el 10 hay que recorrer al

Para saber cuantos elementos hay en la Fila, simplemente se
toma el valor de final + 1.

Con este método el frente siempre apuntará a 0; a menos que ya
no haya elementos en la Fila; para lo cual apuntará a -1.

FILA LLENA.
Con este método, una Fila esta llena; cuando el Número de
elementos, es igual al tamaño de la Fila; o si el valor
de Final +1 es igual al tamaño de la Fila.

De todo lo anterior, podemos detectar los siguientes proce
dimientos y valores.

Tamaño.      Número de Elementos que va a poder manejar la fila
Frente.      El valor que indica la posición del Frente
Final .      El valor que indica la posición del Final
Inicializa().Funcion para Inicializar la Fila
Insertar().  Función para Insertar un Elemento
Eliminar().  Función para Eliminar un Elemento
FilaVacía(). Función para Verificar si la Fila está vacía.
FilaLlena(). Función para Verificar si la Fila está llena.
FilaFrente().Función para obtener el Elemento del frente.
FilaFinal(). Función para obtener el Elemento del final.
Recorre().   Función para Recorrer los elementos de la Fila


*/
// Librerias
#include "stdio.h"

// Constantes
#define TRUE  1
#define FALSE 0

// Definimos el Tamaño de la Fila
#define FILA_TAMANIO 5

// Definimos la estructura de la Fila
typedef struct stcFila
{
    // Variable para manejar el frente y final de la Fila
    int  iFilaFrente;
    int  iFilaFinal;

    // El Arreglo para la Fila
    int arrIntFila[FILA_TAMANIO];
}fila;

// Implementamos Inicializar la Fila
void SbFilaInicializa(fila *pFila)
{
   // Para Inicializar la Fila basta con poner el frente y final a -1
   // Ya que el primer elemento ocupa la posición 0
   pFila->iFilaFrente=-1;
   pFila->iFilaFinal =-1;

   // Ciclo para llenar con 0's la fila
   for (int i=0; i<FILA_TAMANIO; i++)   
       pFila->arrIntFila[i]=0;

   // Desplegamos Mensaje
   printf("Fila Inicializada ...\n");
}

// Implementamos Obtener cuantos elementos tiene la Fila
int FnIntFilaElementos(fila *pFila)
{
    // Retorna el Final + 1
    return pFila->iFilaFinal + 1;
}

// Implementamos Verificar si la Fila está vacía
int FnIntFilaVacia(fila *pFila)
{
    if (pFila->iFilaFinal==-1)
        return TRUE;
    else
        return FALSE;
}

// Implementamos Verificar si la Fila está llena
int FnIntFilaLlena(fila *pFila)
{
    if (pFila->iFilaFinal+1 == FILA_TAMANIO)
       return TRUE;
    else
       return FALSE;    
}

// Implementamos para Obtener el Elemento del Frente de la Fila
int FnIntFilaFrente(fila *pFila)
{
    // Verificamos si la Fila está vacía
    if (!FnIntFilaVacia(pFila))
    {
       return(pFila->arrIntFila[pFila->iFilaFrente]);
    }
    else
    {
       printf("La Fila está vacia; no hay frente\n");
       return (-1);
    }           
}

// Implementamos para Obtener el Elemento del Final de la Fila
int FnIntFilaFinal(fila *pFila)
{
    // Verificamos si la Fila está vacía
    if (FnIntFilaVacia(pFila))
    {
       printf("La Fila está vacia; no hay final\n");
       return (-1);
    }
    else
       return(pFila->arrIntFila[pFila->iFilaFinal]);
}

// Implementamos Insertar un Elemento en la Fila
void SbFilaInsertar(fila *pFila,int iElemento)
{
    // Verificamos si la Fila está llena
    if (FnIntFilaLlena(pFila))
       printf("La Fila está llena y no es posible agregar el elemento:%d\n",iElemento);
    else
    {
       // Verificamos si fue el primer elemento para asignar el frente
       if (pFila->iFilaFrente==-1)
           pFila->iFilaFrente=0;

       // Agrega el Elemento a la Fila
       pFila->arrIntFila[++pFila->iFilaFinal] = iElemento;
    }
}

// Método para recorrer los elementos
void SbFilaRecorre(fila *pFila)
{
   // Variable para el índice
   char iIndice;

   // Ciclo para recorrer los elementos
   for (iIndice=0;iIndice<pFila->iFilaFinal;iIndice++)

       // Adelanta cada elemento
       pFila->arrIntFila[iIndice]=pFila->arrIntFila[iIndice+1];

   // Colocamos 0 en el final
   pFila->arrIntFila[pFila->iFilaFinal] = 0;

   // Decrementa el final
   pFila->iFilaFinal--;
}

// Implementamos Eliminiar un Elemento de la Fila
int FnIntFilaEliminar(fila *pFila)
{
    // El valor a devolver
    int iResult;

    // Verificamos si la Fila está vacía
    if (FnIntFilaVacia(pFila))
    {
       printf("La Fila está vacía no es posible eliminar elementos\n");
       iResult = pFila->iFilaFinal;
    }
    else
    {
       // Obtiene el Elemento a Devolver que es el que se elimina
       iResult = pFila->arrIntFila[pFila->iFilaFrente];
       
       // Verifica si solo hay un elemento
       if (pFila->iFilaFinal==0)
       {
          // Ponemos 0 el elemento final
          pFila->arrIntFila[pFila->iFilaFinal] = 0;

          // Inicializa
          pFila->iFilaFinal  = -1;
          pFila->iFilaFrente = -1;
          
       }
       else
          // Recorre los Elementos de la Fila
          SbFilaRecorre(pFila);
    }

    // Devuelve el resultado
    return(iResult);
}

// Función Principal
int main()
{
    // Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 15 - Filas(Colas) \n\n");

    // Declara la Variable para la Fila
    fila xFila;

    // Inicializa la Fila
    SbFilaInicializa(&xFila);

    // Verificamos elementos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaElementos(&xFila));
    printf("El Frente de la Fila : %d\n"  ,FnIntFilaFrente(&xFila));
    printf("El Final   de la Fila: %d\n"  ,FnIntFilaFinal(&xFila));
    //printf("La Fila está vacía   : %d\n",FnIntFilaVacia(&xFila));
    //printf("La Fila está llena   : %d\n\n",FnIntFilaLlena(&xFila));
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila) ? "True" : "False");
    printf("La Fila está llena   : %s\n\n",FnIntFilaLlena(&xFila) ? "True" : "False");

    // Agrega elementos a la Fila
    printf("Agregamos el 10 a la Fila \n\n");
    SbFilaInsertar(&xFila,10);

    // Verificamos elementos en la Fila
    printf("Elementos en la Fila : %d\n",FnIntFilaElementos(&xFila));
    printf("El Frente de la Fila : %d\n",FnIntFilaFrente(&xFila));
    printf("El Final   de la Fila: %d\n",FnIntFilaFinal(&xFila));
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaLlena(&xFila)? "True" : "False" );

    // Agrega elementos a la Fila
    printf("Agregamos el 13 a la Fila \n\n");
    SbFilaInsertar(&xFila,13);

    // Verificamos elementos en la Fila
    printf("Elementos en la Fila : %d\n",FnIntFilaElementos(&xFila));
    printf("El Frente de la Fila : %d\n",FnIntFilaFrente(&xFila));
    printf("El Final   de la Fila: %d\n",FnIntFilaFinal(&xFila));
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaLlena(&xFila)? "True" : "False" );


    printf("Agregamos el 34,45,67,78 a la Fila \n\n");
    SbFilaInsertar(&xFila,34);
    SbFilaInsertar(&xFila,45);
    SbFilaInsertar(&xFila,67);
    SbFilaInsertar(&xFila,78);

    // Verificamos elementos en la Fila
    printf("Elementos en la Fila : %d\n",FnIntFilaElementos(&xFila));
    printf("El Frente de la Fila : %d\n",FnIntFilaFrente(&xFila));
    printf("El Final   de la Fila: %d\n",FnIntFilaFinal(&xFila));
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaLlena(&xFila)? "True" : "False" );


    printf("Eliminamos del Frente de La Fila :%d \n",FnIntFilaEliminar(&xFila));
    printf("Elementos en la Fila : %d\n",FnIntFilaElementos(&xFila));
    printf("El Frente de la Fila : %d\n",FnIntFilaFrente(&xFila));
    printf("El Final   de la Fila: %d\n",FnIntFilaFinal(&xFila));
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaLlena(&xFila)? "True" : "False" );

    printf("Eliminamos del Frente de La Fila :%d \n",FnIntFilaEliminar(&xFila));
    printf("Elementos en la Fila : %d\n",FnIntFilaElementos(&xFila));
    printf("El Frente de la Fila : %d\n",FnIntFilaFrente(&xFila));
    printf("El Final   de la Fila: %d\n",FnIntFilaFinal(&xFila));
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaLlena(&xFila)? "True" : "False" );

    printf("Eliminamos del Frente de La Fila :%d \n",FnIntFilaEliminar(&xFila));
    printf("Eliminamos del Frente de La Fila :%d \n",FnIntFilaEliminar(&xFila));
    printf("Eliminamos del Frente de La Fila :%d \n",FnIntFilaEliminar(&xFila));
    printf("Eliminamos del Frente de La Fila :%d \n\n",FnIntFilaEliminar(&xFila));

    printf("Agregamos el 10 a la Fila \n\n");
    SbFilaInsertar(&xFila,10);

    // Verificamos elementos en la Fila
    printf("Elementos en la Fila : %d\n",FnIntFilaElementos(&xFila));
    printf("El Frente de la Fila : %d\n",FnIntFilaFrente(&xFila));
    printf("El Final   de la Fila: %d\n",FnIntFilaFinal(&xFila));
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaLlena(&xFila)? "True" : "False" );

    printf("Agregamos el 20 a la Fila \n\n");
    SbFilaInsertar(&xFila,20);
    // Verificamos elementos en la Fila
    printf("Elementos en la Fila : %d\n",FnIntFilaElementos(&xFila));
    printf("El Frente de la Fila : %d\n",FnIntFilaFrente(&xFila));
    printf("El Final   de la Fila: %d\n",FnIntFilaFinal(&xFila));
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaLlena(&xFila)? "True" : "False" );


    printf("Eliminamos del Frente de La Fila :%d \n",FnIntFilaEliminar(&xFila));
    // Verificamos elementos en la Fila
    printf("Elementos en la Fila : %d\n",FnIntFilaElementos(&xFila));
    printf("El Frente de la Fila : %d\n",FnIntFilaFrente(&xFila));
    printf("El Final   de la Fila: %d\n",FnIntFilaFinal(&xFila));
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaLlena(&xFila)? "True" : "False" );
    
    printf("Eliminamos del Frente de La Fila :%d \n",FnIntFilaEliminar(&xFila));
    // Verificamos elementos en la Fila
    printf("Elementos en la Fila : %d\n",FnIntFilaElementos(&xFila));
    printf("El Frente de la Fila : %d\n",FnIntFilaFrente(&xFila));
    printf("El Final   de la Fila: %d\n",FnIntFilaFinal(&xFila));
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaLlena(&xFila)? "True" : "False" );
    

    // Finaliza
    return 0;

}

