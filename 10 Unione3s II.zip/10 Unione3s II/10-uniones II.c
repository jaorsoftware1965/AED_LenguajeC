/*

Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE
www.jaorsoftware.com

Clase 10 - Uniones II

Es posible utilizar typedef con la uniones de la misma forma
como lo realizamos con las estructuras.
De igual forma podemos establecer el tipo y tambien el nombre
de la unión y utilizar ambas para poder declarar variables.

Ejemplo:

typedef union COMPARTE
{
    char        xChar;   // 1 Byte
    short int   xsInt;   // 2 Bytes
    float       xFloat;  // 4 Bytes
    double      xDouble; // 8 Bytes
}comparte;

En el caso anterior, estamos definiendo la estructura COMPARTE
y el tipo comparte. Podemos definir variables utilizando ambos:

struct COMPARTE x;
comparte        y;

Al definir estructuras dentro de uniones; y/o uniones dentro 
de estructuras, es posible no indicar el nombre de la 
estructura o de la unión; y hacer referencia directamente 
al dato que se defina en la estructura o unión interior.


*/

// LIbrerias
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Definimos una estructura para manejar la Fecha
struct FECHA
{
    char cTipo;//0-Semanas;1-Dias;2-Cadena;3-Partes
    union
    {
        char      en_semanas;    // 1-52
        short int en_dias;       // 1-365
        char      en_cadena[12]; // dd-mmm-yyyy
        struct
        {
           char dia;  // 1-31
           char mes;  // 1-12
           short int anio; // 2015...
        }en_partes;
    };
};


// Definimos una estructura para manejar un Número en 
// Diversos Sistemas
typedef union REGISTRO
{
    unsigned short int full; // 2 Bytes
    struct
    {
      unsigned char  baja;  // 1 Byte
      unsigned char  alta;  // 1 Byte
    }parte;

}registro;

typedef union NOMBRE
{
    char nombreCompleto[60]; // 60
    struct
    {
        char nombre[30];  // 1 Byte
        char apellido[30];  // 1 Byte
    };

}nombre;

// Definimos una estructura para manejar un Número en Diversos Sistemas
typedef union COLOR
{
    int   rgb;  // 4 Bytes
    struct
    {
       unsigned char  blue; //0000ff
       unsigned char  green;//00ff00
       unsigned char  red;  //ff0000
    };
}color;

// Compartimiento de la memoria
//                            --blue--
//                   -green--
//          ---red--
// ----------------rgb----------------
// 00000000 00000000 00000000 00000000
// 00000000 11111111 11111111 11111111 <=FFFFFF

// Imprime la Fecha
void SbFechaImprime(struct FECHA pFecha);

// Función Principal
int main()
{
    // Desplegamos Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 10 - Uniones II\n\n");


    
    // Imprimo el nombre completo
    printf("Nombre Completo :%s\n ",miNombre.nombreCompleto);
    printf("Nombre          :%s\n ",miNombre.nombre);
    printf("Apellido        :%s\n ",miNombre.apellido);



    // Asignamos el valor a los colores
    //color xColor;
    union COLOR xColor;
    printf("Tamaño de la Union:%d \n",sizeof(xColor));

    // Definimos los Colores
    xColor.rgb=0xFFFFFF; // Establecemos el Color Blanco

    // Imprimimos el Color y su proporción en RGB
    printf(" El Color establecido a Blanco \n");
    printf(" El Valor del Color RGB    :%d\t %X \n",xColor.rgb,xColor.rgb);
    printf(" El Valor del Color Red    :%d\t\t %X \n",xColor.red,xColor.red);
    printf(" El Valor del Color Green  :%d\t\t %X \n",xColor.green,xColor.green);
    printf(" El Valor del Color Blue   :%d\t\t %X \n\n",xColor.blue,xColor.blue);

    xColor.blue=0;
    printf(" Ponemos el Color Azul a 0 \n");
    printf(" El Valor del Color RGB    :%d\t %X \n",xColor.rgb,xColor.rgb);
    printf(" El Valor del Color Red    :%d\t\t %X \n",xColor.red,xColor.red);
    printf(" El Valor del Color Green  :%d\t\t %X \n",xColor.green,xColor.green);
    printf(" El Valor del Color Blue   :%d\t\t %X \n\n",xColor.blue,xColor.blue);

    xColor.green=0;
    printf(" Ponemos el Color Verde a 0 \n");
    printf(" El Valor del Color RGB    :%d\t %X \n",xColor.rgb,xColor.rgb);
    printf(" El Valor del Color Red    :%d\t\t %X \n",xColor.red,xColor.red);
    printf(" El Valor del Color Green  :%d\t\t %X \n",xColor.green,xColor.green);
    printf(" El Valor del Color Blue   :%d\t\t %X \n\n",xColor.blue,xColor.blue);

    xColor.red=0;
    printf(" Ponemos el Color Rojo a 0 lo que es igual al Color NEGRO: 000000 \n");
    printf(" El Valor del Color RGB    :%d\t\t %X \n",xColor.rgb,xColor.rgb);
    printf(" El Valor del Color Red    :%d\t\t %X \n",xColor.red,xColor.red);
    printf(" El Valor del Color Green  :%d\t\t %X \n",xColor.green,xColor.green);
    printf(" El Valor del Color Blue   :%d\t\t %X \n\n",xColor.blue,xColor.blue);

    // Establecemos una tonalidad de Gris
    xColor.red=44;
    xColor.green=84;
    xColor.blue=66;

    printf(" Ponemos el Color en Tonalidad Gris \n");
    printf(" El Valor del Color RGB    :%d\t %X \n",xColor.rgb,xColor.rgb);
    printf(" El Valor del Color Red    :%d\t\t %X \n",xColor.red,xColor.red);
    printf(" El Valor del Color Green  :%d\t\t %X \n",xColor.green,xColor.green);
    printf(" El Valor del Color Blue   :%d\t\t %X \n\n",xColor.blue,xColor.blue);


    // Definimos una variable registro
    registro AX;

    AX.full=255;
    printf(" Desplegamos el Valor del Registro \n");
    printf(" Completo    :%d ",AX.full);
    printf(" Parte Alta  :%d ",AX.parte.alta);
    printf(" Parte Baja  :%d\n\n",AX.parte.baja);

    // ------- AX ------
    // 00000000 00000000
    // ----AH-- --AL----
    // h-high      L - Low

    // 00000010 00101000
    AX.parte.alta=2;
    AX.parte.baja=40;
    printf(" Desplegamos el Valor del Registro \n");
    printf(" Completo    :%d ",AX.full);
    printf(" Parte Alta  :%d ",AX.parte.alta);
    printf(" Parte Baja  :%d\n\n",AX.parte.baja);

    AX.full=0xD462;
    // 11010100 = 212
    // 01100010 =  98
    printf(" Desplegamos el Valor del Registro \n");
    printf(" Completo    :%d ",AX.full);
    printf(" Parte Alta  :%d ",AX.parte.alta);
    printf(" Parte Baja  :%d\n\n",AX.parte.baja);


    // Defino la variable para la FEcha
    struct FECHA xFecha;

    // Establezco la Fecha en Semanas
    xFecha.cTipo=0;
    xFecha.en_semanas=23;
    printf(" Desplegamos la Fecha en Semanas:");
    //Llama a Rutina que imprime la fecha
    SbFechaImprime(xFecha);

    // Establezco la Fecha en Dias
    xFecha.cTipo=1;
    xFecha.en_dias=233;
    printf(" Desplegamos la Fecha en Dias   :");
    //Llama a Rutina que imprime la fecha
    SbFechaImprime(xFecha);

    // Establezco la Fecha en Cadena
    xFecha.cTipo=2;
    strcpy(xFecha.en_cadena,"23-Jun-2015");
    printf(" Desplegamos la Fecha en Cadena :");
    //Llama a Rutina que imprime la fecha
    SbFechaImprime(xFecha);

    // Establezco la Fecha en Partes
    xFecha.cTipo=3;
    xFecha.en_partes.dia=10;
    xFecha.en_partes.mes=3;
    xFecha.en_partes.anio=2015;
    printf(" Desplegamos la Fecha en Partes :");
    //Llama a Rutina que imprime la fecha
    SbFechaImprime(xFecha);


    // Finaliza con 0 la aplicación
    return 0;
}

// Imprime la Fecha
void SbFechaImprime(struct FECHA pFecha)
{

   // Verifica que fecha está manejando para imprimir
   switch (pFecha.cTipo)
   {
      case 0:// En Semanas
           printf(" %d\n",pFecha.en_semanas);
           break;
      case 1:
           printf(" %d\n",pFecha.en_dias);
           break;
      case 2:
           printf(" %s\n",pFecha.en_cadena);
           break;
      case 3:
           printf(" %d-%02d-%d\n",pFecha.en_partes.dia,pFecha.en_partes.mes,pFecha.en_partes.anio);
           break;
      default:
           printf("Error en Tipo de Fecha\n");
           break;
   }
}
