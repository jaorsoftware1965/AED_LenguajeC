/*
Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE
www.jaorsoftware.com

Clase 18 - Filas de Prioridad

Continuamos viendo tipos de Filas y para esta clase veremos
la Fila de Prioridad.

Una Fila de Prioridad, respeta la lógica de una estructura
FIFO; es decir que el Primero en Entrar es el Primero en salir;
pero agregando la condición de que "saldrá primero el que tenga
mayor prioridad; y si tienen la misma prioridad sale el que
llegó primero.

En una Fila de Prioridad, cada elemento que es ingresado en la
fila tiene que tener una prioridad asignada; la cual determina
su posición dentro de la fila. Si su prioridad es mayor que todos
los elementos de la Fila, deberá ser ingresado hasta el frente
de la fila. Si su prioridad es igual a uno varios elementos en
la fila, se ingresará despues de ellos.

Para establecer la prioridad utilizaremos un valor numérico; en
donde el número MAYOR indicará mayor prioridad; es decir; si
un elemento tiene prioridad 10; tiene mayor prioridad que un
elemento con prioridad 9.

Ejemplo. Suponga que queremos ingresar los siguiente elementos
con sus prioridades: A-1,X-0,C-0,D-0,F-1

La fila se iría llenando de la siguiente forma:


Fila   ->|A-1|...
Fila   ->|A-1|X-0|...
Fila   ->|A-1|X-0|C-0|...+
Fila   ->|A-1|X-0|C-0|D-0|...
Fila   ->|A-1|F-1|X-0|C-0|D-0|

Como podemos observar; los primeros 4 elementos al tener la misma
prioridad, se ingresaron al Final de la Fila; excepto el F; el cual
al tener mayor prioridad que todos EXCEPTO A, fue ingresado
DESPUES DE LA A.

Lo anterior nos lleva a concluir que los elementos estarán
ordenados por inserción y prioridad.

Como ya mencionamos anteriormente, utilizaremos una fila Circular
para implementar la Fila de Prioridad; y el único proceso que
cambia totalmente es el de Insertar; el cual evaluaremos las
circunstancias posibles.

1) INSERTAR CUANDO EL ELEMENTO A INSERTAR TIENE LA MISMA PRIORIDAD
   O MENOR QUE EL ELEMENTO FINAL.
   Para este caso, el elemento se insertará al final, tal y como ya
   se ha considerado en la Fila circular.
   Ejemplo.
   Insertar W-9
              0   1   2   3   4
   A)FILA-> |A-9|B-9|C-9|   |   |  Fte->0    Final->2
   B)FILA-> |   |   |A-9|B-9|C-9|  Fte->2    Final->4
   C)FILA-> |F-9|   |   |B-9|C-9|  Fte->3    Final->0

   Estas son las posibilidades que ya están consideradas en la función
   insertar de la fila circular

2) INSERTAR POR PRIORIDAD CUANDO EL ORDEN DE LA FILA CIRCULAR ESTÁ
   NORMAL, ES DECIR QUE FINAL ES MAYOR QUE FRENTE.
   Para este caso, se realiza una busqueda de Frente a Final hasta
   encontrar el elemento con menor prioridad en la Fila, para ahí
   insertar el Elemento y recorrer a la derecha.
   Insertar W-8

   A)FILA-> |A-9|B-7|C-7|   |   |
     FILA.> |A-9|W-8|B-7|C-7|   |

   Si Final ocupa
   la última posición, el elemento final se pasa a posición 0.

   B)FILA-> |   |   |A-9|B-7|C-7|
     FILA-> |C-7|   |A-9|W-8|B-7|

3) INSERTAR POR PRIORIDAD CUANDO EL ORDEN DE LA FILA CIRCULAR NO ESTÁ
   NORMAL, ES DECIR QUE FINAL ES MENOR QUE FRENTE.
   Para este caso, se realizan 2 búsquedas. Primero desde Frente hasta
   FILA_TAMAÑO. Si encuentra una prioridad menor en la Fila, en la
   parte ALTA.
   - Se debe recorrer primero los de la parte BAJA
   - Pasar el ultio elemento a la posición 0
   - Recorrer los de la parte final, pasando el ultimo a la posición 0

   Insertar W-8

   A)FILA-> |D-7|   |   |B-9|C-7|  // Cuando se debe insertar en la parte ALTA
     FILA.> |C-7|D-7|   |B-9|W-8|

   Si se encuentra el elemento con prioridad menor; en la parte BAJA;
   se debe hacer el recorrido a la derecha de sus elementos posteriores,
   e insertar ahí el elemento.

   B)FILA-> |D-8|E-7|   |B-9|C-9|  // Cuando se debe insertar en la parte baja
            |D-8|W-8|E-7|B-9|C-9|

*/
// Librerias
#include "stdio.h"
#include "stdlib.h"
#include "string.h"

// Constantes
#define TRUE  1
#define FALSE 0

// Definimos el Tamaño de la Fila
#define FILA_TAMANIO 5

// Definimos la estructura para un Elemento
typedef struct stcElemento
{
   // El elemento a Ingresar
   char cElemento[10];

   // La Prioridad del Elemento
   char cPrioridad;

}elemento;

// Definimos la estructura de la Fila Prioridad
typedef struct stcFilaPrioridad
{
    // Variable para manejar el frente y final de la Fila
    int  iFilaFrente;
    int  iFilaFinal;

    // El Arreglo para la Fila
    elemento arrElementosFila[FILA_TAMANIO];

}filaPrioridad;

// Implementamos Inicializar la Fila de Prioridad
void SbFilaPrioridadInicializa(filaPrioridad *pFila)
{
   // Para Inicializar la Fila basta con poner el frente y final a -1
   // Ya que el primer elemento ocupa la posición 0
   pFila->iFilaFrente=-1;
   pFila->iFilaFinal =-1;

   for (int i = 0; i< FILA_TAMANIO; i++)
       strcpy(pFila->arrElementosFila[i].cElemento,"NULO");
   
   // Desplegamos Mensaje
   printf("Fila Inicializada ...\n");
}

// Implementamos Verificar si la Fila de Prioridad está vacía
int FnIntFilaPrioridadVacia(filaPrioridad *pFila)
{
    if (pFila->iFilaFinal==-1)
        return TRUE;
    else
        return FALSE;
}

// Implementamos para Obtener el Elemento del Frente de la Fila
elemento FnElemFilaPrioridadFrente(filaPrioridad *pFila)
{
    // Para retornar un Elemento
    elemento xElemento;
    strcpy(xElemento.cElemento,"NULO");
    xElemento.cPrioridad=-1;

    // Verificamos si la Fila está vacía
    if (FnIntFilaPrioridadVacia(pFila))
       return(xElemento);
    else
       return(pFila->arrElementosFila[pFila->iFilaFrente]);
}

// Implementamos para Obtener el Elemento del Final de la Fila
elemento FnElemFilaPrioridadFinal(filaPrioridad *pFila)
{
    // Para retornar un Elemento
    elemento xElemento;
    strcpy(xElemento.cElemento,"NULO");
    xElemento.cPrioridad=-1;

    // Verificamos si la Fila está vacía
    if (FnIntFilaPrioridadVacia(pFila))
       return (xElemento);
    else
       return(pFila->arrElementosFila[pFila->iFilaFinal]);
}

// Implementamos Obtener cuantos elementos tiene la Fila Prioridad (Circular)
int FnIntFilaPrioridadElementos(filaPrioridad *pFila)
{
    // Verifica si la Fila está vacía
    if (FnIntFilaPrioridadVacia(pFila))// Agregue Prioridad
        return 0;
    else
       // Verifica si final es mayor o igual que frente
       if (pFila->iFilaFinal >= pFila->iFilaFrente)
          // Retorna en base al Final - Frente + 1
          return pFila->iFilaFinal - pFila->iFilaFrente + 1;
       else
          // Retorna en base al Tamaño - Frente + Final + 1
          return FILA_TAMANIO - pFila->iFilaFrente + pFila->iFilaFinal + 1;
}

// Implementamos Verificar si la Fila de Prioridad está llena
int FnIntFilaPrioridadLlena(filaPrioridad *pFila)
{
    if (FnIntFilaPrioridadElementos(pFila)==FILA_TAMANIO)
       return TRUE;
    else
       return FALSE;
}


// Implementamos Insertar un Elemento en la Fila Prioridad
void SbFilaPrioridadInsertar(filaPrioridad *pFila,elemento pElemento)
{
    // Variable de Tipo Elemento
    elemento xElementoFinal;

    // Para ciclos
    char cIndice,cIndice2;

    // Obtengo el elemento final para comparar contra su prioridad
    xElementoFinal = FnElemFilaPrioridadFinal(pFila);

    // Verificamos si la Fila está llena
    if (FnIntFilaPrioridadLlena(pFila))
       printf("La Fila está llena y no es posible agregar el elemento:%d\n",pElemento);
    else
    {
       // Verificamos si esta vacia
       if (pFila->iFilaFinal==-1)
       {
           // Coloca el Frente en 0
           pFila->iFilaFrente=0;

           // Coloca el Final en 0 tambien
           pFila->arrElementosFila[++pFila->iFilaFinal] = pElemento;
       }
       else
           // Verificamos que la prioridad sea igual o menor que el elemento final
           if (xElementoFinal.cPrioridad >= pElemento.cPrioridad)
               // 1) INSERTAR CUANDO EL ELEMENTO A INSERTAR TIENE LA MISMA PRIORIDAD
               // O MENOR QUE EL ELEMENTO FINAL.
               // Verificamos que esté en el final
               if (pFila->iFilaFinal +1 == FILA_TAMANIO)
               {                    
                    // Final va a 0
                    pFila->iFilaFinal=0;

                    // Asigna el Elemento
                    pFila->arrElementosFila[pFila->iFilaFinal]=pElemento;
               }
               else
                 // Si no está en el final, incrementamos FInal y asignamos
                 pFila->arrElementosFila[++pFila->iFilaFinal]=pElemento;
           else
           // Inserta el Elemento en la Posición de acuerdo a su prioridad
           {
              // Como es fila circular, verifica si está en posición normal
              if (pFila->iFilaFinal >= pFila->iFilaFrente)
              {
                 //2) INSERTAR POR PRIORIDAD CUANDO EL ORDEN DE LA FILA CIRCULAR ESTÁ
                 //   NORMAL, ES DECIR QUE FINAL ES MAYOR QUE FRENTE.

                 // Ciclo que busca una prioridad mayor en la parte
                 for (cIndice=pFila->iFilaFrente; cIndice<=pFila->iFilaFinal; cIndice++)
                      // Verifica la prioridad cuando Elemento a Insertar > Elemento en Fila
                      if (pElemento.cPrioridad > pFila->arrElementosFila[cIndice].cPrioridad)
                          // Encontró la prioridad y sale del Ciclo
                          break;

                 // Muevo Primero el elemento final
                 if (pFila->iFilaFinal+1 == FILA_TAMANIO)
                    // Lo mueve a la 0
                    pFila->arrElementosFila[0]=pFila->arrElementosFila[pFila->iFilaFinal];
                 else
                    // Lo mueve 1 atras
                    pFila->arrElementosFila[pFila->iFilaFinal+1]=pFila->arrElementosFila[pFila->iFilaFinal];

                 // a partir de la posición encontrada debe recorrer
                 for (cIndice2=pFila->iFilaFinal-1; cIndice2>=cIndice;cIndice2--)
                     pFila->arrElementosFila[cIndice2+1]=pFila->arrElementosFila[cIndice2];

                 // Coloco el Elemento Nuevo en  su posición
                 pFila->arrElementosFila[cIndice]=pElemento;

                 // Actualizo Final
                 // Muevo Primero el elemento final
                 if (pFila->iFilaFinal+1 == FILA_TAMANIO)
                    // Lo mueve a la 0
                    pFila->iFilaFinal=0;
                 else
                    // Lo mueve 1 atras
                    pFila->iFilaFinal++;

              }
              else
              {
                 // 3) INSERTAR POR PRIORIDAD CUANDO EL ORDEN DE LA FILA CIRCULAR NO ESTÁ
                 // NORMAL, ES DECIR QUE FINAL ES MENOR QUE FRENTE.
                 // 0 1 2 3 4 6 7 8 9 3
                 // A b   C D D W Q A T    
                 // A - b          
                 //  
                    
                 // Esta es la busqueda cuando el Final está al frente
                 // Primero buscamos del frente hasta FILA_TAMAÑIO
                 // Ciclo que busca una prioridad mayor en la parte ALTA
                 for (cIndice=pFila->iFilaFrente; cIndice<=FILA_TAMANIO-1; cIndice++)
                      // Verifica la prioridad hasta que Elemento a Insertar > Elemento en Fila
                      if (pElemento.cPrioridad > pFila->arrElementosFila[cIndice].cPrioridad)
                          // Encontró la prioridad y sale del Ciclo
                          break;

                 // Verifica si lo encontró
                 if (cIndice<FILA_TAMANIO)
                 {
                    // Encontro en parte ALTA
                    // Cuando se debe insertar en la parte ALTA
                    // Recorremos primero la parte BAJA
                    for (cIndice2=pFila->iFilaFinal;cIndice2=0;cIndice2--)
                        // Recorremos a la derecha para dejar la posición 0 vacía
                        pFila->arrElementosFila[cIndice2+1]=pFila->arrElementosFila[cIndice2];

                    // Colocamos el del final en la posición 0
                    pFila->arrElementosFila[0]=pFila->arrElementosFila[pFila->iFilaFinal];

                    // Recorremos a la derecha la parte alta
                    for (cIndice2=pFila->iFilaFinal-1;cIndice2>=cIndice;cIndice2--)
                        // Recorremos a la derecha para dejar la posición 0 vacía
                        pFila->arrElementosFila[cIndice2+1]=pFila->arrElementosFila[cIndice2];

                    // Agrega el Nuevo Elemento en cIndice
                    pFila->arrElementosFila[cIndice]=pElemento;

                    // Ojo, Creo que falta actualizar Final
                    pFila->iFilaFinal++;

                 }
                 else // No lo encontró
                 {
                    // Cuando se debe insertar en la parte BAJA
                    // Ciclo que busca una prioridad mayor en la parte BAJA
                    for (cIndice=0; cIndice<=pFila->iFilaFinal; cIndice++)
                        // Verifica la prioridad
                        if (pElemento.cPrioridad > pFila->arrElementosFila[cIndice].cPrioridad )
                           // Encontró la prioridad y sale del Ciclo
                           break;

                    // Recorre los Elementos hacia la derecha
                    for (cIndice2=pFila->iFilaFinal;cIndice2>=cIndice;cIndice2--)
                        // Recorremos a la derecha para dejar la posición 0 vacía
                        pFila->arrElementosFila[cIndice2+1]=pFila->arrElementosFila[cIndice2];

                    // Agrega el Nuevo Elemento en cIndice
                    pFila->arrElementosFila[cIndice]=pElemento;

                    // Incrementa el Final
                    pFila->iFilaFinal++;

                 }
              }
           }
    }
}

// Implementamos Eliminar un Elemento de la Fila Circular
elemento FnElemFilaPrioridadEliminar(filaPrioridad *pFila)
{
    // El valor a devolver
    elemento eResult;

    // Verificamos si la Fila está vacía
    if (FnIntFilaPrioridadVacia(pFila))
    {
       printf("La Fila está vacía no es posible sacar elementos\n");
       strcpy(eResult.cElemento,"NULO");
       eResult.cPrioridad=-1;
    }
    else
    {
       // Obtiene el Elemento a Devolver y le coloca -1 para visualizacion mejor
       eResult= pFila->arrElementosFila[pFila->iFilaFrente];
       strcpy(pFila->arrElementosFila[pFila->iFilaFrente].cElemento,"NULO");
       pFila->arrElementosFila[pFila->iFilaFrente].cPrioridad=-1;

       // Verifica si solo hay un elemento
       if (pFila->iFilaFinal==pFila->iFilaFrente)
       {
          // Inicializa
          pFila->iFilaFinal=-1;
          pFila->iFilaFrente=-1;

       }
       else
          // Verifica si está en posición 0 el frente para mandar al final
          if (pFila->iFilaFrente+1==FILA_TAMANIO)
             // El frente es ahora 0
             pFila->iFilaFrente=0;
          else
            // Mueve el referenciador del Frente
            pFila->iFilaFrente++;
    }

    // Devuelve el resultado
    return(eResult);

}

// Despliega el Vector de la Fila de Prioridad
void SbFilaPrioridadDespliegaVector(filaPrioridad *pFila)
{
   char iIndice;

   printf("Fila->| ");
   for (iIndice=0; iIndice<FILA_TAMANIO;iIndice++)
        printf("%s[%d] | ",pFila->arrElementosFila[iIndice].cElemento,pFila->arrElementosFila[iIndice].cPrioridad);
   printf("\n\n");

}

// función Principal
int main()
{
    // Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 18 - Filas Prioridad \n\n");

    // Declara la variable de la Fila
    filaPrioridad xFila;

    // Declara la variable para Elemento
    elemento xElemento;

    // Incializa la Fila
    strcpy(xFila.arrElementosFila[0].cElemento,"NULO");
    xFila.arrElementosFila[0].cPrioridad=-1;
    strcpy(xFila.arrElementosFila[1].cElemento,"NULO");
    xFila.arrElementosFila[1].cPrioridad=-1;
    strcpy(xFila.arrElementosFila[2].cElemento,"NULO");
    xFila.arrElementosFila[2].cPrioridad=-1;
    strcpy(xFila.arrElementosFila[3].cElemento,"NULO");
    xFila.arrElementosFila[3].cPrioridad=-1;
    strcpy(xFila.arrElementosFila[4].cElemento,"NULO");
    xFila.arrElementosFila[4].cPrioridad=-1;

    // Inicializa la Fila
    SbFilaPrioridadInicializa(&xFila); // Agregue Prioridad

    // Verificamos Datos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaPrioridadElementos(&xFila));
    // Obtiene el Elemento del Frente
    xElemento =FnElemFilaPrioridadFrente(&xFila);
    printf("El Frente de la Fila : Elemento:%s Prioridad:%d en pos:%d\n" ,xElemento.cElemento,xElemento.cPrioridad,xFila.iFilaFrente);
    xElemento =FnElemFilaPrioridadFinal(&xFila);
    printf("El Final de la Fila  : Elemento:%s Prioridad:%d en pos:%d\n" ,xElemento.cElemento,xElemento.cPrioridad,xFila.iFilaFinal);
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaPrioridadVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaPrioridadLlena(&xFila)? "True" : "False" );
    SbFilaPrioridadDespliegaVector(&xFila);

    // Preparamos elemento a insertar
    strcpy(xElemento.cElemento,"Doc1.Doc");
    xElemento.cPrioridad=0;

    // Insertamos el Elemento
    SbFilaPrioridadInsertar(&xFila,xElemento);

    // Verificamos Datos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaPrioridadElementos(&xFila));
    // Obtiene el Elemento del Frente
    xElemento =FnElemFilaPrioridadFrente(&xFila);
    printf("El Frente de la Fila : Elemento:%s Prioridad:%d en pos:%d\n" ,xElemento.cElemento,xElemento.cPrioridad,xFila.iFilaFrente);
    xElemento =FnElemFilaPrioridadFinal(&xFila);
    printf("El Final de la Fila  : Elemento:%s Prioridad:%d en pos:%d\n" ,xElemento.cElemento,xElemento.cPrioridad,xFila.iFilaFinal);
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaPrioridadVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaPrioridadLlena(&xFila)? "True" : "False" );
    SbFilaPrioridadDespliegaVector(&xFila);

    // Preparamos elemento a insertar
    strcpy(xElemento.cElemento,"Imag.bmp");
    xElemento.cPrioridad=0;

    // Insertamos el Elemento
    SbFilaPrioridadInsertar(&xFila,xElemento);
    // Verificamos Datos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaPrioridadElementos(&xFila));
    // Obtiene el Elemento del Frente
    xElemento =FnElemFilaPrioridadFrente(&xFila);
    printf("El Frente de la Fila : Elemento:%s Prioridad:%d en pos:%d\n" ,xElemento.cElemento,xElemento.cPrioridad,xFila.iFilaFrente);
    xElemento =FnElemFilaPrioridadFinal(&xFila);
    printf("El Final de la Fila  : Elemento:%s Prioridad:%d en pos:%d\n" ,xElemento.cElemento,xElemento.cPrioridad,xFila.iFilaFinal);
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaPrioridadVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaPrioridadLlena(&xFila)? "True" : "False" );
    SbFilaPrioridadDespliegaVector(&xFila);

    // Preparamos elemento a insertar
    strcpy(xElemento.cElemento,"Datos.Dat");
    xElemento.cPrioridad=2;

    // Insertamos el Elemento
    SbFilaPrioridadInsertar(&xFila,xElemento);
    // Verificamos Datos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaPrioridadElementos(&xFila));
    // Obtiene el Elemento del Frente
    xElemento =FnElemFilaPrioridadFrente(&xFila);
    printf("El Frente de la Fila : Elemento:%s Prioridad:%d en pos:%d\n" ,xElemento.cElemento,xElemento.cPrioridad,xFila.iFilaFrente);
    xElemento =FnElemFilaPrioridadFinal(&xFila);
    printf("El Final de la Fila  : Elemento:%s Prioridad:%d en pos:%d\n" ,xElemento.cElemento,xElemento.cPrioridad,xFila.iFilaFinal);
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaPrioridadVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaPrioridadLlena(&xFila)? "True" : "False" );
    SbFilaPrioridadDespliegaVector(&xFila);

    // Preparamos elemento a insertar
    strcpy(xElemento.cElemento,"Calif.Dat");
    xElemento.cPrioridad=2;

    // Insertamos el Elemento
    SbFilaPrioridadInsertar(&xFila,xElemento);
    // Verificamos Datos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaPrioridadElementos(&xFila));
    // Obtiene el Elemento del Frente
    xElemento =FnElemFilaPrioridadFrente(&xFila);
    printf("El Frente de la Fila : Elemento:%s Prioridad:%d en pos:%d\n" ,xElemento.cElemento,xElemento.cPrioridad,xFila.iFilaFrente);
    xElemento =FnElemFilaPrioridadFinal(&xFila);
    printf("El Final de la Fila  : Elemento:%s Prioridad:%d en pos:%d\n" ,xElemento.cElemento,xElemento.cPrioridad,xFila.iFilaFinal);
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaPrioridadVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaPrioridadLlena(&xFila)? "True" : "False" );
    SbFilaPrioridadDespliegaVector(&xFila);

    // Preparamos elemento a insertar
    strcpy(xElemento.cElemento,"Boleta.Dat");
    xElemento.cPrioridad=1;

    // Insertamos el Elemento
    SbFilaPrioridadInsertar(&xFila,xElemento);

    // Verificamos Datos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaPrioridadElementos(&xFila));
    // Obtiene el Elemento del Frente
    xElemento =FnElemFilaPrioridadFrente(&xFila);
    printf("El Frente de la Fila : Elemento:%s Prioridad:%d en pos:%d\n" ,xElemento.cElemento,xElemento.cPrioridad,xFila.iFilaFrente);
    xElemento =FnElemFilaPrioridadFinal(&xFila);
    printf("El Final de la Fila  : Elemento:%s Prioridad:%d en pos:%d\n" ,xElemento.cElemento,xElemento.cPrioridad,xFila.iFilaFinal);
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaPrioridadVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaPrioridadLlena(&xFila)? "True" : "False" );
    SbFilaPrioridadDespliegaVector(&xFila);

    // Eliminamos un Elemento
    xElemento = FnElemFilaPrioridadEliminar(&xFila);
    printf("Se eliminó el Elemento %s con Prioridad %d\n",xElemento.cElemento,xElemento.cPrioridad);

    // Verificamos Datos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaPrioridadElementos(&xFila));
    // Obtiene el Elemento del Frente
    xElemento =FnElemFilaPrioridadFrente(&xFila);
    printf("El Frente de la Fila : Elemento:%s Prioridad:%d en pos:%d\n" ,xElemento.cElemento,xElemento.cPrioridad,xFila.iFilaFrente);
    xElemento =FnElemFilaPrioridadFinal(&xFila);
    printf("El Final de la Fila  : Elemento:%s Prioridad:%d en pos:%d\n" ,xElemento.cElemento,xElemento.cPrioridad,xFila.iFilaFinal);
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaPrioridadVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaPrioridadLlena(&xFila)? "True" : "False" );
    SbFilaPrioridadDespliegaVector(&xFila);

    // Preparamos elemento a insertar
    strcpy(xElemento.cElemento,"List.Dat");
    xElemento.cPrioridad=0;

    // Insertamos el Elemento
    SbFilaPrioridadInsertar(&xFila,xElemento);

    // Verificamos Datos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaPrioridadElementos(&xFila));
    // Obtiene el Elemento del Frente
    xElemento =FnElemFilaPrioridadFrente(&xFila);
    printf("El Frente de la Fila : Elemento:%s Prioridad:%d en pos:%d\n" ,xElemento.cElemento,xElemento.cPrioridad,xFila.iFilaFrente);
    xElemento =FnElemFilaPrioridadFinal(&xFila);
    printf("El Final de la Fila  : Elemento:%s Prioridad:%d en pos:%d\n" ,xElemento.cElemento,xElemento.cPrioridad,xFila.iFilaFinal);
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaPrioridadVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaPrioridadLlena(&xFila)? "True" : "False" );
    SbFilaPrioridadDespliegaVector(&xFila);

    // Eliminamos un Elemento
    xElemento = FnElemFilaPrioridadEliminar(&xFila);
    printf("Se eliminó el Elemento %s con Prioridad %d\n",xElemento.cElemento,xElemento.cPrioridad);

    // Eliminamos un Elemento
    xElemento = FnElemFilaPrioridadEliminar(&xFila);
    printf("Se eliminó el Elemento %s con Prioridad %d\n",xElemento.cElemento,xElemento.cPrioridad);

    // Verificamos Datos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaPrioridadElementos(&xFila));
    // Obtiene el Elemento del Frente
    xElemento =FnElemFilaPrioridadFrente(&xFila);
    printf("El Frente de la Fila : Elemento:%s Prioridad:%d en pos:%d\n" ,xElemento.cElemento,xElemento.cPrioridad,xFila.iFilaFrente);
    xElemento =FnElemFilaPrioridadFinal(&xFila);
    printf("El Final de la Fila  : Elemento:%s Prioridad:%d en pos:%d\n" ,xElemento.cElemento,xElemento.cPrioridad,xFila.iFilaFinal);
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaPrioridadVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaPrioridadLlena(&xFila)? "True" : "False" );
    SbFilaPrioridadDespliegaVector(&xFila);


    // Preparamos elemento a insertar
    strcpy(xElemento.cElemento,"List.txt");
    xElemento.cPrioridad=-2;

    // Insertamos el Elemento
    SbFilaPrioridadInsertar(&xFila,xElemento);

    // Verificamos Datos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaPrioridadElementos(&xFila));
    // Obtiene el Elemento del Frente
    xElemento =FnElemFilaPrioridadFrente(&xFila);
    printf("El Frente de la Fila : Elemento:%s Prioridad:%d en pos:%d\n" ,xElemento.cElemento,xElemento.cPrioridad,xFila.iFilaFrente);
    xElemento =FnElemFilaPrioridadFinal(&xFila);
    printf("El Final de la Fila  : Elemento:%s Prioridad:%d en pos:%d\n" ,xElemento.cElemento,xElemento.cPrioridad,xFila.iFilaFinal);
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaPrioridadVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaPrioridadLlena(&xFila)? "True" : "False" );
    SbFilaPrioridadDespliegaVector(&xFila);

    // Preparamos elemento a insertar
    strcpy(xElemento.cElemento,"List.JPG");
    xElemento.cPrioridad=0;

    // Insertamos el Elemento
    SbFilaPrioridadInsertar(&xFila,xElemento);

    // Verificamos Datos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaPrioridadElementos(&xFila));
    // Obtiene el Elemento del Frente
    xElemento =FnElemFilaPrioridadFrente(&xFila);
    printf("El Frente de la Fila : Elemento:%s Prioridad:%d en pos:%d\n" ,xElemento.cElemento,xElemento.cPrioridad,xFila.iFilaFrente);
    xElemento =FnElemFilaPrioridadFinal(&xFila);
    printf("El Final de la Fila  : Elemento:%s Prioridad:%d en pos:%d\n" ,xElemento.cElemento,xElemento.cPrioridad,xFila.iFilaFinal);
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaPrioridadVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaPrioridadLlena(&xFila)? "True" : "False" );
    SbFilaPrioridadDespliegaVector(&xFila);

    // Eliminamos un Elemento
    xElemento = FnElemFilaPrioridadEliminar(&xFila);
    printf("Se eliminó el Elemento %s con Prioridad %d\n",xElemento.cElemento,xElemento.cPrioridad);

    // Eliminamos un Elemento
    xElemento = FnElemFilaPrioridadEliminar(&xFila);
    printf("Se eliminó el Elemento %s con Prioridad %d\n",xElemento.cElemento,xElemento.cPrioridad);

    // Verificamos Datos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaPrioridadElementos(&xFila));
    // Obtiene el Elemento del Frente
    xElemento =FnElemFilaPrioridadFrente(&xFila);
    printf("El Frente de la Fila : Elemento:%s Prioridad:%d en pos:%d\n" ,xElemento.cElemento,xElemento.cPrioridad,xFila.iFilaFrente);
    xElemento =FnElemFilaPrioridadFinal(&xFila);
    printf("El Final de la Fila  : Elemento:%s Prioridad:%d en pos:%d\n" ,xElemento.cElemento,xElemento.cPrioridad,xFila.iFilaFinal);
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaPrioridadVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaPrioridadLlena(&xFila)? "True" : "False" );
    SbFilaPrioridadDespliegaVector(&xFila);

    // Eliminamos un Elemento
    xElemento = FnElemFilaPrioridadEliminar(&xFila);
    printf("Se eliminó el Elemento %s con Prioridad %d\n",xElemento.cElemento,xElemento.cPrioridad);

    // Verificamos Datos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaPrioridadElementos(&xFila));
    // Obtiene el Elemento del Frente
    xElemento =FnElemFilaPrioridadFrente(&xFila);
    printf("El Frente de la Fila : Elemento:%s Prioridad:%d en pos:%d\n" ,xElemento.cElemento,xElemento.cPrioridad,xFila.iFilaFrente);
    xElemento =FnElemFilaPrioridadFinal(&xFila);
    printf("El Final de la Fila  : Elemento:%s Prioridad:%d en pos:%d\n" ,xElemento.cElemento,xElemento.cPrioridad,xFila.iFilaFinal);
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaPrioridadVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaPrioridadLlena(&xFila)? "True" : "False" );
    SbFilaPrioridadDespliegaVector(&xFila);

    // Preparamos elemento a insertar
    strcpy(xElemento.cElemento,"Lis1.JPG");
    xElemento.cPrioridad=-2;

    // Insertamos el Elemento
    SbFilaPrioridadInsertar(&xFila,xElemento);

    // Preparamos elemento a insertar
    strcpy(xElemento.cElemento,"Lis2.JPG");
    xElemento.cPrioridad=-4;

    // Insertamos el Elemento
    SbFilaPrioridadInsertar(&xFila,xElemento);

    // Verificamos Datos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaPrioridadElementos(&xFila));
    // Obtiene el Elemento del Frente
    xElemento =FnElemFilaPrioridadFrente(&xFila);
    printf("El Frente de la Fila : Elemento:%s Prioridad:%d en pos:%d\n" ,xElemento.cElemento,xElemento.cPrioridad,xFila.iFilaFrente);
    xElemento =FnElemFilaPrioridadFinal(&xFila);
    printf("El Final de la Fila  : Elemento:%s Prioridad:%d en pos:%d\n" ,xElemento.cElemento,xElemento.cPrioridad,xFila.iFilaFinal);
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaPrioridadVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaPrioridadLlena(&xFila)? "True" : "False" );
    SbFilaPrioridadDespliegaVector(&xFila);

  // Preparamos elemento a insertar
    strcpy(xElemento.cElemento,"Lis3.JPG");
    xElemento.cPrioridad=-3;

    // Insertamos el Elemento
    SbFilaPrioridadInsertar(&xFila,xElemento);

    // Verificamos Datos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaPrioridadElementos(&xFila));
    // Obtiene el Elemento del Frente
    xElemento =FnElemFilaPrioridadFrente(&xFila);
    printf("El Frente de la Fila : Elemento:%s Prioridad:%d en pos:%d\n" ,xElemento.cElemento,xElemento.cPrioridad,xFila.iFilaFrente);
    xElemento =FnElemFilaPrioridadFinal(&xFila);
    printf("El Final de la Fila  : Elemento:%s Prioridad:%d en pos:%d\n" ,xElemento.cElemento,xElemento.cPrioridad,xFila.iFilaFinal);
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaPrioridadVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaPrioridadLlena(&xFila)? "True" : "False" );
    SbFilaPrioridadDespliegaVector(&xFila);

    // Finaliza
    return 0;

}




