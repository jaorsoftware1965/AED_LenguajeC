/*
Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE
www.jaorsoftware.cu.cc

Clase 30- Árboles Binarios II

Temas:
-Recorrido de un Árbol Binario
-Contar los Nodos del Árbol
-Altura del Árbol.


Árbol Binario de Ejemplo.

Secuencia a Insertar:10,14,2,27,25,31,5,-2,9

             10                         Nivel 0
        2          14                   Nivel 1
   -2      5            27              Nivel 2
               9      25    31          Nivel 3


Secuencia a Insertar:10,14,2,27,25,31,5,-2,9,----,19,-9,39,49,59

             10                         Nivel 0
        2          14                   Nivel 1
   -2      5            27              Nivel 2
     -9       9      25    31           Nivel 3
                  19          39        Nivel 4
               18               49      Nivel 5
            17                     59   Nivel 6
         16
*/
// Librerias
#include <stdlib.h>
#include <stdio.h>
#include <string.h>


// Constantes
#define TRUE  1
#define FALSE 0

// Define el Cambio de Línea
#define CR printf("\n")

// Defino la Estructura de los Nodos del Árbol
typedef struct NODO_ARBOL
{
   int    iDato;  // Dato del Nodo
   struct NODO_ARBOL *pIzquierdo;  // Apuntador a Hijo Izquierdo
   struct NODO_ARBOL *pDerecho;    // Apuntador a Hijo Derecho
}nodo_arbol;

// Función para crear un Nodo para el Árbol
nodo_arbol *FnArbolNodoCrea(int xDato)
{
   // Defino una variable de tipo Apuntador Nodo
   nodo_arbol *xNodo;

   // Reservo la Memoria para el Nodo
   xNodo = (nodo_arbol *)malloc(sizeof(nodo_arbol));

   // Verifico que haya podido reservar memoria
   if (xNodo == NULL)
      // Despliega el Mensaje de Error
      printf("Error. No se pudo reservar memoria para el Nodo_Arbol");
   else
   {
      // Asigna la Información al Nodo
      xNodo->iDato      = xDato; // El Dato
      xNodo->pDerecho   = NULL;  // Apunta a Null
      xNodo->pIzquierdo = NULL;  // Apunta a Null
   }

   //Retorna el resultado
   return xNodo;
}

// Función para Insertar un Nodo en el Árbol
void SbArbolInsertaNodo(nodo_arbol **pRaiz, int xDato)
{
    // Definimos un Apuntador a un Nodo Nuevo
    nodo_arbol *pNodoNuevo;

    // Definiendo un Apuntador Auxiliar
    nodo_arbol *pAuxiliar;

    // Variable para saber en que nivel se insertó
    int iNivel=1;
    int iPadre=0;

    // Variable para Indicar el Lado de la Inserción
    char sLado[4]="Der";

    // Variables para saber si se insertó correctamente
    int bHuboInsercion = TRUE;

    // Creamos el Nodo Nuevo
    pNodoNuevo=FnArbolNodoCrea(xDato);

    // Verificamos si está vacío el Árbol
    if (*pRaiz==NULL)
    {
        // Lo Asignamos como raíz; el nuevo nodo
        *pRaiz = pNodoNuevo;

        // Mensaje
        printf("Se ha insertado el Dato:%d como Raiz del Arbol\n",xDato);
    }
    // Si no está vacío entramos a un ciclo
    else
    {
       // Colocamos el Auxiliar apuntando a Raíz
       pAuxiliar = *pRaiz;

       // Ciclo
       while (TRUE)
       {
          // Verificamos si es mayor el que quiero insertar
          if (pAuxiliar->iDato < xDato)
              // Verificamos si tiene Hijo Derecho
              if (pAuxiliar->pDerecho!=NULL)
              {
                  // Guardo el Padre
                  iPadre = pAuxiliar->iDato;

                  // Movemos a pAuxiliar al Nodo Derecho
                  pAuxiliar = pAuxiliar->pDerecho;
              }
              else
              {   
                  // No tiene Hijo Derecho; Insertamos
                  pAuxiliar->pDerecho=pNodoNuevo;

                  // Salimos del Ciclo
                  break;
              }
          else
             // Verifica si es Menor el que quiero insertar
             if (pAuxiliar->iDato > xDato)
                // Verificamos si tiene Hijo Izquierdo
                if (pAuxiliar->pIzquierdo!=NULL)
                {
                    // Guardo el Padre
                    iPadre = pAuxiliar->iDato;

                    // Movemos a pAuxiliar al Nodo Izquierdo
                    pAuxiliar = pAuxiliar -> pIzquierdo;
                }
                else
                {   
                    // No tiene Hijo Izquierdo; Insertamos
                    pAuxiliar->pIzquierdo=pNodoNuevo;

                    // Actualizamos el lado para el Mensaje
                    strcpy(sLado,"Izq");

                    // Salimos del Ciclo
                    break;
                 }
             else
             {
                // Se intenta Insertar un Nodo que ya Existe
                bHuboInsercion = FALSE;

                // Sale del Ciclo
                break;
             }

           // Incrementamos el Nivel
           iNivel++;

       }// Fin del Ciclo While

       // Verifica si Inserción Correcta
       if (bHuboInsercion)
          // Mensaje de Inserción
          printf("Se ha insertado el Dato:%02d como Hijo %s de:%02d en el Nivel:%d \n",xDato,sLado,pAuxiliar->iDato,iNivel);
       else
          // Mensaje de Error
          printf("Error. el Dato:%d ya existe como hijo de:%d en el Nivel:%d \n",xDato,iPadre,--iNivel);

    }
}

// Recorre el Árbol
void SbArbolRecorre(nodo_arbol *pNodo)
{
     // Verifica que no sea Null
     if (pNodo==NULL)
        // Finaliza la Función
        return;
     else
     {
        // Imprime el Contenido del Nodo
        printf("%d \n",pNodo->iDato);

        // Llama a misma Función con el Hijo Izquierdo
        SbArbolRecorre(pNodo->pIzquierdo);

        // Llama a misma Función con el Hijo Derecho
        SbArbolRecorre(pNodo->pDerecho);
     }
}

// Imprimir N Espacios
void SbEspaciosImprime(int iNumero)
{
   int iCuenta;
   for (iCuenta=0;iCuenta<=iNumero;iCuenta++)
       printf(" ");
}

// Recorre el Árbol Nivel
void SbArbolRecorreNivel(nodo_arbol *pNodo,int iNivel)
{

     // Verifica que no sea Null
     if (pNodo==NULL)
        // Finaliza la Función
        return;
     else
     {
        // Imprime los Espacios de acuerdo al Nivel
        SbEspaciosImprime(iNivel*3);

        // Imprime el Contenido del Nodo
        printf("%d Nivel %d \n",pNodo->iDato,iNivel);

        // Incrementamos el Nivel
        iNivel++;

        // Llama a misma Función con el Hijo Izquierdo
        SbArbolRecorreNivel(pNodo->pIzquierdo,iNivel);
        SbArbolRecorreNivel(pNodo->pDerecho,iNivel);
     }
}

// Recorre el Árbol
void SbArbolRecorreNivelLado(nodo_arbol *pNodo,int iNivel,char cLado)
{

     // Verifica que no sea Null
     if (pNodo==NULL)
        // Finaliza la Función
        return;
     else
     {
        // Imprime los Espacios de acuerdo al Nivel
        SbEspaciosImprime(iNivel*3);

        // Imprime el Contenido del Nodo
        printf("%c-%d Nivel %d \n",cLado,pNodo->iDato,iNivel);

        // Incrementamos el Nivel
        iNivel++;

        // Llama a misma Función con el Hijo Izquierdo
        SbArbolRecorreNivelLado(pNodo->pIzquierdo,iNivel,'I');
        SbArbolRecorreNivelLado(pNodo->pDerecho,iNivel,'D');
     }
}


// Cuenta los Nodos del Árbol
int FnIntArbolNodos(nodo_arbol *pNodo)
{

     // Para devolver el Resultado
     int iHijosDerechos=0;
     int iHijosIzquierdos=0;

     // Verifica que no sea Null
     if (pNodo==NULL)
        // Finaliza la Función
        return 0;
     else
     {

        // Obtiene los Hijos Derechos
        iHijosDerechos=FnIntArbolNodos(pNodo->pDerecho);

        // Obtiene los Hijos Izquierdos
        iHijosIzquierdos=FnIntArbolNodos(pNodo->pIzquierdo);

        // Retorno el Resultado
        return 1 + iHijosDerechos + iHijosIzquierdos;
     }
}

// Recorre el Árbol y Obtiene su Altura
int FnIntArbolAltura(nodo_arbol *pNodo,int iNivel)
{
     // Variables para obtener resultados
     int iResult1=0;
     int iResult2=0;

     // Para devolver el Resultado
     int iResult=0;

     // Verifica que no sea Null
     if (pNodo==NULL && iNivel==0)
        // El Árbol está vacío
        return -1;
     else
        if (pNodo==NULL)
           // Finaliza la Función
           return 0;
        else
        {
           // Obtiene el Grado del Hijo Derecho
           iResult1=FnIntArbolAltura(pNodo->pDerecho,iNivel+1);
           iResult2=FnIntArbolAltura(pNodo->pIzquierdo,iNivel+1);

           // Acá verifico cual de los 2 niveles es el mayor
           if (iResult1>=iResult2 && iResult1 >= iNivel)
              return iResult1;
           else
              if (iResult2>=iResult1 && iResult2 >= iNivel)
                 return iResult2;
              else
                 return iNivel;
        }
}

// Función Principal
int main()
{
    // Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 30 - Árboles Binarios II \n\n");

    // Declaro el Apuntador a la Raíz.
    nodo_arbol *pRaiz=NULL;

    // Imprime la Altura del Árbol
    printf("Altura del Arbol:%d \n",FnIntArbolAltura(pRaiz,0));
    // Pausa
    getc(stdin);

    // Secuencia a Insertar:10,14,2,27,25,31,5,-2,9,----,19,-9,39,49,59
    printf("Creando el Arbol Binario con la siguiente Secuencia:10,14,2,27,25,31,5,-2,9\n");
    SbArbolInsertaNodo(&pRaiz,10);

     // Imprime la Altura del Árbol
    printf("Altura del Arbol:%d \n",FnIntArbolAltura(pRaiz,0));

    SbArbolInsertaNodo(&pRaiz,14);
    SbArbolInsertaNodo(&pRaiz,2);
    SbArbolInsertaNodo(&pRaiz,27);
    SbArbolInsertaNodo(&pRaiz,25);
    SbArbolInsertaNodo(&pRaiz,31);
    SbArbolInsertaNodo(&pRaiz,5);
    SbArbolInsertaNodo(&pRaiz,-2);
    SbArbolInsertaNodo(&pRaiz,9);
    getc(stdin);

    // Agregue mas nodos para verificar Altura
    SbArbolInsertaNodo(&pRaiz,19);
    SbArbolInsertaNodo(&pRaiz,-9);
    SbArbolInsertaNodo(&pRaiz,39);
    SbArbolInsertaNodo(&pRaiz,49);
    SbArbolInsertaNodo(&pRaiz,59);
    SbArbolInsertaNodo(&pRaiz,18);
    SbArbolInsertaNodo(&pRaiz,17);
    SbArbolInsertaNodo(&pRaiz,16);
    getc(stdin);

    // Deja una Línea
    CR;

    // Recorre el Árbol
    printf("Recorrido Simple del Árbol \n");
    SbArbolRecorre(pRaiz);
    getc(stdin);

    // Deja una Línea
    CR;

    // Recorre el Árbol con Nivel
    printf("Recorrido del Arbol con Nivel, Indentación \n");
    SbArbolRecorreNivel(pRaiz,0);
    getc(stdin);

    // Deja una Línea
    CR;

    // Recorre el Árbol con Nivel y Lado
    SbArbolRecorreNivelLado(pRaiz,0,'R');
    getc(stdin);

    // Deja una Línea
    CR;

    // Imprime el Número de Nodos del Árbol
    printf("Nodos del Arbol:%d \n",FnIntArbolNodos(pRaiz));
    getc(stdin);

    // Imprime la Altura del Árbol
    printf("Altura del Arbol:%d \n",FnIntArbolAltura(pRaiz,0));
    getc(stdin);


    // Finaliza la aplicación retornando 0
    return 0;
}
