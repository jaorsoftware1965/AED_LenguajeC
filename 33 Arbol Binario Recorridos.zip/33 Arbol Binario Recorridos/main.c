/*
Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE
www.jaorsoftware.cu.cc

Clase 33 - Árbol Binario Recorridos

Se le conoce como Recorrido de un árbol, a la secuencia
o lógica que es posible seguir para recorrer todos sus nodos.

Existen 2 tipos de recorridos: por anchura o por profundidad.
Los mas comunes y utilizados son los recorridos por profundidad
los cuales son lo que estudiaremos en este clase.

Existen 3 tipos de recorridos en profundidad:
- Pre  - Orden.
- In   - Orden.
- Post - Orden.

  4
3   5
Pre -> 4, 3, 5       4, 5, 3
In  -> 3, 4, 5       5, 4, 3
Post-> 3, 5, 4       5, 3, 4

Los prefijos Pre, In y Post; hacen referencia al nodo raíz; es decir.

En el Recorrido Pre-Orden; primero se visita el Nodo Raíz; posteriormente
el Nodo Izquierdo y finalmente el Nodo Derecho. El prefijo Pre; indica que
la Raiz va primero.

En el Recorrido In-Orden, primero se visita el Nodo Izquierdo; posteriormente
la Raíz; y finalmente el Nodo Derecho. El Prefijo In; hace referencia a que
la Raíz va en medio del Nodo Izquierdo y del Nodo Derecho.

Finalmente en el Recorrido Post-Orden; primero se visita el Nodo Izquierdo;
luego el Nodo Derecho; y finalmente la Raíz. El Prefijo Post, indica que la
Raíz va posterior a los nodos Izquierdo y Derecho.

Nota. Siempre se visita el Nodo Izquierdo y luego el Derecho; por el hecho
de que la Lectura; se realiza de Izquierda a Derecha.

Ejemplo; suponga el siguiente Árbol Binario.


                       10
                2             14
                    5                27
                                 25       31

Pre -> 10, 2,  5, 14, 27, 25, 31
In  ->  2, 5, 10, 14, 25, 27, 31
Post->  5, 2, 25, 31, 27, 14, 10



Recorrido en Pre-Orden.
Raiz,Izquierdo,Derecho.
10-2-5-14-27-25-31

Recorrido en In-Orden.
Izquierdo,Raiz,Derecho.
2-5-10-14-25-27-31

Recorrido en Post-Orden.
Izquierdo,Derecho,Raiz.
5-2-25-31-27-14-10

*/

// Librerias
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

// Constantes
#define TRUE  1
#define FALSE 0

// Define el Cambio de Línea
#define CR printf("\n")

// Defino la Estructura de los Nodos del Árbol
typedef struct NODO_ARBOL
{
   int    iDato;  // Dato del Nodo
   struct NODO_ARBOL *pIzquierdo;  // Apuntador a Hijo Izquierdo
   struct NODO_ARBOL *pDerecho;    // Apuntador a Hijo Derecho
}nodo_arbol;

// Función para crear un Nodo para el Árbol
nodo_arbol *FnArbolNodoCrea(int xDato)
{
   // Defino una variable de tipo Apuntador Nodo
   nodo_arbol *xNodo;

   // Reservo la Memoria para el Nodo
   xNodo = (nodo_arbol *)malloc(sizeof(nodo_arbol));

   // Verifico que haya podido reservar memoria
   if (xNodo == NULL)
      // Despliega el Mensaje de Error
      printf("Error. No se pudo reservar memoria para el Nodo_Arbol");
   else
   {
      // Asigna la Información al Nodo
      xNodo->iDato      = xDato; // El Dato
      xNodo->pDerecho   = NULL;  // Apunta a Null
      xNodo->pIzquierdo = NULL;  // Apunta a Null
   }

   //Retorna el resultado
   return xNodo;
}

// Función para Insertar un Nodo en el Árbol
void SbArbolInsertaNodo(nodo_arbol **pRaiz, int xDato)
{
    // Definimos un Apuntador a un Nodo Nuevo
    nodo_arbol *pNodoNuevo;

    // Definiendo un Apuntador Auxiliar
    nodo_arbol *pAuxiliar;

    // Variable para saber en que nivel se insertó
    int iNivel=1;
    int iPadre=0;

    // Variable para Indicar el Lado de la Inserción
    char sLado[4]="Der";

    // Variables para saber si se insertó correctamente
    int bHuboInsercion = TRUE;

    // Creamos el Nodo Nuevo
    pNodoNuevo=FnArbolNodoCrea(xDato);

    // Verificamos si está vacío el Árbol
    if (*pRaiz==NULL)
    {
        // Lo Asignamos como raiz; el nuevo nodo
        *pRaiz = pNodoNuevo;

        // Mensaje
        printf("Se ha insertado el Dato:%d como Raiz del Arbol\n",xDato);
    }
    // Si no está vacío entramos a un ciclo
    else
    {
       // Colocamos el Auxiliar apuntando a raiz
       pAuxiliar = *pRaiz;

       // Ciclo
       while (TRUE)
       {
          // Verificamos si es mayor el que quiero insertar
          if (pAuxiliar->iDato < xDato)
              // Verificamos si tiene Hijo Derecho
              if (pAuxiliar->pDerecho!=NULL)
              {
                  // Guardo el Padre
                  iPadre = pAuxiliar->iDato;

                  // Movemos a pAuxiliar al Nodo Derecho
                  pAuxiliar = pAuxiliar->pDerecho;
              }
              else
              {   
                  // No tiene Hijo Derecho; Insertamos
                  pAuxiliar->pDerecho=pNodoNuevo;

                  // Salimos del Ciclo
                  break;
              }
          else
             // Verifica si es Menor el que quiero insertar
             if (pAuxiliar->iDato > xDato)
                // Verificamos si tiene Hijo Izquierdo
                if (pAuxiliar->pIzquierdo!=NULL)
                {
                    // Guardo el Padre
                    iPadre = pAuxiliar->iDato;

                    // Movemos a pAuxiliar al Nodo Izquierdo
                    pAuxiliar = pAuxiliar -> pIzquierdo;
                }
                else
                {   
                    // No tiene Hijo Izquierdo; Insertamos
                    pAuxiliar->pIzquierdo=pNodoNuevo;

                    // Actualizamos el lado para el Mensaje
                    strcpy(sLado,"Izq");

                    // Salimos del Ciclo
                    break;
                 }
             else
             {
                // Se intenta Insertar un Nodo que ya Existe
                bHuboInsercion = FALSE;

                // Sale del Ciclo
                break;
             }

           // Incrementamos el Nivel
           iNivel++;

       }// Fin del Ciclo While

       // Verifica si Inserción Correcta
       if (bHuboInsercion)
          // Mensaje de Inserción
          printf("Se ha insertado el Dato:%02d como Hijo %s de:%02d en el Nivel:%d \n",xDato,sLado,pAuxiliar->iDato,iNivel);
       else
          // Mensaje de Error
          printf("Error. el Dato:%d ya existe como hijo de:%d en el Nivel:%d \n",xDato,iPadre,--iNivel);

    }
}


// Recorre el Árbol en Pre-Orden:
//    4
//  3   5
// Raiz - Izquierdo - Derecho
void SbArbolRecorridoPreOrden(nodo_arbol *pNodo)
{
     // Verifica que no sea Null
     if (pNodo==NULL)
        // Finaliza la Función
        return;
     else
     {
        // Imprime el Contenido del Nodo
        printf("%d \n ",pNodo->iDato);                      // 4

        // Llama a misma Función con el Hijo Izquierdo
        SbArbolRecorridoPreOrden(pNodo->pIzquierdo);    // 3

        // Llama a misma Función con el Hijo Derecho
        SbArbolRecorridoPreOrden(pNodo->pDerecho);                  // 5
     }
}

// Recorre el Árbol en In-Orden:
// Izquierdo - Raiz - Derecho
void SbArbolRecorridoInOrden(nodo_arbol *pNodo)
{
     // Verifica que no sea Null
     if (pNodo==NULL)
        // Finaliza la Función
        return;
     else
     {
        // Llama a misma Función con el Hijo Izquierdo
        SbArbolRecorridoInOrden(pNodo->pIzquierdo);

        // Imprime el Contenido del Nodo
        printf("%d \n",pNodo->iDato);

        // Llama a misma Función con el Hijo Derecho
        SbArbolRecorridoInOrden(pNodo->pDerecho);
     }
}

// Recorre el Árbol en Post-Orden:
// Izquierdo - Derecho - Raiz
void SbArbolRecorridoPostOrden(nodo_arbol *pNodo)
{
     // Verifica que no sea Null
     if (pNodo==NULL)
        // Finaliza la Función
        return;
     else
     {
        // Llama a misma Función con el Hijo Izquierdo
        SbArbolRecorridoPostOrden(pNodo->pIzquierdo);  // 3

        // Llama a misma Función con el Hijo Derecho
        SbArbolRecorridoPostOrden(pNodo->pDerecho);    // 5

        // Imprime el Contenido del Nodo
        printf("%d \n",pNodo->iDato);                  // 4
     }
}


// Función Principal
int main(int argc, const char* argv[])
{
    int indice;
    for (indice=0; indice< argc; indice++)
    {
        printf("[%s]\n",argv[indice]);
        getc(stdin);
    }

    // Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 33 - Árboles Binarios Recorridos \n\n");

     
    // Declaro el Apuntador a la Raíz.
    nodo_arbol *pRaiz=NULL;

    // Secuencia a Insertar:10,14,2,27,25,31,5
    printf("Creando el Árbol Binario \n");

    // Insertamos la Secuencia
    SbArbolInsertaNodo(&pRaiz,10);//                  10
    SbArbolInsertaNodo(&pRaiz,2); //           2             14
    SbArbolInsertaNodo(&pRaiz,14);//                               27
    SbArbolInsertaNodo(&pRaiz,27);//                                   
    SbArbolInsertaNodo(&pRaiz,25);//                           25
    SbArbolInsertaNodo(&pRaiz,31);//                                   31
    SbArbolInsertaNodo(&pRaiz,5); //               5

    printf("Recorrido en Pre-Orden \n");
    SbArbolRecorridoPreOrden(pRaiz);//  10,2,5,14,27,25,31
    CR;CR;
    getc(stdin);

    printf("Recorrido en In-Orden \n");
    SbArbolRecorridoInOrden(pRaiz); //  2,5,10,14,25,27,31
    CR;CR;
    getc(stdin);

    printf("Recorrido en Post-Orden \n");
    SbArbolRecorridoPostOrden(pRaiz);// 5,2,25,31,27,14,10
    CR;CR;
    getc(stdin);

    // Finaliza la aplicación retornando 0
    return 0;
}
