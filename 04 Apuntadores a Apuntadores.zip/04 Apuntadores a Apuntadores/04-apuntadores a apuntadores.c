/*
Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE
www.jaorsoftware.com

Clase 04 - Apuntadores a Apuntadores

Un puntero puede apuntar a otra variable puntero. 
Este concepto se utiliza con mucha frecuencia en
programas complejos de C. 
Para declarar un puntero a un puntero se hace 
preceder a la variable con dos asteriscos (**).

Utilizando la características de "cast" veremos que 
no es necesario declarar un apuntador de
apuntador para poder realizar una referencia tal cual.

*/

// Librerias
#include <stdio.h>
#include <stdlib.h>

int main()
{
    // Desplegamos Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 04 - Apuntadores a Apuntadores \n\n");

    int   iValor=10;  // Variable int
    int  *piValor;    // Variable apuntador a int
    int **ppiValor;   // Variable apuntador a apuntador a int
    int  *piOtro;     // Variable apuntador a int

    // Asiganos a piValor la dirección de la variable int iValor
    piValor=&iValor;

    // Asignamos a ppiValor la dirección de la variable apuntador a int piValor
    ppiValor=&piValor;

    // Asignamos a piOtro la dirección de la variable apuntador int piValor
    piOtro = (int *)&piValor;

    printf("Valores Iniciales\n");
    printf("El valor de iValor .................:%d\n",iValor);
    printf("La dirección de iValor .............:%p\n",&iValor);
    printf("La dirección a que apunta piValor ..:%p\n",piValor);
    printf("El valor de iValor desde piValor  ..:%d\n",*piValor);
    printf("La dirección de piValor ............:%p\n",&piValor);
    printf("La dirección a que apunta ppiValor..:%p\n",ppiValor);
    printf("El valor de iValor desde ppiValor ..:%d\n",**ppiValor);
    printf("La dirección a que apunta piOtro ...:%p\n",piOtro);
    printf("La dirección de iValor desde piOtro :%p\n",   *piOtro);
    printf("El valor de iValor desde piOtro ....:%d\n\n",*(int *)(*piOtro));

    // Asignamos al Contenido de piOtro la direccin a la que apunta piValor
    
    *piOtro = (int)piValor;
    printf("La dirección de iValor desde piOtro :%p\n"  ,        (*piOtro));
    printf("El valor de iValor desde piOtro ....:%d\n\n",*(int *)(*piOtro));

    // Asignamos al Contenido del primer apuntador de ppiValor la dirección a que apunta piValor
    *ppiValor =piValor;
    printf("La dirección a que apunta ppiValor..:%p\n",ppiValor);
    printf("El valor de iValor desde ppiValor ..:%d\n\n",**ppiValor);

    // Modificamor el Valor de la variable int iValor a través de ppiValor
    **ppiValor =30;
    printf("El valor de iValor .................:%d\n",iValor);
    printf("La dirección a que apunta ppiValor..:%p\n",ppiValor);
    printf("El valor de iValor desde ppiValor ..:%d\n\n",**ppiValor);

     // Asignamos al Contenido de piOtro la direccin a la que apunta piValor
    *piOtro = (int)piValor;
    printf("La dirección de iValor desde piOtro :%p\n",(int *)(*piOtro));
    printf("El valor de iValor desde piOtro ....:%d\n\n",*(int *)(*piOtro));

    // Declara una variable entera x con valor de 30
    // declarar un apuntador de int y coloca la direcccion de x
    // declarar un apuntador de apuntador y coloca el valor 
    // del anterior apuntador
    // Modifica el valor de x desde el apuntador a integer
    // Imprime x
    // Modifica el valor de x desde el apuntador de apuntador
    // Imprime x


    return 0;
}

