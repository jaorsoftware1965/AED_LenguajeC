/*
Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE
www.jaorsoftware.com

Clase 16 - Filas II

SEGUNDO MÉTODO.
Para este segundo método, seguiremos considerando que la
inserción se sigue realizando de la forma que ya se explicó
en la clase anterior; excepto un caso que veremos en esta
clase. Es decir. Cuando un elemento se inserta en la Fila;
se inserta al Final.

Ahora veremos las circunstancias que se presentan en el Segundo
Método para cuando deseamos realizar una eliminación.

Cuando se saca un elemento de la Fila
a) Si es que hay mas de un elemento en la fila; es decir; que el
   apuntador Final es mayor que el frente; el apuntador del
   frente se mueve a la posición que está detrás

Frente -> 1
Final  -> 4
FILA      | |21|12|08|43|  Se saca el 10 y frente apunta a 1


b) Si hay solo un elemento en la fila; la Fila es Inicializada
   para colocar de nuevo los apuntadores a -1.

Frente -> 4
Final  -> 4
FILA      |  |  |  |  |43|

Cuando se saca el 43; los apuntadores se reinician. Esto se
debe realizar, cuando se elimina un elemento y solamente hay
uno en la lista.

Frente -> 1
Final  -> 3
FILA      |  |12 |45 |67  |  |

Utilizando este método; la forma de saber cuantos elementos
hay en la Fila es:
Elementos = Final-Frente + 1

EXCEPCIÓN AL INGRESAR.
Cuando se intenta agregar un elemento y ya está ocupada la
última posición; entonces se debe de verificar  el número
de elementos; y si este es menor que el tamaño de la Fila
entonces se debe de realizar el recorrido de los elementos
hacia el frente.

Frente -> 4
Final  -> 4
FILA      |  |  |  |  |43|

Intento ingresar el 54

Frente -> 1
Final  -> 1
FILA      |43|  |  |  |  |

Frente -> 0
Final  -> 1
FILA      |43|54|  |  |  |

FILA LLENA.
Con este método, una Fila esta llena; cuando el Número de
elementos, es igual al tamaño de la Fila.

Lo Necesario para implementar el Método

Tamaño.
Frente.
Final .
Inicializa().
Insertar().  *
Eliminar().  *
FilaVacía().
FilaLlena(). *
FilaFrente().
FilaFinal().
Recorre().   *
*/

// Librerias
#include "stdio.h"

// Constantes
#define TRUE  1
#define FALSE 0

// Definimos el Tamaño de la Fila
#define FILA_TAMANIO 5

// Definimos la estructura de la Fila
typedef struct stcFila
{
    // Variable para manejar el frente y final de la Fila
    int  iFilaFrente;
    int  iFilaFinal;

    // El Arreglo para la Fila
    int arrIntFila[FILA_TAMANIO];

}fila;

// Implementamos Inicializar la Fila
void SbFilaInicializa(fila *pFila)
{
   // Para Inicializar la Fila basta con poner el frente y final a -1
   // Ya que el primer elemento ocupa la posición 0
   pFila->iFilaFrente=-1;
   pFila->iFilaFinal =-1;

   // Ciclo para llenar con 0's la fila
   for (int i=0; i<FILA_TAMANIO; i++)   
       pFila->arrIntFila[i]=0;

   // Desplegamos Mensaje
   printf("Fila Inicializada ...\n");
}

// Implementamos Verificar si la Fila está vacía
int FnIntFilaVacia(fila *pFila)
{
    if (pFila->iFilaFinal==-1)
        return TRUE;
    else
        return FALSE;
}

// Implementamos Obtener cuantos elementos tiene la Fila
int FnIntFilaElementosII(fila *pFila)
{
    if (FnIntFilaVacia(pFila))
        return 0;
    else
       // Retorna en base al Final y Frente
       return pFila->iFilaFinal - pFila->iFilaFrente + 1;

}

// Implementamos Verificar si la Fila está llena
int FnIntFilaLlena(fila *pFila)
{
    if (pFila->iFilaFinal+1 == FILA_TAMANIO)
       return TRUE;
    else
       return FALSE;    
}


// Implementamos para Obtener el Elemento del Frente de la Fila
int FnIntFilaFrente(fila *pFila)
{
    // Verificamos si la Fila está vacía
    if (!FnIntFilaVacia(pFila))
    {
       return(pFila->arrIntFila[pFila->iFilaFrente]);
    }
    else
    {
       printf("La Fila está vacia; no hay frente\n");
       return (-1);
    }           
}

// Implementamos para Obtener el Elemento del Final de la Fila
int FnIntFilaFinal(fila *pFila)
{
    // Verificamos si la Fila está vacía
    if (FnIntFilaVacia(pFila))
    {
       printf("La Fila está vacia; no hay final\n");
       return (-1);
    }
    else
       return(pFila->arrIntFila[pFila->iFilaFinal]);
}
// Implementamos Insertar un Elemento en la Fila
void SbFilaInsertar(fila *pFila,int iElemento)
{
    // Verificamos si la Fila está llena
    if (FnIntFilaLlena(pFila))
       printf("La Fila está llena y no es posible agregar el elemento:%d\n",iElemento);
    else
    {
       // Verificamos si fue el primer elemento para asignar el frente
       if (pFila->iFilaFrente==-1)
           pFila->iFilaFrente=0;

       // Agrega el Elemento a la Fila
       pFila->arrIntFila[++pFila->iFilaFinal] = iElemento;
    }
}

// Implementamos Verificar si la Fila está llena
int FnIntFilaLlenaII(fila *pFila)
{
    if (FnIntFilaElementosII(pFila)==FILA_TAMANIO)
       return TRUE;
    else
       return FALSE;
}

// Ciclo para recorrer los elementos de la fila
void SbFilaRecorreII(fila *pFila)
{
    // Variable para el Índice
    char iIndice1;
    char iIndice2;

    // Ciclo para recorrer
    for (iIndice1 = 0, iIndice2 = pFila->iFilaFrente, printf("Inicio \n"); iIndice2<=pFila->iFilaFinal;iIndice1++,iIndice2++, printf("Final \n"))
        // Recorre el Dato
        pFila->arrIntFila[iIndice1]=pFila->arrIntFila[iIndice2];

    // Recorre el referenciador de la parte final
    pFila->iFilaFinal = pFila->iFilaFinal - pFila->iFilaFrente;

    // Manda el frente a la posición 0
    pFila->iFilaFrente=0;
}

// Implementamos Insertar un Elemento en la Fila
void SbFilaInsertarII(fila *pFila,int iElemento)
{
    // Verificamos si la Fila está llena
    if (FnIntFilaLlenaII(pFila))
       printf("La Fila está llena y no es posible agregar el elemento:%d\n",iElemento);
    else
    {
       // Verificamos si fue el primer elemento para asignar el frente
       if (FnIntFilaVacia(pFila)) // Ojo 1
           pFila->iFilaFrente=0;
       else // Verificamos está en la última posición
          if (pFila->iFilaFinal+1==FILA_TAMANIO)
             SbFilaRecorreII(pFila);       
       // Agrega el Elemento a la Fila
       pFila->arrIntFila[++pFila->iFilaFinal]=iElemento;
    }
}

// Implementamos Eliminar un Elemento de la Fila
int FnIntFilaEliminarII(fila *pFila)
{
    // El valor a devolver
    int iResult;

    // Verificamos si la Fila está vacía
    if (FnIntFilaVacia(pFila))
    {
       printf("La Fila está vacía no es posible sacar elementos\n");
       iResult=-1;
    }
    else
    {
       // Obtiene el Elemento a Devolver y Eliminar
       iResult = pFila->arrIntFila[pFila->iFilaFrente];

       // Verifica si solo hay un elemento
       if (pFila->iFilaFinal==pFila->iFilaFrente)
       {
          // Inicializa Ojo 2
          pFila->arrIntFila[pFila->iFilaFrente]=0;
          pFila->iFilaFinal=-1;
          pFila->iFilaFrente=-1;
       }
       else
       {
           // Dejamos en 0
           pFila->arrIntFila[pFila->iFilaFrente] = 0;
           // Mueve el referenciador del Frente
           pFila->iFilaFrente++; // Ojo 3
       }
    }

    // Devuelve el resultado
    return(iResult);
}

// Programa Principal
int main()
{
    // Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 16 - Filas II \n\n");

    // Declara la variable de la Fila
    fila xFila;
    // Inicializa la Fila
    SbFilaInicializa(&xFila);

    // Verificamos elementos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaElementosII(&xFila));
    printf("El Frente de la Fila : %d\n"  ,FnIntFilaFrente(&xFila));
    printf("El Final   de la Fila: %d\n"  ,FnIntFilaFinal(&xFila));
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila)? "Si esta vacia" : "No esta vacia" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaLlenaII(&xFila)? "Si esta llena" : "No esta llena" );

    // Agrega elementos a la Fila
    printf("Agregamos el 10 a la Fila \n\n");
    SbFilaInsertarII(&xFila,10);

    // Verificamos elementos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaElementosII(&xFila));
    printf("El Frente de la Fila : %d\n"  ,FnIntFilaFrente(&xFila));
    printf("El Final   de la Fila: %d\n"  ,FnIntFilaFinal(&xFila));
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaLlenaII(&xFila)? "True" : "False" );


    // Agrega elementos a la Fila
    printf("Agregamos el 13 a la Fila \n\n");
    SbFilaInsertarII(&xFila,13);

    // Verificamos elementos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaElementosII(&xFila));
    printf("El Frente de la Fila : %d\n"  ,FnIntFilaFrente(&xFila));
    printf("El Final   de la Fila: %d\n"  ,FnIntFilaFinal(&xFila));
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaLlenaII(&xFila)? "True" : "False" );

    // Agregamos 4 Elementos
    printf("Agregamos el 34,45,67,78 a la Fila \n\n");
    SbFilaInsertarII(&xFila,34);
    SbFilaInsertarII(&xFila,45);
    SbFilaInsertarII(&xFila,67);
    SbFilaInsertarII(&xFila,78);

    // Verificamos elementos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaElementosII(&xFila));
    printf("El Frente de la Fila : %d\n"  ,FnIntFilaFrente(&xFila));
    printf("El Final   de la Fila: %d\n"  ,FnIntFilaFinal(&xFila));
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaLlenaII(&xFila)? "True" : "False" );

    // Eliminamos un Elemento y Verificamos
    printf("Eliminamos del Frente de La Fila :%d \n",FnIntFilaEliminarII(&xFila));
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaElementosII(&xFila));
    printf("El Frente de la Fila : %d\n"  ,FnIntFilaFrente(&xFila));
    printf("El Final   de la Fila: %d\n"  ,FnIntFilaFinal(&xFila));
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaLlenaII(&xFila)? "True" : "False" );

    // Eliminamos un Elemento y Verificamos
    printf("Eliminamos del Frente de La Fila :%d \n",FnIntFilaEliminarII(&xFila));
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaElementosII(&xFila));
    printf("El Frente de la Fila : %d\n"  ,FnIntFilaFrente(&xFila));
    printf("El Final   de la Fila: %d\n"  ,FnIntFilaFinal(&xFila));
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaLlenaII(&xFila)? "True" : "False" );

    // Insertamos y ya estamos en el final y hay espacio
    SbFilaInsertarII(&xFila,134);

    // Eliminando 4 Elementos
    printf("Eliminamos del Frente de La Fila :%d \n",FnIntFilaEliminarII(&xFila));
    printf("Eliminamos del Frente de La Fila :%d \n",FnIntFilaEliminarII(&xFila));
    printf("Eliminamos del Frente de La Fila :%d \n",FnIntFilaEliminarII(&xFila));
    printf("Eliminamos del Frente de La Fila :%d \n\n",FnIntFilaEliminarII(&xFila));


    // Agregamos un Elemento
    printf("Agregamos el 10 a la Fila \n\n");
    SbFilaInsertarII(&xFila,10);

    // Verificamos elementos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaElementosII(&xFila));
    printf("El Frente de la Fila : %d\n"  ,FnIntFilaFrente(&xFila));
    printf("El Final   de la Fila: %d\n"  ,FnIntFilaFinal(&xFila));
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaLlenaII(&xFila)? "True" : "False" );

    // Agregamos un Elemento
    printf("Agregamos el 20 a la Fila \n\n");
    SbFilaInsertarII(&xFila,20);

    // Verificamos elementos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaElementosII(&xFila));
    printf("El Frente de la Fila : %d\n"  ,FnIntFilaFrente(&xFila));
    printf("El Final   de la Fila: %d\n"  ,FnIntFilaFinal(&xFila));
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaLlenaII(&xFila)? "True" : "False" );


    // Eliminamos del Frente de la Fila
    printf("Eliminamos del Frente de La Fila :%d \n",FnIntFilaEliminarII(&xFila));

    // Verificamos elementos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaElementosII(&xFila));
    printf("El Frente de la Fila : %d\n"  ,FnIntFilaFrente(&xFila));
    printf("El Final   de la Fila: %d\n"  ,FnIntFilaFinal(&xFila));
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaLlenaII(&xFila)? "True" : "False" );

    // Eliminamos del Frente de la Fila
    printf("Eliminamos del Frente de La Fila :%d \n",FnIntFilaEliminarII(&xFila));

    // Verificamos elementos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaElementosII(&xFila));
    printf("El Frente de la Fila : %d\n"  ,FnIntFilaFrente(&xFila));
    printf("El Final   de la Fila: %d\n"  ,FnIntFilaFinal(&xFila));
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaLlenaII(&xFila)? "True" : "False" );


    // Finaliza
    return 0;

}


