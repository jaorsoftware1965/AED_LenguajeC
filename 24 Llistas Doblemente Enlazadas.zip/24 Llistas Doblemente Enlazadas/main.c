/*
Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR


Clase 24 - Listas Doblemente Enlazadas

Toca el tema ahora a otro tipo de Listas Llamadas Doblemente Enlazadas.
Una Lista Doblemente enlazada, es aquella que dentro su nodo, contiene
un apuntador adicional, el cual apunta al nodo anterior. Es decir.
Cada nodo de la lista, contará con el Valor del Nodo; un apuntador al
siguiente nodo; y un apuntador al nodo anterior.

GRÁFICAMENTE.

      CABEZA
         |
         |
       Nodo1       Nodo2      Nodo3     Nodo4      Nodo5
nil<--|PAnter|<--|PAnter|<--|PAnter|<--|PAnter|<--|PAnter|
      |Valor1|   |Valor2|   |Valor3|   |Valor4|   |Valor5|
      |PSigte|-->|PSigte|-->|PSigte|-->|PSigte|-->|PSigte|-->nil

El hecho de que cada nodo tenga un apuntador a anterior, permite hacer
un recorrido de la lista en forma inversa; es decir; partiendo del último
elemento y recorriendo la lista hacia atrás hasta llegar al principio.

Con un único Apuntador; CABEZA; es suficiente para poder controlar las
operaciones de una Lista Doblemente Enlazada; solo que para hacer el recorrido
inverso, primeramente se tendría que ir hacia el último elemento de la lista
y a partir de ahí; recorrer hacia atrás. Si no se quiere realizar este recorrido;
la Lista deberá de contar con al Apuntador COLA; el cual apuntaría al elemento
final de la Lista.

Para esta clase, construiremos la Lista Doblemente Enlazada, únicamente con
apuntador CABEZA; para la siguiente clase; la construiremos adicionando el
apuntador COLA.

Ahora analizaremos cada uno de los Procesos que implentaremos en la Lista
Doblemente Enlazada.

INSERTAR. Cuando la Lista está Vacía

a) Crear el Nodo con el Valor Correspondiente
b) Siguiente y anterior apunta a NULL
c) Hacer que Cabeza apunte al Nodo Nuevo.

GRAFICAMENTE

      CABEZA
         |
         |
       NodoNvo
nil<--|PAnter|
      |Valor1|
      |PSigte|-->nil


INSERTAR. Al Inicio de la Lista

a) Crear el Nodo Nuevo con el Valor Correspondiente.
b) Hacer que CABEZA->Anterior apunte al Nuevo Nodo
c) Hacer que el Nuevo Nodo->Siguiente Apunte al Nodo que apunta Cabeza
d) Hacer que el Nuevo Nodo->Anterior apunte a NULL
e) Hacer que CABEZA Apunte al Nvo Nodo

GRAFICAMENTE

       CABEZA
         |
         |
       NodoNvo    Nodo1
nil<--|PAnter|<--|PAnter|
      |ValorN|   |Valor1|
      |PSigte|-->|pSigte|-->nil

ELIMINAR DEL INICIO.

x) Aux = Cabeza
b) Cabeza apunta ahora a Cabeza->Siguiente
c) Cabeza->Anterior = NULL
a) Liberar el Nodo a que apunta CABEZA



GRAFICAMENTE

      CABEZA
         |
         |
       Nodo1      Nodo2
nil<--|PAnter|<--|PAnter|
      |Valor1|   |Valor2|
      |PSigte|-->|pSigte|-->nil

                    CABEZA
                      |
                      |
     Nodo1          Nodo1
    |PAnter| nil<--|PAnter|
    |ValorN|       |Valor1|
    |PSigte|       |pSigte|-->nil

DESPLIEGUE DE LA LISTA.
EN NORMAL
Hacer el recorrido normal que ya se tenía anteriormente
partiendo de CABEZA y moviendose a siguiente, hasta que
CABEZA sea Null.

EN INVERSO
Primero se recorre hasta el último elemento de la Lista;
o sea cuando su siguiente apunte a NULL; y a partir de
ahí se hace el mismo recorrido; pero utilizando el
apuntador anterior.


*/

// Librerias
#include <stdlib.h>
#include <stdio.h>

// Constantes
#define TRUE  1
#define FALSE 0

// Define la Estructura para los Nodos
struct stcNodo
{
   int iDato;
   struct stcNodo *pSiguiente;
   struct stcNodo *pAnterior;
};

// Define el tipo de acuerdo a la Estructura
typedef struct stcNodo nodo;

// Funcion para crear un Nodo
nodo *FnNodoCrea(int xDato)
{
   // Defino una variable de tipo Apuntador Nodo
   nodo *xNodo;

   // Reservo la Memoria para el Nodo
   xNodo = (nodo *)malloc(sizeof(nodo));

   
   // Verifico que haya podido reservar memoria
   if (xNodo == NULL)
      // Despliega el Mensaje de Error
      printf("Error. No se pudo reservar memoria para el Nodo");
   else
   {
      // Asigna la Informacion al Nodo
      xNodo->iDato      = xDato; // El Dato
      xNodo->pSiguiente = NULL;  // Apunta a Null
      xNodo->pAnterior  = NULL;
   }

   //Retorna el resultado
   return xNodo;
}

// Funcion para verificar si una Lista Enlazada esta vacia
int FnIntListaVacia(nodo *pCabeza)
{
   // Verifica si esta apuntando a Null
   if (pCabeza==NULL)
   {
      printf("La Lista esta vacia \n");
      return TRUE;
   }
   else
   {
      printf("La Lista no esta vacia \n");
      return FALSE;
   }
}


// Función para Insertar un Elemento al Frente de la Lista Doblemente Enlazada
void SbListaDobleInsertarFrente(nodo **pCabeza, int xDato)
{

    // Definimos un Apuntador a un Nodo

    //a) Crear el Nodo Nuevo con el Valor Correspondiente.
    nodo *pNodoNuevo;

    // Crea un Nuevo Nodo apuntando a Null
    pNodoNuevo=FnNodoCrea(xDato);

    // Verifica si está vacía ( Mandamos con pCola en lugar de pCabeza)
    if (FnIntListaVacia(*pCabeza))
    {
        // b) Siguiente y anterior apunta a NULL
        //pNodoNuevo->pSiguiente = NULL;
        //pNodoNuevo->pAnterior = NULL;

        // c) Hacer que Cabeza apunte al Nodo Nuevo.
        *pCabeza=pNodoNuevo;

        // Mensaje
        printf("Inserción Lista Doblemente Enlazada Vacía; Elemento %d en dirección %p \n\n",xDato,pNodoNuevo);
    }
    else
    {
        // b) Hacer que CABEZA->Anterior apunte al Nuevo Nodo
        (*pCabeza)->pAnterior = pNodoNuevo;

        // c) Hacer que el Nuevo Nodo->Siguiente Apunte al Nodo que apunta Cabeza
        pNodoNuevo->pSiguiente = *pCabeza;

        // d) Hacer que el Nuevo Nodo->Anterior apunte a NULL
        pNodoNuevo->pAnterior = NULL;

        // e) Hacer que CABEZA Apunte al Nvo Nodo
        *pCabeza = pNodoNuevo;

        // Mensaje
        printf("Inserción Inicio Lista Doblemente Enlazada Elemento %d en dirección %p \n\n",xDato,pNodoNuevo);
    }
}

// Función para Eliminar un Elemento del Frente de la Lista Doble
nodo FnNodoListaDobleEliminaFrente(nodo **pCabeza)
{
    // apuntador Auxiliar
    nodo* pAux;

    // Definimos un Apuntador a un Nodo
    nodo xNodo;

    // Inicializa
    xNodo.iDato=-1;
    xNodo.pSiguiente=NULL;
    xNodo.pAnterior=NULL;

    // Verifica si está vacía ( Mandamos con pCola en lugar de pCabeza)
    if (FnIntListaVacia(*pCabeza))
    {
        // Mensaje
        printf("La Lista Doblemente Enlazada está vacía, no es posible eliminar Elementos \n\n");
    }
    else
    {
        // Obtenemos la información del Nodo a Eliminar
        xNodo.iDato      = (*pCabeza)->iDato;
        xNodo.pSiguiente = (*pCabeza)->pSiguiente;
        xNodo.pAnterior  = (*pCabeza)->pAnterior;
        
        // Guardamos el Apuntador
        pAux = (*pCabeza)->pSiguiente;

        // a) Liberar el Nodo a que apunta CABEZA
        free(*pCabeza); 

        // b) Cabeza apunta ahora a Cabeza->Siguiente
        //*pCabeza = (*pCabeza)->pSiguiente; // Error
        *pCabeza = pAux;                     // CORREGIDO

        // c) Cabeza->Anterior = NULL
        if (*pCabeza!=NULL)
           (*pCabeza)->pAnterior = NULL;

        // Mensaje
        printf("Eliminación Frente Lista Doblemente Enlazada Elemento:%d Sigte:%p Anter:%p \n\n",xNodo.iDato,xNodo.pSiguiente,xNodo.pAnterior);

    }

    // Retorna el Nodo
    return xNodo;
}


// Función para desplegar los Elementos en Orden Normal e Inverso
void SbListaDobleDespliega(nodo *pCabeza,int iOrdenNormal)
{
    // Para Contar los Elementos
    char iContar=0;

    // Verificamos que esté vacía
    if (FnIntListaVacia(pCabeza))
    {
       // Mensaje de Lista Vacía
       printf("La Lista Doblemente Enlazada se encuentra vacía; no hay valores que desplegar");
    }
    else
    {
        // Desplegando los Elementos de la lista
        printf("Desplegando los Elementos de la Lista ");

        // Verifica el Orden
        if (iOrdenNormal)
        {
            // Despliega el Orden
            printf("en orden normal \n");

            // Ciclo para desplegar los Elementos de la Lista
            while (pCabeza!=NULL)
            {
               // Despliega la información del Nodo
               printf("Elemento:%d Valor:%d en dirección:%p pSigte:%p pAnter:%p \n",++iContar,pCabeza->iDato,pCabeza,pCabeza->pSiguiente,pCabeza->pAnterior);

               // Mueve cabeza al siguiente elemento
               pCabeza = pCabeza->pSiguiente;
            }
         }
         else
         {
            // Despliega el Orden
            printf("en orden inverso \n");

            // Ciclo para ir hacia el Elemento Final
            while (pCabeza->pSiguiente!=NULL)
            {
               // Mueve cabeza al siguiente elemento
               pCabeza = pCabeza->pSiguiente;

               // Incrementa el Contador de elementos
               iContar++;
            }

            // Incrementa el Contador del último elemento
            iContar++;

            // Comienza el Recorrido hacia atrás
            // Ciclo para desplegar los Elementos de la Lista
            while (pCabeza!=NULL)
            {
               // Despliega la información del Nodo
               printf("Elemento:%d Valor:%d en dirección:%p pSigte:%p pAnter:%p \n",iContar--,pCabeza->iDato,pCabeza,pCabeza->pSiguiente,pCabeza->pAnterior);

               // Mueve cabeza al siguiente elemento
               pCabeza = pCabeza->pAnterior;
            }
         }
    }
    // Deja una Línea
    printf("\n");

}


// Función Principal
int main()
{
    // Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 24 - Listas Doblemente Enlazadas \n\n");

    // Apuntadores Cabeza
    nodo *pCabeza=NULL;

    // Variable Nodo para Eliminar
    nodo xNodo;

    // Inserta un Elemento al Inicio
    SbListaDobleInsertarFrente(&pCabeza,10);

    // Despliega la Lista en Orden Normal
    SbListaDobleDespliega(pCabeza,TRUE);

    // Despliega la Lista en Orden Inverso
    SbListaDobleDespliega(pCabeza,FALSE);

    // Inserta un Elemento al Inicio
    SbListaDobleInsertarFrente(&pCabeza,19);

    // Despliega la Lista en Orden Normal
    SbListaDobleDespliega(pCabeza,TRUE);

    // Despliega la Lista en Orden Inverso
    SbListaDobleDespliega(pCabeza,FALSE);

    // Inserta un Elemento al Inicio
    SbListaDobleInsertarFrente(&pCabeza,13);

    // Inserta un Elemento al Inicio
    SbListaDobleInsertarFrente(&pCabeza,14);

    // Inserta un Elemento al Inicio
    SbListaDobleInsertarFrente(&pCabeza,27);

    // Despliega la Lista en Orden Normal
    SbListaDobleDespliega(pCabeza,TRUE);

    // Despliega la Lista en Orden Inverso
    SbListaDobleDespliega(pCabeza,FALSE);

    // Eliminamos un Elemento de la Lista
    xNodo = FnNodoListaDobleEliminaFrente(&pCabeza);

    // Desplegamos Información del Nodo Eliminado
    printf("Información del Nodo:%d Sigte:%p Anter:%p\n",xNodo.iDato,xNodo.pSiguiente,xNodo.pAnterior);

    // Despliega la Lista en Orden Normal
    SbListaDobleDespliega(pCabeza,TRUE);

    // Despliega la Lista en Orden Inverso
    SbListaDobleDespliega(pCabeza,FALSE);

    // Eliminamos un Elemento de la Lista
    xNodo = FnNodoListaDobleEliminaFrente(&pCabeza);

    // Desplegamos Información del Nodo Eliminado
    printf("Información del Nodo:%d Sigte:%p Anter:%p\n",xNodo.iDato,xNodo.pSiguiente,xNodo.pAnterior);

    // Eliminamos un Elemento de la Lista
    xNodo = FnNodoListaDobleEliminaFrente(&pCabeza);

    // Desplegamos Información del Nodo Eliminado
    printf("Información del Nodo:%d Sigte:%p Anter:%p\n",xNodo.iDato,xNodo.pSiguiente,xNodo.pAnterior);

    // Eliminamos un Elemento de la Lista
    xNodo = FnNodoListaDobleEliminaFrente(&pCabeza);

    // Desplegamos Información del Nodo Eliminado
    printf("Información del Nodo:%d Sigte:%p Anter:%p\n",xNodo.iDato,xNodo.pSiguiente,xNodo.pAnterior);

    // Eliminamos un Elemento de la Lista
    xNodo = FnNodoListaDobleEliminaFrente(&pCabeza);

    // Desplegamos Información del Nodo Eliminado
    printf("Información del Nodo:%d Sigte:%p Anter:%p\n",xNodo.iDato,xNodo.pSiguiente,xNodo.pAnterior);

    // Inserta un Elemento al Inicio
    SbListaDobleInsertarFrente(&pCabeza,99);

    // Despliega la Lista en Orden Normal
    SbListaDobleDespliega(pCabeza,TRUE);
    SbListaDobleDespliega(pCabeza,FALSE);

    // Finaliza la aplicación retornando 0
    return 0;
}



