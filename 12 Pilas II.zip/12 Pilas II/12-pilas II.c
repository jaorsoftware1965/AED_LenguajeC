/*
Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE
www.jaorsoftware.com

Clase 12 - Pilas II

Esta Clase la vamos a dedicar a mostrar algunos usos habituales
de las PILAS.

PALINDROMO.
El Primer Uso que veremos es de analizar si una palabra es un
palíndromo.

Palíndromo es una palabra o frase que se lee de igual hacia
adelante que hacia atrás. Ejemplos:

"1234321"
"Ama"
"Ata"
"Radar"
"Amor a Roma"

El uso de la Pila, para este efecto es muy sencillo. Simplemente
se van agregando cada uno de los caracteres a la Pila; y cuando
se ha finalizado; entonces se sacan uno por uno, y se van agregando
a una nueva cadena. Si esta cadena resultante, es igual que la
original, entonces será un Palíndromo.

Cadena Original: Amor a roma
1) Se meten todos los caracteres en la Pila
Pila->A,m,o,r, ,a, ,r,o,m,a

2) Se sacan todos los elementos de la Pila y se colocan en una
nueva cadena:
Nueva Cadena:amor a romA.

CADENA INVERSA.
El otro uso es obvio en base a lo anterior; y que es poder obtener el
reverso de una cadena; en lugar de comparar; simplemente se
retorna la cadena.

EVALUAR UNA EXPRESIÓN
a) Aritmética con Suma,Resta,Multiplicación, División?
b) SIN PARENTESIS
c) NI PRECEDENCIA
d) Operandos de un dígito

5+6*7/8

Operadores->
Operandos ->

*/

// Librerias
#include <stdio.h>
#include <stdlib.h>
#include "string.h"

// Definimos True y False
#define TRUE  1
#define FALSE 0

// Definimos el Tamaño de la Pila
#define PILA_TAMANIO   50
#define ESPACIO_BLANCO 32

// Definimos la estructura de la Pila
typedef struct stcPila
{
    // Variable para manejar el tope actual de la Pila
    int  iPilaTope;

    // El Arreglo para la Pila
    int arrIntPila[PILA_TAMANIO];

}pila;

// Implementamos Inicializar la Pila
void SbPilaInicializa(pila *pPila);

// Implementamos Verificar si la Pila está vacía
int FnIntPilaVacia(pila *pPila);

// Implementamos Verificar si la Pila está llena
int FnIntPilaLlena(pila *pPila);

// Implementamos Obtener cuantos elementos tiene la Pila
int FnIntPilaElementos(pila *pPila);

// Implementamos desplegar el Elemento de la CIma
void SbPilaCima(pila *pPila);

// Implementamos obtener el Elemento de la CIma sin sacarlo
int  FnIntPilaCima(pila *pPila);

// Implementamos Insertar un Elemento en la Pila
void SbPilaPush(pila *pPila,int iElemento);

// Implementamos Sacar un Elemento de la Pila
int FnIntPilaPop(pila *pPila);

//----------------------------------------------------
// Función para verificar si una cadena es palíndromo
// utilizando pilas
int FnIntPalindromo(char *sCadena);

// Función para obtener el Inverso de una Cadena
// utilizando pilas
char *FnStrInverso(char *sCadena);

// Función que evalúa una expresión
int FnIntExpresionEvalua(char *sExpresion);


// Función Principal
int main()
{
    // Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 12 - Pilas II\n\n");

    // Variable para manejar Cadenas
    char sCadena[30];

    // Deposita palíndromo
    strcpy(sCadena,"sevansusnaveS");

    // Verifica si la Cadena es palíndromo
    if (FnIntPalindromo(sCadena)==TRUE)
       printf("La Cadena %s SI es un Palíndromo \n",sCadena);
    else
       printf("La Cadena %s NO es un Palíndromo \n",sCadena);

    // Obtiene la Cadena Inversa
    printf("La Cadena inversa de JAORSOFTWARE es:\n%s",FnStrInverso("JAORSOFTWARE"));

    // Procesa una Expresión aritmética
    //FnIntExpresionEvalua("5+A-4*5/3");
    FnIntExpresionEvalua("5-4*5/3");
    //FnIntExpresionEvalua("+");
    
    // Procesa una Expresión aritmética
    //FnIntExpresionEvalua("+5-4*5/3");

    // Procesa una Expresión aritmética
    //FnIntExpresionEvalua("5+/5-4*5/3");

    // Procesa una Expresión aritmética
    //FnIntExpresionEvalua("5+57-4*5/3");

    // Procesa una Expresión aritmética
    //FnIntExpresionEvalua("5+5-4*5/");

    // Procesa una Expresión aritmética
    //FnIntExpresionEvalua("5/*");
}

// Implementamos Inicializar la Pila
void SbPilaInicializa(pila *pPila)
{
   // Para Inicializa la Pila basta con poner el tope a -1
   // Ya que el primer elemento ocupa la posición 0
   pPila->iPilaTope=-1;

   // Desplegamos Mensaje
   printf("Pila Inicializada ...\n");
}

// Implementamos Verificar si la Pila está vacía
int FnIntPilaVacia(pila *pPila)
{
    if (pPila->iPilaTope==-1)
       return TRUE;
    else
       return FALSE;
}

// Implementamos Verificar si la Pila está llena
int FnIntPilaLlena(pila *pPila)
{
    if (pPila->iPilaTope==PILA_TAMANIO-1)
       return TRUE;
    else
       return FALSE;
}

// Implementamos Obtener cuantos elementos tiene la Pila
int FnIntPilaElementos(pila *pPila)
{
    // Retorna el Tope de la Pila
    return pPila->iPilaTope+1;
}

// Implementamos para Desplegar el Elemento en la Cima
void SbPilaCima(pila *pPila)
{
    // Verificamos si la Pila está vacía
    if (FnIntPilaVacia(pPila))
       printf("La Pila está vacía; no hay elemento Cima\n");
    else
       printf("Pila Cima: %d",pPila->arrIntPila[pPila->iPilaTope]);
}

// Implementamos para Obtener el Elemento en la Cima
int FnIntPilaCima(pila *pPila)
{
    // Verificamos si la Pila está vacía
    if (FnIntPilaVacia(pPila))
       return (-1);
    else
       return(pPila->arrIntPila[pPila->iPilaTope]);
}

// Implementamos Insertar un Elemento en la Pila
void SbPilaPush(pila *pPila,int iElemento)
{
    // Verificamos si la Pila está llena
    if (FnIntPilaLlena(pPila))
       printf("La Pila está llena y no es posible agregar el elemento:%d\n",iElemento);
    else
    {
       // Incrementamos el tope de la pila
       pPila->iPilaTope++;

       // Agrega el Elemento a la Pila
       pPila->arrIntPila[pPila->iPilaTope]=iElemento;

       // Colocamos el dato en la Pila
       //printf("Se ha agregado el elemento %d a la Pila \n",iElemento);
    }
}

// Implementamos Sacar un Elemento de la Pila
int FnIntPilaPop(pila *pPila)
{
    // Verificamos si la Pila está vacía
    if (FnIntPilaVacia(pPila))
    {
       printf("La Pila está vacía no es posible sacar elementos\n");
       return pPila->iPilaTope;
    }
    else
    {

       // Colocamos el dato en la Pila
       //printf("Se ha sacado un elemento de la Pila %d \n",pPila->arrIntPila[pPila->iPilaTope]);
       // Agrega el Elemento a la Pila
       return(pPila->arrIntPila[pPila->iPilaTope--]);
    }

}

//----------------------------
// Función para verificar si una cadena es palíndromo
// utilizando pilas
int FnIntPalindromo(char *sCadena)
{
    // Declaramos la Variable de la Pila
    pila xPila;

    // Declaramos el vector para la cadena resultante
    char sReverso[30];

    // Variable para el índice del vector
    char cIndice;

    // Inicializa la Pila
     
    SbPilaInicializa(&xPila);
    // Ciclo para leer los caracteres y colocarlos en la pila
    for (cIndice=0; cIndice < strlen(sCadena); cIndice++)
        // Coloca cada caracter en la pila
        SbPilaPush(&xPila,sCadena[cIndice]);

    // Una vez terminado de colocar los elementos en la pila
    // ahora los saca en el nuevo vector

    // Inicializa el indice a 0
    cIndice=0;

    // Ciclo mientras la Pila no esté vacía
    while (!FnIntPilaVacia(&xPila))
        // Coloca en el nuevo vector
        sReverso[cIndice++]=FnIntPilaPop(&xPila);

    // Agrega el caracter de Nulo al final
    sReverso[cIndice]='\0';

    // Ahora compara para verificar si es lo mismo
    if (strcmp(sCadena,sReverso)==0)
        return TRUE;
    else
        return FALSE;
}

// Función para obtener el Inverso de una Cadena
// utilizando pilas
char *FnStrInverso(char *sCadena)
{
    // Declaramos la Variable de la Pila
    pila xPila;

    // Declaramos el vector para la cadena resultante
    static char sInverso[30];

    // Variable para el índice del vector
    char cIndice;

    // Inicializa la Pila
    SbPilaInicializa(&xPila);

    // Ciclo para leer los caracteres y colocarlos en la pila
    for (cIndice=0; cIndice < strlen(sCadena); cIndice++)
        // Coloca cada caracter en la pila
        SbPilaPush(&xPila,sCadena[cIndice]);

    // Una vez terminado de colocar los elementos en la pila
    // ahora los saca en el nuevo vector
    // Inicializa el indice a 0
    cIndice=0;

    // Ciclo mientras la Pila no esté vacía
    while (!FnIntPilaVacia(&xPila))
        // Coloca en el nuevo vector
        sInverso[cIndice++]=FnIntPilaPop(&xPila);

    // Agrega el caracter de Nulo al final
    sInverso[cIndice]='\0';

    // Devuelve la Cadena Resultante
    return (sInverso);
}

// Función que evalúa una expresión
int FnIntExpresionEvalua(char *sExpresion)
{
    // Define una pila para parentesis y una para operandos y operadores
    pila xPilaOperandos;
    pila xPilaOperadores;

    // Inicializa Ambas Pilas
    SbPilaInicializa(&xPilaOperandos);
    SbPilaInicializa(&xPilaOperadores);

    // Para el Indice de los caracteres de la Expresión
    int iIndice;

    // para el Resultado
    int iResult=0;

    // para el Operador
    char cOperador;

    // para el Operando
    int cOperando;

    // Mensaje de Procesamiento
    printf("Analizando Expresión ... \n");

    // Cuando encuentro un operador
    // a) No debe haber otro en lapila de operadores
    // b) Debe haber un operando en la pila de operandos

    // 5+6
    // Ciclo para analizar la expresión
    for (iIndice=0; iIndice<strlen(sExpresion); iIndice++)
    {
        // Descarta el Espacio en Blanco
        if (sExpresion[iIndice]!=ESPACIO_BLANCO)
        {
            // Verifica que caracter es
            switch (sExpresion[iIndice])
            {                
                case  43:// Suma
                case  45:// Resta
                case  42:// Multiplicación
                case  47:// División
                         // Siempre solo hay un operador en la Pila
                         // Verifica si la Pila de Operadores está vacía
                         if (FnIntPilaVacia(&xPilaOperadores))
                            if (FnIntPilaElementos(&xPilaOperandos)>0)
                            {
                               printf("%c es un Operador; se agrega a la Pila de Operadores \n",sExpresion[iIndice]);
                               SbPilaPush(&xPilaOperadores,sExpresion[iIndice]);
                            }
                            else
                            {
                               printf("Error. Operador sin Operando Previo :%c",sExpresion[iIndice]);
                               iResult=-1;
                            }
                         else
                         {
                            printf("Error. Exceso de Operadores :%c",sExpresion[iIndice]);
                            iResult=-1;
                         }
                         break;

                case  48:// 0
                case  49:// 1
                case  50:// 2
                case  51:// 3
                case  52:// 4
                case  53:// 5
                case  54:// 6
                case  55:// 7
                case  56:// 8
                case  57:// 9
                         // Verifica si la Pila de Operadores está vacía
                         if (FnIntPilaVacia(&xPilaOperadores))
                            if (FnIntPilaVacia(&xPilaOperandos))
                                // Agrega el Elemento a la Pila de Operandos
                                SbPilaPush(&xPilaOperandos,sExpresion[iIndice]-48);
                            else
                            {
                                printf("Error. Exceso de Operandos :%c",sExpresion[iIndice]);
                                iResult=-1;
                            }
                         else
                         {
                            //if (!FnIntPilaVacia(&xPilaOperandos))
                            //{
                                // Obtiene el Operador
                                cOperador=FnIntPilaPop(&xPilaOperadores);

                                // Obtiene el Operando
                                cOperando=FnIntPilaPop(&xPilaOperandos);

                                // Realiza la operación con los 2 operandos de acuerdo al Operador
                                if (cOperador=='+')
                                   iResult= cOperando + (sExpresion[iIndice]-48);
                                else
                                   if (cOperador=='-')
                                      iResult= cOperando - (sExpresion[iIndice]-48);
                                   else
                                      if (cOperador=='*')
                                         iResult= cOperando * (sExpresion[iIndice]-48);
                                      else
                                         //if (cOperador=='/')
                                         iResult= cOperando / (sExpresion[iIndice]-48);
                                // Despliega la Operación
                                printf("Se realizó operación: %d %c %d = %d\n",cOperando, cOperador,sExpresion[iIndice]-48,iResult);

                                // Inserta el Operando en la pila
                                SbPilaPush(&xPilaOperandos,iResult);
                                iResult=0;
                         }
                            //else
                            //{
                            //    printf("Error. No se encontró operando para realizar operación\n");
                            //    iResult=-1;
                            //}
                         break;
                default: printf("Error. Caracter no reconocido:%c",sExpresion[iIndice]);
                         iResult=-1;
                         break;

            }// Cierre del switch
        } // Cierre del IF del Espacio en Blanco

        // Verifica que hubo error
        if (iResult==-1)
           break;

    }// Ciclo For
    if (iResult!=-1)
       //if (FnIntPilaElementos(&xPilaOperandos)==1 && FnIntPilaVacia(&xPilaOperadores))
       if (FnIntPilaVacia(&xPilaOperadores))
       {
           iResult = FnIntPilaPop(&xPilaOperandos);
           printf("El resultado de la Expresión %s es:%d \n",sExpresion,iResult);
       }

       else
          printf("Error. Exceso de Operadores:%c \n",FnIntPilaPop(&xPilaOperadores));

    // Retorna el Resultado
    return (iResult);

}
