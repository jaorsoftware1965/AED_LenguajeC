/*
Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE
www.jaorsoftware.cu.cc

Clase 34 - Árbol Binario de Expresión

Uno de los principales usos de un árbol binario, es la
evaluación de expresiones aritméticas.

Una expresión aritmética puede expresarse a través de
un árbol binario. Veamos el siguiente ejemplo:

(5 + 4)  *  (6 - (2 + 1))

La anterior expresión, quedaría implementada en un  árbol
binario de la siguiente forma:

                *
         +              -
     5       4      6      +
                         2   1

La anterior expresión se evalúa de la siguiente forma:
1.- 5+4 = 9
2.- 2+1 = 3
3.- 6-3 = 3
4.- 9*3 = 27

Si podemos observar, en la raíz del árbol, queda reflejado
el operador de la última operación que se realiza.

Lo que vamos a ver en esta clase, es como podemos crear
el árbol de expresión, a partir de su diseño.

Existen procesos, como el que ya vimos en una clase inicial,
en donde se evalúa una expresión y se resuelve utilizando
pilas.

En esta clase simplemente vamos a ver como construir el
árbol, y en la siguiente; como evaluar la expresión una vez
que tenemos el árbol construido.

Nuestro algoritmo funcionara básicamente con 2 puntos:

1.- Insertar el nodo raíz
2.- Insertar un nodo a la izquierda o derecha de un nodo
    Padre.

Como Creariamos el árbol partiedo de los 2 anteriores puntos:

                 *
         +              -
     5       4      6      +
                         2   1


1.- Insertar * como nodo raíz
2.- Insertar + como hijo izquierdo de *
3.- Insertar 5 como hijo izquierdo de +
4.- Insertar 4 como hijo derecho de +
5.- Insertar - como hijo derecho de *
6.- Insertar 6 como hijo izquierdo de -
7.- Insertar + como hijo derecho de -
8.- Insertar 2 como hijo izquierdo de +
9.- Insertar 1 como hijo derecho de +

La función deberá ir buscando el Nodo Padre al cual se
le asignará el hijo; hasta encontrar que esté vacío el
hijo que indica; ya que; como sucede en el ejemplo; cuando
insertamos el 2 y el 1 finales; como hijos del +; puede
encontrarse con el + previo.

*/

#include <stdlib.h>
#include <stdio.h>
#include "stdbool.h"

#define TRUE  1
#define FALSE 0

// Define el Cambio de Línea
#define CR printf("\n")

// Defino la Estructura de los Nodos del Árbol
typedef struct NODO_ARBOL
{
   char   cDato;  // Dato del Nodo
   struct NODO_ARBOL *pIzquierdo;  // Apuntador a Hijo Izquierdo
   struct NODO_ARBOL *pDerecho;    // Apuntador a Hijo Derecho
}nodo_arbol;

// Función para crear un Nodo para el Árbol
nodo_arbol *FnArbolCreaNodo(char xDato)
{
   // Defino una variable de tipo Apuntador Nodo
   nodo_arbol *xNodo;

   // Reservo la Memoria para el Nodo
   xNodo = (nodo_arbol *)malloc(sizeof(nodo_arbol));

   // Verifico que haya podido reservar memoria
   if (xNodo == NULL)
      // Despliega el Mensaje de Error
      printf("Error. No se pudo reservar memoria para el Nodo_Arbol");
   else
   {
      // Asigna la Información al Nodo
      xNodo->cDato      = xDato; // El Dato
      xNodo->pDerecho   = NULL;  // Apunta a Null
      xNodo->pIzquierdo = NULL;  // Apunta a Null
   }

   //Retorna el resultado
   return xNodo;
}


// Función para Insertar un Nodo en el Árbol
int FnBoolArbolInsertaNodo(nodo_arbol** pRaiz, 
                           char         xDatoInserta,
                           char         xDatoPadre,
                           char         cLado)
{
    // Definiendo un Apuntador Auxiliar
    nodo_arbol *pAuxiliar;

    // Verificamos si está vacío el Árbol
    if (*pRaiz==NULL)
    {

        // Definimos un Apuntador a un Nodo Nuevo
        nodo_arbol *pNodoNuevo;

        // Creamos el Nodo Nuevo
        pNodoNuevo=FnArbolCreaNodo(xDatoInserta);

        // Lo Asignamos como raíz
        *pRaiz=pNodoNuevo;

        // Mensaje
        printf("Se Inserto el Dato:%c como Raiz del Arbol\n",xDatoInserta);

        // Finaliza
        return TRUE;
    }
    // Si no está vacío entramos a un ciclo
    else
    {
       // Colocamos el Auxiliar apuntando a Raíz
       pAuxiliar = *pRaiz;

      // Comparamos si es el dato Padre
      if (pAuxiliar->cDato == xDatoPadre)

         // Verificamos si lo desea insertar a la Derecha
         if (cLado=='D')
         {
             // Verificamos si No tiene Hijo Derecho
             if (pAuxiliar->pDerecho==NULL)
             {
                 // Definimos un Apuntador a un Nodo Nuevo
                 nodo_arbol *pNodoNuevo;

                 // Creamos el Nodo Nuevo
                 pNodoNuevo=FnArbolCreaNodo(xDatoInserta);

                 // No tiene Hijo Derecho; Insertamos
                 pAuxiliar->pDerecho=pNodoNuevo;

                 printf("Inserto  %c del Lado Derecho de %c \n",xDatoInserta,xDatoPadre);

                 // Salimos de la Función
                 return TRUE;
             }
         }
         else
         {
             // Verificamos si tiene Hijo Izquierdo
             if (pAuxiliar->pIzquierdo==NULL)
             {
                 // Definimos un Apuntador a un Nodo Nuevo
                 nodo_arbol *pNodoNuevo;

                 // Creamos el Nodo Nuevo
                 pNodoNuevo=FnArbolCreaNodo(xDatoInserta);

                 // No tiene Hijo Izquierdo; Insertamos
                 pAuxiliar->pIzquierdo=pNodoNuevo;

                 printf("Inserto %c del Lado Izquierdo de %c \n",xDatoInserta,xDatoPadre);
                 // Salimos del Ciclo
                 return TRUE;
             }
          }

      // Busca por ambos lados
      if (pAuxiliar->pIzquierdo!=NULL)
         if (! FnBoolArbolInsertaNodo(&(pAuxiliar->pIzquierdo),xDatoInserta,xDatoPadre,cLado))
            if (pAuxiliar->pDerecho!=NULL)
               if (!FnBoolArbolInsertaNodo(&(pAuxiliar->pDerecho),xDatoInserta,xDatoPadre,cLado))
                  return FALSE;
               else
                  return TRUE;
            else
               return FALSE;
          else
             return TRUE;
       else
          return FALSE;
    }
}

// Recorre el Árbol
void SbArbolRecorreChar(nodo_arbol *pNodo)
{
   // Variable control de Impresion
     // Verifica que no sea Null
     if (pNodo==NULL)
        // Finaliza la Función
        return;
     else
     {
        // Imprime el Contenido del Nodo
        printf("%c \n",pNodo->cDato);
        // Llama a misma Función con el Hijo Izquierdo
        SbArbolRecorreChar(pNodo->pIzquierdo);
        // Llama a misma Función con el Hijo Derecho
        SbArbolRecorreChar(pNodo->pDerecho);
     }
}

// Recorre el Árbol
void SbArbolRecorreCharCond(nodo_arbol *pNodo,char cond)
{
   // Variable control de Impresion
   static bool puedoImprimir=false;

     // Verifica que no sea Null
     if (pNodo==NULL)
        // Finaliza la Función
        return;
     else
     {
        // Preguntamos si es el condicionado
        if (pNodo->cDato==cond)
           puedoImprimir = true;

        // Imprime el Contenido del Nodo
        if (puedoImprimir)
           printf("%c \n",pNodo->cDato);

        // Llama a misma Función con el Hijo Izquierdo
        SbArbolRecorreCharCond(pNodo->pIzquierdo,cond);
        
        // Llama a misma Función con el Hijo Derecho
        SbArbolRecorreCharCond(pNodo->pDerecho,cond);

        // Acá es donde cambio a false
        printf("Cambio a False ...\n");
        puedoImprimir = false;
     }
}



// Función Principal
int main()
{
    // Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 35 - Arboles Binarios Expresion \n\n");

    // Declaro el Apuntador a la Raíz.
    //nodo_arbol *pRaiz=NULL;

    // Expresión a Insertar: (5 + 4)  *  (6 - (2 + 1))
    //                *
    //         +              -
    //     5       4      6      +
    //                         2   1

    printf("Creando el Arbol Binario \n");

    // Insertamos la Secuencia
   //  FnBoolArbolInsertaNodo(&pRaiz,'*',' ',' ');
   //  FnBoolArbolInsertaNodo(&pRaiz,'+','*','I');
   //  FnBoolArbolInsertaNodo(&pRaiz,'5','+','I');
   //  FnBoolArbolInsertaNodo(&pRaiz,'4','+','D');
   //  FnBoolArbolInsertaNodo(&pRaiz,'-','*','D');
   //  FnBoolArbolInsertaNodo(&pRaiz,'6','-','I');
   //  FnBoolArbolInsertaNodo(&pRaiz,'+','-','D');
   //  FnBoolArbolInsertaNodo(&pRaiz,'2','+','I');
   //  FnBoolArbolInsertaNodo(&pRaiz,'1','+','D');

   //  SbArbolRecorreChar(pRaiz);
   //  // Finaliza la aplicación retornando 0
   //  return 0;

    // Expresion Aritmetica
    //(9-7)/8 + 5*(8-3)
    // 9-7 
    //     /8
    //   8-3
    // 5*
    // +

    //               +
    //        /             * 
    //   -        8      5     -
    // 9   7                 8   3

    // Creamos otro arbol
    nodo_arbol *pRaiz2=NULL;

    FnBoolArbolInsertaNodo(&pRaiz2,'+',' ',' ');
    FnBoolArbolInsertaNodo(&pRaiz2,'/','+','I');
    FnBoolArbolInsertaNodo(&pRaiz2,'-','/','I');
    SbArbolRecorreChar(pRaiz2);
    FnBoolArbolInsertaNodo(&pRaiz2,'8','/','D');
    FnBoolArbolInsertaNodo(&pRaiz2,'9','-','I');
    FnBoolArbolInsertaNodo(&pRaiz2,'7','-','D');
    FnBoolArbolInsertaNodo(&pRaiz2,'*','+','D');
    SbArbolRecorreChar(pRaiz2);
    FnBoolArbolInsertaNodo(&pRaiz2,'5','*','I');
    FnBoolArbolInsertaNodo(&pRaiz2,'-','*','D');
    FnBoolArbolInsertaNodo(&pRaiz2,'8','-','I');
    FnBoolArbolInsertaNodo(&pRaiz2,'3','-','D');
    SbArbolRecorreChar(pRaiz2);
    printf("\n\n");

    printf("1\n\n");
    SbArbolRecorreCharCond(pRaiz2,'/');
    printf("2\n\n");
    SbArbolRecorreCharCond(pRaiz2,'*');
    printf("3\n\n");
    SbArbolRecorreCharCond(pRaiz2,'+');
    

    
    return 0;



    




}

