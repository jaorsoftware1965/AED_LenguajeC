/*

Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE
www.jaorsoftware.com

Clase 09 - Uniones

Una unión es un area de memoria la cual se encuentra compartida por 
varias variables que pueden ser de tipos diferentes.

La definición de unión es:

union nombre_union
{
    tipo nombre1;
    tipo nombre2;
    ...
    tipo nombreN;
}var_union;

Como puede observarse su declaración, es parecida a la declaración de una
estructura. Sin embargo, en una unión, todas las variables comparten la misma
área de memoria. Así, si declaramos:

union comparte
{
    char        xChar;   //  1 Byte  1
    short int   xsInt;   // +1 Bytes O sea 2 Bytes
    float       xFloat;  // +2 Bytes O sea 4 bytes
    double      xDouble; // +4 Bytes O sea 8 bytes
}xVar;

La cantidad de memoria reservada por la unión en el caso anterior se encuentra
indicada por la variable que ocupe la mayor cantidad de bytes;
para el caso anterior es 8 bytes. "Gráficamente" en bits, esto se explicaría así

VARIABLE    MEMORIA QUE OCUPA
xChar       00000000
xsInt       00000000 00000000
xFloat      00000000 00000000 00000000 00000000
xDouble     00000000 00000000 00000000 00000000 00000000 00000000 00000000 00000000

Ahora ya en forma compartida

            --------------------------------xDouble--------------------------------
            --------------xFloat---------------
            ------xsInt------
            -xChar--
Memoria     00000000 00000000 00000000 00000000 00000000 00000000 00000000 00000000

Si colocamos un dato en cualquiera de ellos; esto se verá reflejado en los demás.
Pero esto ¿no provocará problemas?. Si siempre se va a ocupar únicamente 1 de
los datos involucrados; NO. Esa es la razón de usar una UNION; cuando es posible
usar varios datos, pero solo uno al mismo tiempo. Esto permite ahorrar memoria.
En muchos programas es posible tener varias variables, pero no necesitan utilizarse
todas al mismo tiempo.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Definimos una Unión para el Manejo del Color
union COLOR
{
    // Variable para el manejo del Color Global
    int   rgb; // 4 Bytes
    struct
    {
       unsigned char  red;  //ff0000
       unsigned char  green;//00ff00
       unsigned char  blue; //0000ff       
    }; 
};

// Definimos una estructura para manejar un Número en Diversos Sistemas
union numero
{
    char binario[9];     // 11111111
    char octal[4];       // 377
    char decimal[4];     // 255
    char hexadecimal[3]; // FF
}xNumero;

// Definimos una estructura para manejar la Fecha
union fecha
{
    char      en_semanas;    // 1-52
    short int en_dias;       // 1-365
    char      en_cadena[12]; // dd-mmm-yyyy
    struct
    {
       char dia;  // 1-31
       char mes;  // 1-12
       short int anio; // 2015...
    }en_partes;
}xFecha;

// Función Principal
int main()
{
    // Desplegamos Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 09 - Uniones\n\n");
    
    union COLOR xColor;
    printf("Tamaño de la Union del Color:%d \n",sizeof(xColor));

    // Definimos los Colores
    xColor.rgb=0xff5733; // Establecemos el Color Blanco

    // Imprimimos el Color y su proporción en RGB
    printf(" El Color establecido a Blanco \n");
    printf(" El Valor del Color RGB    :%d\t %X \n",xColor.rgb,xColor.rgb);
    printf(" El Valor del Color Red    :%d\t\t %X \n",xColor.red,xColor.red);
    printf(" El Valor del Color Green  :%d\t\t %X \n",xColor.green,xColor.green);
    printf(" El Valor del Color Blue   :%d\t\t %X \n\n",xColor.blue,xColor.blue);

    // Colocamos el Color Azul en 0
    xColor.blue=0;
    
    printf(" Ponemos el Color Azul a 0 \n");
    printf(" El Valor del Color RGB    :%d\t %X \n",xColor.rgb,xColor.rgb);
    printf(" El Valor del Color Red    :%d\t\t %X \n",xColor.red,xColor.red);
    printf(" El Valor del Color Green  :%d\t\t %X \n",xColor.green,xColor.green);
    printf(" El Valor del Color Blue   :%d\t\t %X \n\n",xColor.blue,xColor.blue);

    // Colocamos el Color Verde en 0
    xColor.green=0;
    printf(" Ponemos el Color Verde a 0 \n");
    printf(" El Valor del Color RGB    :%d\t %X \n",xColor.rgb,xColor.rgb);
    printf(" El Valor del Color Red    :%d\t\t %X \n",xColor.red,xColor.red);
    printf(" El Valor del Color Green  :%d\t\t %X \n",xColor.green,xColor.green);
    printf(" El Valor del Color Blue   :%d\t\t %X \n\n",xColor.blue,xColor.blue);

    // Colocamos el Color Rojo en 0
    xColor.red=0;
    printf(" Ponemos el Color Rojo a 0 lo que es igual al Color NEGRO: 000000 \n");
    printf(" El Valor del Color RGB    :%d\t\t %X \n",xColor.rgb,xColor.rgb);
    printf(" El Valor del Color Red    :%d\t\t %X \n",xColor.red,xColor.red);
    printf(" El Valor del Color Green  :%d\t\t %X \n",xColor.green,xColor.green);
    printf(" El Valor del Color Blue   :%d\t\t %X \n\n",xColor.blue,xColor.blue);

    // Establecemos color Silver
    xColor.red  =128;
    xColor.green=0;
    xColor.blue =128;
    

    // Imprimimos lo valores
    printf(" Ponemos el Color en Tonalidad Gris \n");
    printf(" El Valor del Color RGB    :%d\t %X \n",xColor.rgb,xColor.rgb);
    printf(" El Valor del Color Red    :%d\t\t %X \n",xColor.red,xColor.red);
    printf(" El Valor del Color Green  :%d\t\t %X \n",xColor.green,xColor.green);
    printf(" El Valor del Color Blue   :%d\t\t %X \n\n",xColor.blue,xColor.blue);

    printf("Longitud en Bytes de las Variables \n");
    printf("bytes usados en char        %d\n",sizeof(char));
    printf("bytes usados en short int   %d\n",sizeof(short int));
    printf("bytes usados en int         %d\n",sizeof(int));
    printf("bytes usados en float       %d\n",sizeof(float));
    printf("bytes usados en double      %d\n",sizeof(double));
    printf("bytes usados en xNumero     %d\n",sizeof(xNumero));
    printf("bytes usados en xFecha      %d\n\n",sizeof(xFecha));

    // Inicializamos el Número en Binario
    strcpy(xNumero.binario,"11111111");

    // Desplegando el Número
    printf("Numero en binario     :%s \n",xNumero.binario);
    printf("Numero en octal       :%s \n",xNumero.octal);
    printf("Numero en decimal     :%s \n",xNumero.decimal);
    printf("Numero en hexadecimal :%s \n",xNumero.hexadecimal);

    // Modificamos a decimal
    strcpy(xNumero.octal,"377");

    printf("Numero en binario     :%s \n",xNumero.binario);
    printf("Numero en octal       :%s \n",xNumero.octal);
    printf("Numero en decimal     :%s \n",xNumero.decimal);
    printf("Numero en hexadecimal :%s \n\n",xNumero.hexadecimal);

    // Utilizamos la Fecha en días
    xFecha.en_dias=1;
    printf("xFecha en Días       :%d \n",xFecha.en_dias);
    printf("xFecha en Semanas    :%d \n",xFecha.en_semanas);
    printf("xFecha en Cadena     :%s \n",xFecha.en_cadena);
    printf("xFecha en Partes     :%d-%d-%d \n\n",xFecha.en_partes.dia,xFecha.en_partes.mes,xFecha.en_partes.anio);

    //                 300
    // 0000 0001 0010 1100  = 4+8+32+256 = 300
    //           0010 1100  = 4+8+32     = 44

    // Utilizamos la Union como cadena
    strcpy(xFecha.en_cadena,"10-Ene-2015");
    printf("xFecha en Días       :%d \n",xFecha.en_dias);
    printf("xFecha en Semanas    :%d \n",xFecha.en_semanas);
    printf("xFecha en Cadena     :%s \n",xFecha.en_cadena);
    printf("xFecha en Partes     :%d-%d-%d \n\n",xFecha.en_partes.dia,xFecha.en_partes.mes,xFecha.en_partes.anio);

    // Utilizamos la Union como cadena
    xFecha.en_partes.anio=2015;
    xFecha.en_partes.mes=12;
    xFecha.en_partes.dia=10;
    printf("xFecha en Días       :%d \n",xFecha.en_dias);
    printf("xFecha en Semanas    :%d \n",xFecha.en_semanas);
    printf("xFecha en Cadena     :%s \n",xFecha.en_cadena);
    printf("xFecha en Partes     :%d-%d-%d \n\n",xFecha.en_partes.dia,xFecha.en_partes.mes,xFecha.en_partes.anio);

    // Finaliza con 0 la aplicación
    return 0;
}
