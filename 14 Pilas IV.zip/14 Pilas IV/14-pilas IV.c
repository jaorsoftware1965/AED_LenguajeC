/*
Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE
www.jaorsoftware.com

Clase 14 - Pilas IV

(5+8-7*6)+5+(8/4)

Operadores:
Operandos :-22

(5+6+(4+5/7)*2)
Operadores:
Operandos :19


(5+((4+5)*6)*7)
Operadores:
Operandos :383


*/

// Librerias
#include <stdio.h>
#include <stdlib.h>
#include "string.h"
#include "math.h"

// Definimos True y False
#define TRUE  1
#define FALSE 0

// Definimos el Tamaño de la Pila
#define PILA_TAMANIO   50

// Espacion Blanco
#define ESPACIO_BLANCO 32

// Definimos la estructura de la Pila
typedef struct stcPila
{
    // Variable para manejar el tope actual de la Pila
    int  iPilaTope;

    // El Arreglo para la Pila
    int arrIntPila[PILA_TAMANIO];

}pila;

// Implementamos Inicializar la Pila
void SbPilaInicializa(pila *pPila);

// Implementamos Verificar si la Pila está vacía
int FnIntPilaVacia(pila *pPila);

// Implementamos Verificar si la Pila está llena
int FnIntPilaLlena(pila *pPila);

// Implementamos Obtener cuantos elementos tiene la Pila
int FnIntPilaElementos(pila *pPila);

// Implementamos desplegar el Elemento de la CIma
void SbPilaCima(pila *pPila);

// Implementamos obtener el Elemento de la CIma sin sacarlo
int  FnIntPilaCima(pila *pPila);

// Implementamos Insertar un Elemento en la Pila
void SbPilaPush(pila *pPila,int iElemento);

// Implementamos Sacar un Elemento de la Pila
int FnIntPilaPop(pila *pPila);

// Función que valida si es un dígito
int FnIntDigitoEs(char cCaracter)
{   
   // Valida en cuanto al ASCII de los Numeros
   if (cCaracter>47 && cCaracter < 58)
      return TRUE;
   else
      return FALSE;
}

// Función que valida si es un operador
int FnIntOperadorEs(char cCaracter)
{
   // Variable para el Resultado
   int iResult = FALSE;

   switch(cCaracter)
   {

      case  43:// Suma
      case  45:// Resta
      case  42:// Multiplicación
      case  47:// División
      case 'e':// Exponente
               iResult = TRUE;
               break;
   }

   // Retorna el Resultado
   return (iResult);
}

// Función para determinar Prioridad
int FnIntMayorPrioridad(char cOperador1,char cOperador2)
{
    // Variable para el Resultado
    int iResult;

    switch (cOperador1)
    {

       // Suma o Resta
       case  43:// En Procesaimiento de izquierda a derecha tiene mayor prioridad sobre si mismo
       case  45:if (cOperador2=='+' || cOperador2=='-')
                    iResult=TRUE;
                else
                    iResult=FALSE;
                break;

       case  42:// Tiene mayor prioridad sobre todos excepto "e"
       case  47:if (cOperador2=='e')
                    iResult=FALSE;
                else
                    iResult=TRUE;
                break;

       // Exponente
       case 'e':// Tiene mayor prioridad sobre todos incluyendo que si mismo en procesamiento por izquierda
                iResult=TRUE;
                break;
    }
    // Devuelve el resultado
    return iResult;
}



// Función que evalúa una expresión
int FnIntExpresionEvaluaCompleta(char *sExpresion)
{

    // Define una pila para parentesis y una para operandos y operadores
    pila xPilaOperandos;
    pila xPilaOperadores;

    // Inicializa Ambas Pilas
    SbPilaInicializa(&xPilaOperandos);
    SbPilaInicializa(&xPilaOperadores);

    // Para el Indice de los caracteres de la Expresión
    int iIndice;

    // para el Resultado
    int iResult=0;

    // para el Operador
    char cOperador;

    // para los Operandos
    int cOperando,cOperando2;

    // Mensaje de Procesamiento
    printf("Analizando Expresión:%s \n",sExpresion);
    printf("... \n");

    // Ciclo para analizar la expresión
    for (iIndice=0; iIndice<strlen(sExpresion); iIndice++)
    {

        // Descarta el Espacio en Blanco
        if (sExpresion[iIndice]!=ESPACIO_BLANCO)
        {
            // Verifica que caracter es
            switch (sExpresion[iIndice])
            {
                case  40:// Parentesis apertura. Error posible en:8(
                         if (FnIntPilaVacia(&xPilaOperadores) && !FnIntPilaVacia(&xPilaOperandos))
                         {
                             printf("Error 0. Falta Operador antes de:%c",sExpresion[iIndice]);
                             iResult=-1;
                         }
                         else
                             SbPilaPush(&xPilaOperadores,sExpresion[iIndice]);
                         break;

                case  41:// Primero verifica que haya un operando previo
                         // Se procesa lo que está en la Pila hasta encontrar un )
                         // Ciclo para procesar mientras la pila de operadores no esté vacía

                         while (FnIntPilaCima(&xPilaOperadores)!='(' && ! FnIntPilaVacia(&xPilaOperadores))
                         {

                               // Obtiene el Operador
                               cOperador=FnIntPilaPop(&xPilaOperadores);

                               // Valida que haya operandos
                               if (! FnIntPilaVacia(&xPilaOperandos))

                                  // Obtiene el Operando1
                                  cOperando2=FnIntPilaPop(&xPilaOperandos);

                               else
                               {
                                  printf("Error X. Falta Operando 2 para operación:%c",cOperador);
                                  iResult=-1;
                                  break;
                               }

                               // Valida que haya operandos
                               if (! FnIntPilaVacia(&xPilaOperandos))

                                  // Obtiene el Operando1
                                  cOperando=FnIntPilaPop(&xPilaOperandos);

                               else
                               {
                                  printf("Error X. Falta Operando 1 para operación:%c",cOperador);
                                  iResult=-1;
                                  break;
                               }


                               // Realiza la operación con los 2 operandos de acuerdo al Operador
                               if (cOperador=='+')
                                  iResult= cOperando + cOperando2;
                               else
                                  if (cOperador=='-')
                                     iResult= cOperando - cOperando2;
                                  else
                                     if (cOperador=='*')
                                        iResult= cOperando * cOperando2;
                                     else
                                        if (cOperador=='/')
                                           iResult= cOperando / cOperando2;
                                        else
                                           iResult= pow(cOperando,cOperando2);

                               // Despliega la Operación
                               printf("Se realizó operación 1: %d %c %d = %d\n",cOperando, cOperador,cOperando2,iResult);

                               // Inserta el Operando en la pila
                               SbPilaPush(&xPilaOperandos,iResult);
                               iResult=0;

                         }// While

                         if(iResult!=-1)
                         {

                             // Verifica que la pila  esté vacía
                             if (FnIntPilaVacia(&xPilaOperadores))
                             {
                                printf("Error 2. No se encontró un ( necesario\n");
                                iResult=-1;
                             }
                             else
                             {
                                 // Saca el "(" de la Pila
                                 FnIntPilaPop(&xPilaOperadores);
                                 // 5+139)

                                 // Verifico que no esté en el final
                                 if (iIndice < strlen(sExpresion)-1)
                                 {
                                     // Ahora verifica que si el siguiente elemento es un operador para ver si tiene mayor prioridad
                                     if (FnIntDigitoEs(sExpresion[iIndice+1]))
                                     {
                                         printf("Error 3. Falta un operador antes de:%c\n",sExpresion[iIndice+1]);
                                         iResult=-1;
                                     }
                                     else
                                         // Verifica que el siguiente caracter es un operador
                                         if (FnIntOperadorEs(sExpresion[iIndice+1]))
                                            /// 9*6
                                            // Operadores :
                                            // Operandos  :13
                                            // Verifica que este vacía la pila de operadores
                                            if (FnIntPilaVacia(&xPilaOperadores))
                                            {
                                               // Meto el Operador a la Pila de Operadores ya que no hay con que validar prioridad
                                               SbPilaPush(&xPilaOperadores,sExpresion[++iIndice]);

                                            }
                                            else
                                                // Verifica si el operador en la cima tiene mayor prioridad que el que viene
                                                if (FnIntMayorPrioridad(FnIntPilaCima(&xPilaOperadores),sExpresion[iIndice+1]))
                                                {  // Se realiza la operación actual
                                                   // Obtiene el Operador
                                                   cOperador=FnIntPilaPop(&xPilaOperadores);

                                                   // Obtiene el Operando
                                                   cOperando2=FnIntPilaPop(&xPilaOperandos);

                                                   // Obtiene el Operando
                                                   cOperando=FnIntPilaPop(&xPilaOperandos);

                                                   // Realiza la operación con los 2 operandos de acuerdo al Operador
                                                   if (cOperador=='+')
                                                      iResult= cOperando + cOperando2;
                                                   else
                                                      if (cOperador=='-')
                                                         iResult= cOperando - cOperando2;
                                                      else
                                                         if (cOperador=='*')
                                                            iResult= cOperando * cOperando2;
                                                         else
                                                            if (cOperador=='/')
                                                               iResult= cOperando / cOperando2;
                                                            else
                                                               iResult= pow(cOperando,cOperando2);

                                                   // Despliega la Operación
                                                   printf("Se realizó operación 2: %d %c %d = %d\n",cOperando, cOperador,sExpresion[iIndice]-48,iResult);

                                                   // Inserta el Operando en la pila
                                                   SbPilaPush(&xPilaOperandos,iResult);
                                                   iResult=0;

                                                }
                                                else
                                                {

                                                   // Agrego el Operador con mayor prioridad a la pila e incremento el iIndice
                                                   SbPilaPush(&xPilaOperadores,sExpresion[++iIndice]);

                                                }
                                         else
                                            // Acá es donde se valida si el caracter siguiente es un ")"
                                            if (!sExpresion[iIndice+1]==')')

                                               // Verifica que no sea un ( sin tener un operador antes
                                               if (sExpresion[iIndice+1]=='(')
                                               {
                                                   printf("Error 4. Se necesita un operador antes de un ( \n");
                                                   iResult=-1;
                                               }
                                               else // Caracter No reconocido
                                               {
                                                  printf("Error 5. Caracter No Reconocido :%c\n",sExpresion[iIndice+1]);
                                                  iResult=-1;
                                               }
                                 }
                             }
                         }

                         break;

                case  43:// Suma
                case  45:// Resta
                case  42:// Multiplicación
                case  47:// División
                case 'e':// Exponente
                         // Siempre solo hay un operador en la Pila
                         // Verifica si la Pila de Operadores está vacía
                         if (FnIntPilaVacia(&xPilaOperadores))
                            if (FnIntPilaElementos(&xPilaOperandos)>0)
                            {
                               printf("%c es un Operador; se agrega a la Pila de Operadores \n",sExpresion[iIndice]);
                               SbPilaPush(&xPilaOperadores,sExpresion[iIndice]);
                            }
                            else
                            {
                               printf("Error 6. Operador sin Operando Previo :%c",sExpresion[iIndice]);
                               iResult=-1;
                            }
                         else
                            if (FnIntPilaCima(&xPilaOperadores)!='(')
                            {
                               printf("Error 7. Exceso de Operadores :%c",sExpresion[iIndice]);
                               iResult=-1;
                            }
                            else
                            {
                               printf("%c es un Operador; se agrega a la Pila de Operadores \n",sExpresion[iIndice]);
                               SbPilaPush(&xPilaOperadores,sExpresion[iIndice]);
                            }
                         break;

                case  48:// 0
                case  49:// 1
                case  50:// 2
                case  51:// 3
                case  52:// 4
                case  53:// 5
                case  54:// 6
                case  55:// 7
                case  56:// 8
                case  57:// 9
                         // Verifica si la Pila de Operadores está vacía
                         if (FnIntPilaVacia(&xPilaOperadores))
                            if (FnIntPilaVacia(&xPilaOperandos))
                                // Agrega el Elemento a la Pila de Operandos
                                SbPilaPush(&xPilaOperandos,sExpresion[iIndice]-48);
                            else
                            {
                                printf("Error 8. Exceso de Operandos :%c",sExpresion[iIndice]);
                                iResult=-1;
                            }
                         else
                         {
                            // Se agrega para la Funcion con Prioridad
                            // Verifica si ya es el último caracter de la Expresión
                            if (iIndice == strlen(sExpresion)-1)
                            {
                                // Obtiene el Operador
                                cOperador=FnIntPilaPop(&xPilaOperadores);

                                // Obtiene el Operando
                                cOperando=FnIntPilaPop(&xPilaOperandos);

                                // Realiza la operación con los 2 operandos de acuerdo al Operador
                                if (cOperador=='+')
                                   iResult= cOperando + (sExpresion[iIndice]-48);
                                else
                                   if (cOperador=='-')
                                      iResult= cOperando - (sExpresion[iIndice]-48);
                                   else
                                      if (cOperador=='*')
                                         iResult= cOperando * (sExpresion[iIndice]-48);
                                      else
                                         if (cOperador=='/')
                                            iResult= cOperando / (sExpresion[iIndice]-48);
                                         else
                                            iResult= pow(cOperando,sExpresion[iIndice]-48);

                                // Despliega la Operación
                                printf("Se realizó operación 3: %d %c %d = %d\n",cOperando, cOperador,sExpresion[iIndice]-48,iResult);

                                // Inserta el Operando en la pila
                                SbPilaPush(&xPilaOperandos,iResult);
                                iResult=0;


                                // Ciclo para procesar mientras la pila de operadores no esté vacía
                                while (!FnIntPilaVacia(&xPilaOperadores))
                                {
                                   // Se agrega el IF para considerar paréntesis
                                   if (FnIntPilaCima(&xPilaOperadores)!='(')
                                   {
                                       // Obtiene el Operador
                                       cOperador=FnIntPilaPop(&xPilaOperadores);

                                       // Obtiene el Operando1
                                       cOperando=FnIntPilaPop(&xPilaOperandos);

                                       // Obtiene el Operando2
                                       cOperando2=FnIntPilaPop(&xPilaOperandos);


                                       // Realiza la operación con los 2 operandos de acuerdo al Operador
                                       if (cOperador=='+')
                                          iResult= cOperando2 + cOperando;
                                       else
                                          if (cOperador=='-')
                                             iResult= cOperando2 - cOperando;
                                          else
                                             if (cOperador=='*')
                                                iResult= cOperando2 * cOperando;
                                             else
                                                if (cOperador=='/')
                                                   iResult= cOperando2 / cOperando;
                                                else
                                                   iResult= pow(cOperando2,cOperando);

                                       // Despliega la Operación
                                       printf("Se realizó operación 4: %d %c %d = %d\n",cOperando2, cOperador,cOperando,iResult);

                                       // Inserta el Operando en la pila
                                       SbPilaPush(&xPilaOperandos,iResult);
                                       iResult=0;
                                   }
                                   else
                                   {
                                       // Se agrega este despliegue de error
                                       printf("Error 9. Se encontró un %c sin cierre\n",FnIntPilaPop(&xPilaOperadores));
                                       iResult=-1;

                                   }

                                }
                            }
                            else // El Operando analizado no es el último caracter de la expresin
                                  // 5 + 6 t 8
                                  //
                                  // Operadores:+
                                  // Operandos :56
                                  // Verifica si el caracter siguiente es un dígito
                                  if (FnIntDigitoEs(sExpresion[iIndice+1]))
                                  {
                                     printf("Error 10. Falta un operador antes de:%c\n",sExpresion[iIndice+1]);
                                     iResult=-1;
                                  }
                                  else
                                     // Verifica que el siguiente caracter es un operador
                                     if (FnIntOperadorEs(sExpresion[iIndice+1]))

                                        // Verifica si el operador en la cima tiene mayor prioridad que el que viene ojo
                                        if (FnIntMayorPrioridad(FnIntPilaCima(&xPilaOperadores),sExpresion[iIndice+1]))
                                        {  // Se realiza la operación actual
                                           // Obtiene el Operador
                                           cOperador=FnIntPilaPop(&xPilaOperadores);

                                           // Obtiene el Operando
                                           cOperando=FnIntPilaPop(&xPilaOperandos);

                                           // Realiza la operación con los 2 operandos de acuerdo al Operador
                                           if (cOperador=='+')
                                              iResult= cOperando + (sExpresion[iIndice]-48);
                                           else
                                              if (cOperador=='-')
                                                 iResult= cOperando - (sExpresion[iIndice]-48);
                                              else
                                                 if (cOperador=='*')
                                                    iResult= cOperando * (sExpresion[iIndice]-48);
                                                 else
                                                    if (cOperador=='/')
                                                       iResult= cOperando / (sExpresion[iIndice]-48);
                                                    else
                                                       iResult= pow(cOperando,sExpresion[iIndice]-48);

                                           // Despliega la Operación
                                           printf("Se realizó operación 5: %d %c %d = %d\n",cOperando, cOperador,sExpresion[iIndice]-48,iResult);

                                           // Inserta el Operando en la pila
                                           SbPilaPush(&xPilaOperandos,iResult);
                                           iResult=0;

                                        }
                                        else
                                        {
                                           // Agrego el Operando a la Pila sin procesarlo
                                           SbPilaPush(&xPilaOperandos,sExpresion[iIndice]-48);

                                           // Agrego el Operador con mayor prioridad a la pila e incremento el iIndice
                                           SbPilaPush(&xPilaOperadores,sExpresion[++iIndice]);

                                        }
                                     else
                                        // Acá es donde se valida si el caracter siguiente es un ")"
                                        if (sExpresion[iIndice+1]==')')
                                        {
                                            // Simplemente mete el operando la pila correspondiente
                                            SbPilaPush(&xPilaOperandos,sExpresion[iIndice]-48);

                                        }// If que verifica si es ")"
                                        else
                                           // Verifica que no sea un ( sin tener un operador antes
                                           if (sExpresion[iIndice+1]=='(')
                                           {
                                               printf("Error 11. Se necesita un operador antes de un ( \n");
                                               iResult=-1;
                                           }
                                           else // Caracter No reconocido
                                           {
                                              printf("Error 12. Caracter No Reconocido :%c\n",sExpresion[iIndice+1]);
                                              iResult=-1;
                                           }


                         }

                         break;
                default: printf("Error 13. Caracter no reconocido:%c",sExpresion[iIndice]);
                         iResult=-1;
                         break;

            }// Cierre del switch
        } // Cierre del IF del Espacio en Blanco

        // Verifica que hubo error
        if (iResult==-1)
           break;

    }// Ciclo For
    if (iResult!=-1)
       //if (FnIntPilaElementos(&xPilaOperandos)==1 && FnIntPilaVacia(&xPilaOperadores))
       if (FnIntPilaVacia(&xPilaOperadores))
       {
           iResult = FnIntPilaPop(&xPilaOperandos);
           printf("El resultado de la Expresión %s es:%d \n",sExpresion,iResult);
       }

       else
          printf("Error 14. Exceso de Operadores:%c \n",FnIntPilaPop(&xPilaOperadores));

    // Retorna el Resultado
    return (iResult);

}



// Función Principal
int main()
{
    // Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 14 - Pilas IV\n\n");


    // Evalua la Expresión
    //FnIntExpresionEvaluaCompleta("((5))");
    //FnIntExpresionEvaluaCompleta("(5+6)");
    FnIntExpresionEvaluaCompleta("(5+6)*8");
    //FnIntExpresionEvaluaCompleta("4e2+(5+6)*8");


    //FnIntExpresionEvaluaCompleta("(4e2+(5+6)*(8+4+((7/2)+1)))");
                                //(16 +  11 *(8+4+((3  )+1)))
                                //(16 +  11 *(8+4+( 4     )))
                                //(16 +  11 *(12+4))
                                //(16 +  11 * 16)
                                //(16 +  176)
                                // 192

    // Expresiones con Errores Posibles
    //FnIntExpresionEvaluaCompleta("(+3)");
    //FnIntExpresionEvaluaCompleta("8(5+6)");
    //FnIntExpresionEvaluaCompleta("(5+6");
    //FnIntExpresionEvaluaCompleta("5+6)");
    //FnIntExpresionEvaluaCompleta("((5+6");
    //FnIntExpresionEvaluaCompleta("4e2(5+6)*8");



    // Finaliza
    return 0;

}

// Implementamos Inicializar la Pila
void SbPilaInicializa(pila *pPila)
{
   // Para Inicializa la Pila basta con poner el tope a -1
   // Ya que el primer elemento ocupa la posición 0
   pPila->iPilaTope=-1;

   // Desplegamos Mensaje
   printf("Pila Inicializada ...\n");
}

// Implementamos Verificar si la Pila está vacía
int FnIntPilaVacia(pila *pPila)
{
    if (pPila->iPilaTope==-1)
       return TRUE;
    else
       return FALSE;
}

// Implementamos Verificar si la Pila está llena
int FnIntPilaLlena(pila *pPila)
{
    if (pPila->iPilaTope==PILA_TAMANIO-1)
       return TRUE;
    else
       return FALSE;
}

// Implementamos Obtener cuantos elementos tiene la Pila
int FnIntPilaElementos(pila *pPila)
{
    // Retorna el Tope de la Pila
    return pPila->iPilaTope+1;
}

// Implementamos para Desplegar el Elemento en la Cima
void SbPilaCima(pila *pPila)
{
    // Verificamos si la Pila está vacía
    if (FnIntPilaVacia(pPila))
       printf("La Pila está vacía; no hay elemento Cima\n");
    else
       printf("Pila Cima: %d",pPila->arrIntPila[pPila->iPilaTope]);
}

// Implementamos para Obtener el Elemento en la Cima
int FnIntPilaCima(pila *pPila)
{
    // Verificamos si la Pila está vacía
    if (FnIntPilaVacia(pPila))
       return (-1);
    else
       return(pPila->arrIntPila[pPila->iPilaTope]);
}

// Implementamos Insertar un Elemento en la Pila
void SbPilaPush(pila *pPila,int iElemento)
{
    // Verificamos si la Pila está llena
    if (FnIntPilaLlena(pPila))
       printf("La Pila está llena y no es posible agregar el elemento:%d\n",iElemento);
    else
    {
       // Incrementamos el tope de la pila
       pPila->iPilaTope++;

       // Agrega el Elemento a la Pila
       pPila->arrIntPila[pPila->iPilaTope]=iElemento;

       // Colocamos el dato en la Pila
       //printf("Se ha agregado el elemento %d a la Pila \n",iElemento);
    }
}


// Implementamos Sacar un Elemento de la Pila
int FnIntPilaPop(pila *pPila)
{
    // Verificamos si la Pila está vacía
    if (FnIntPilaVacia(pPila))
    {
       printf("La Pila está vacía no es posible sacar elementos\n");
       return pPila->iPilaTope;
    }
    else
    {
       // Saco el elemento
       int datoASacar = pPila->arrIntPila[pPila->iPilaTope];

       // Decremento el Tope de la Pila
       pPila->iPilaTope--;
       
       // Retorno el dato
       return(datoASacar);
    }
}
