/*
Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE
www.jaorsoftware.cu.cc

Clase 35 - Árbol Binario Expresión Evalúa. Clase Final

En la Clase anterior vimos como crear un Árbol de Expresión
aritmética. En esta clase veremos como utilizando el Recorrido
en PreOrden podemos evaluar la expresión.

Si tenemos el árbol de expresión

                *                                       
         +              -
     5       4      6      +
                         2   1

la lógica que seguiremos será; primero obtener el operador;
que en este caso es la raiz; y despues obtener el primer operando
que es el nodo izquierdo y posteriormente obtener el segundo
operando para poder realizar la operación.

El Algoritmo quedaría de la siguiente forma.
1.- Si el nodo en el que se está es un operador entonces
    1.1.- Llamar a la función para obtener el operando izquierdo
    1.2.- Llamar a la función para obtener el operando derecho.
    1.3.- Realizar la operación de acuerdo al operador
    1.4.- Retornar el resultado.

2.- Si el nodo es un operando, retornarlo.

*/

#include <stdlib.h>
#include <stdio.h>

#define TRUE  1
#define FALSE 0

// Define el Cambio de Línea
#define CR printf("\n")

// Defino la Estructura de los Nodos del Árbol
typedef struct NODO_ARBOL
{
   char    cDato;  // Dato del Nodo
   struct NODO_ARBOL *pIzquierdo;  // Apuntador a Hijo Izquierdo
   struct NODO_ARBOL *pDerecho;    // Apuntador a Hijo Derecho
}nodo_arbol;

// Prototipos
nodo_arbol *FnArbolCreaNodo(char xDato);
int         FnBoolArbolInsertaNodo(nodo_arbol **pRaiz, char xDatoInserta,char xDatoPadre,char cLado);
void        SbArbolRecorreChar(nodo_arbol *pNodo);
int         FnIntArbolBinarioExpresionEvalua(nodo_arbol *pNodo);

// Función Principal
int main()
{
    // Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 35 - Arboles Binario Expresion Evalua \n\n");

    // Declaro el Apuntador a la Raíz.
    nodo_arbol *pRaiz=NULL;

    // Expresión a Insertar: (5 + 4)  *  (6 - (2 + 1)) = 9 * (6-3) = 9 * 3 = 27
    //                *
    //         +              /
    //     5       4      6      +
    //                         2   1
    // 

    printf("Creando el Arbol Binario \n");

    // Insertamos la Secuencia
    FnBoolArbolInsertaNodo(&pRaiz,'*',' ',' ');
    FnBoolArbolInsertaNodo(&pRaiz,'+','*','I');
    FnBoolArbolInsertaNodo(&pRaiz,'5','+','I');
    FnBoolArbolInsertaNodo(&pRaiz,'4','+','D');
    FnBoolArbolInsertaNodo(&pRaiz,'/','*','D');
    FnBoolArbolInsertaNodo(&pRaiz,'6','/','I');
    FnBoolArbolInsertaNodo(&pRaiz,'+','/','D');
    FnBoolArbolInsertaNodo(&pRaiz,'2','+','I');
    FnBoolArbolInsertaNodo(&pRaiz,'1','+','D');
    CR;
    CR;

    SbArbolRecorreChar(pRaiz);
    CR;
    CR;

    // Evaluamos la Expresión
    printf("El Valor de la Expresion del Arbol es:%d \n",FnIntArbolBinarioExpresionEvalua(pRaiz));

    // Finaliza la aplicación retornando 0
    return 0;
}

// Función para crear un Nodo para el Árbol
nodo_arbol *FnArbolCreaNodo(char xDato)
{
   // Defino una variable de tipo Apuntador Nodo
   nodo_arbol *xNodo;

   // Reservo la Memoria para el Nodo
   xNodo = (nodo_arbol *)malloc(sizeof(nodo_arbol));

   // Verifico que haya podido reservar memoria
   if (xNodo == NULL)
      // Despliega el Mensaje de Error
      printf("Error. No se pudo reservar memoria para el Nodo_Arbol");
   else
   {
      // Asigna la Información al Nodo
      xNodo->cDato      = xDato; // El Dato
      xNodo->pDerecho   = NULL;  // Apunta a Null
      xNodo->pIzquierdo = NULL;  // Apunta a Null
   }

   //Retorna el resultado
   return xNodo;
}


// Función para Insertar un Nodo en el Árbol
int FnBoolArbolInsertaNodo(nodo_arbol **pRaiz, char xDatoInserta,char xDatoPadre,char cLado)
{
    // Definiendo un Apuntador Auxiliar
    nodo_arbol *pAuxiliar;

    // Verificamos si está vacío el Árbol
    if (*pRaiz==NULL)
    {

        // Definimos un Apuntador a un Nodo Nuevo
        nodo_arbol *pNodoNuevo;

        // Creamos el Nodo Nuevo
        pNodoNuevo=FnArbolCreaNodo(xDatoInserta);

        // Lo Asignamos como raíz
        *pRaiz=pNodoNuevo;

        // Mensaje
        printf("Se Inserto el Dato:%c como Raiz del Arbol\n",xDatoInserta);

        // Finaliza
        return TRUE;
    }
    // Si no está vacío entramos a un ciclo
    else
    {
       // Colocamos el Auxiliar apuntando a Raíz
       pAuxiliar = *pRaiz;

      // Comparamos si es el dato Padre
      if (pAuxiliar->cDato == xDatoPadre)

         // Verificamos si lo desea insertar a la Derecha
         if (cLado=='D')
         {
             // Verificamos si No tiene Hijo Derecho
             if (pAuxiliar->pDerecho==NULL)
             {
                 // Definimos un Apuntador a un Nodo Nuevo
                 nodo_arbol *pNodoNuevo;

                 // Creamos el Nodo Nuevo
                 pNodoNuevo=FnArbolCreaNodo(xDatoInserta);

                 // No tiene Hijo Derecho; Insertamos
                 pAuxiliar->pDerecho=pNodoNuevo;

                 printf("Inserto  %c del Lado Derecho de %c \n",xDatoInserta,xDatoPadre);

                 // Salimos de la Función
                 return TRUE;
             }
         }
         else
         {
             // Verificamos si tiene Hijo Izquierdo
             if (pAuxiliar->pIzquierdo==NULL)
             {
                 // Definimos un Apuntador a un Nodo Nuevo
                 nodo_arbol *pNodoNuevo;

                 // Creamos el Nodo Nuevo
                 pNodoNuevo=FnArbolCreaNodo(xDatoInserta);

                 // No tiene Hijo Izquierdo; Insertamos
                 pAuxiliar->pIzquierdo=pNodoNuevo;

                 printf("Inserto %c del Lado Izquierdo de %c \n",xDatoInserta,xDatoPadre);
                 // Salimos del Ciclo
                 return TRUE;
             }
          }

      // Busca por ambos lados
      if (pAuxiliar->pIzquierdo!=NULL)
         if (! FnBoolArbolInsertaNodo(&(pAuxiliar->pIzquierdo),xDatoInserta,xDatoPadre,cLado))
            if (pAuxiliar->pDerecho!=NULL)
               if (!FnBoolArbolInsertaNodo(&(pAuxiliar->pDerecho),xDatoInserta,xDatoPadre,cLado))
                  return FALSE;
               else
                  return TRUE;
            else
               return FALSE;
          else
             return TRUE;
       else
          return FALSE;
    }
}

// Recorre el Árbol
void SbArbolRecorreChar(nodo_arbol *pNodo)
{

     // Verifica que no sea Null
     if (pNodo==NULL)
        // Finaliza la Función
        return;
     else
     {
        // Imprime el Contenido del Nodo
        printf("%c \n",pNodo->cDato);

        // Llama a misma Función con el Hijo Izquierdo
        SbArbolRecorreChar(pNodo->pIzquierdo);

        // Llama a misma Función con el Hijo Derecho
        SbArbolRecorreChar(pNodo->pDerecho);

     }
}


// Función para Evaluar la Expresión del Árbol
int FnIntArbolBinarioExpresionEvalua(nodo_arbol *pNodo)
{
   int xValor;
   int xValorIzquierdo;
   int xValorDerecho;

   // Verifica que sea un operador
   if (pNodo->cDato=='+' || pNodo->cDato=='-' || 
       pNodo->cDato=='*' || pNodo->cDato=='/')
   {
      // Es un Operador vuelve a llamar a la función
      xValorIzquierdo = FnIntArbolBinarioExpresionEvalua(pNodo->pIzquierdo);//4
      xValorDerecho   = FnIntArbolBinarioExpresionEvalua(pNodo->pDerecho);  //5

      // Selecciona operación
      switch (pNodo->cDato)
      {
         case '+':
            // Retorna la Suma
            return xValorIzquierdo + xValorDerecho;
         case '-':
            // Retorna la Resta
            return xValorIzquierdo - xValorDerecho;
         case '*':
            // Retorna la Multiplicación
            return xValorIzquierdo * xValorDerecho;
         case '/':
            // Retorna la División
            return xValorIzquierdo / xValorDerecho;
      }

   }
   else
   {
      // Convierte a numero
      xValor = pNodo->cDato - '0';
      return xValor;
   }
}
