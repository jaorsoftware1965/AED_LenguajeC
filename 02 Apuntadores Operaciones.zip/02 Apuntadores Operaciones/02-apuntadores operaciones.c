/*
Curso de Algoritmos y Estructura de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE

Clase 02 - Apuntadores Operaciones

Con los apuntadores, como con cualquier otra variable, es posible realizar
operaciones.

ARITMÉTICA DE APUNTADORES
Sobre las variables de tipo puntero es posible utilizar los operadores +, -,
++ y --. Estos operadores incrementan o decrementan la posición de memoria
a la que “apunta” la variable puntero.

El incremento o decremento se realiza de acuerdo al tipo de dato al que
apunta el puntero, de ahí la importancia de saber cual es el tipo de dato
al que se apunta en el momento de la declaración.

Analicemos la siguiente tabla:

------------------------------------------------------------------
Variable            Dirección         ++      --      +9      -5
------------------------------------------------------------------
int*     piEdad       3000            3002    2998    3018    2990
float*   pfPrecio     5000            5004    4996    5036    4980


COMPARACIÓN DE APUNTADORES
Con las variables apuntador, es posible realizar las operaciones comunes
de relación como son: >, >=, <, <=, == y !=. Ejemplo:

int *pDato1,*pDato2;

if (pDato1 < pDato2)
   printf(“pDato1 apunta a una dirección más baja que pDato2”);


*/

// Inlcuir la libreria
#include <stdio.h>
#include <stdlib.h>

int main()
{
    // Desplegamos Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 02 - Apuntadores \n\n");

    // Declaramos Variables Short Int
    short int  iEdad=34;
    short int* piEdad=&iEdad;

    // Declaramos Variables Int
    int        iOtraEdad=45;
    int*       piOtraEdad=&iOtraEdad;

    // Declaramos Variables Float
    float      fPeso   = 104.50;
    float      fPeso2  = 108.50; 
    float      fPeso3  = 110.50;
    float*     pfPeso  = &fPeso;
    float*     pfPeso2 = &fPeso2; 
    float*     pfPeso3 = &fPeso3;

    // Movere el de enmedio
    pfPeso2++;
    pfPeso2++;
    pfPeso2--;
    pfPeso2--;
    pfPeso2--;


    // Desplegamos los valores
    printf("Valores Iniciales\n");
    printf("El valor de iEdad .....................:%d \n",iEdad);
    printf("La Dirección de iEdad .................:%p \n",&iEdad);
    printf("La Dirección en piEdad: ...............:%p \n",piEdad);
    printf("El Valor en la Direccion en piEdad ....:%d \n\n",*piEdad);

    printf("El valor de iOtraEdad .................:%d \n",iOtraEdad);
    printf("La Dirección de iOtraEdad .............:%p \n",&iOtraEdad);
    printf("La Dirección en piOtraEdad ............:%p \n",piOtraEdad);
    printf("El Valor en la Dirección en piOtraEdad.:%d \n\n",*piOtraEdad);

    printf("El Valor de fPeso .....................:%f \n",fPeso);
    printf("La Dirección de fPeso .................:%p \n",&fPeso);
    printf("La Dirección en pfPeso ................:%p \n",pfPeso);
    printf("El Valor en la Dirección en pfPeso ....:%f \n\n",*pfPeso);

    printf("El Valor de fPeso2.....................:%f \n",fPeso2);
    printf("La Dirección de fPeso2.................:%p \n",&fPeso2);
    printf("El Valor de fPeso3.....................:%f \n",fPeso3);
    printf("La Dirección de fPeso3.................:%p \n\n",&fPeso3);


    printf("Bytes usados para Variable iEdad ......:%d \n",sizeof(iEdad));
    printf("Bytes usados para Variable iOtraEdad ..:%d \n",sizeof(iOtraEdad));
    printf("Bytes usados para Variable fPeso ......:%d \n\n",sizeof(fPeso));

    // Incrementamos la dirección del Apuntador piEdad
    piEdad++;
    printf("La Dirección de iEdad .................:%p \n",&iEdad);
    printf("El valor de iEdad .....................:%d \n",iEdad);
    printf("La Dirección en piEdad: ...............:%p \n",piEdad);
    printf("El Valor en la Dirección en piEdad ....:%d \n\n",*piEdad);

    // Incrementamos la dirección del Apuntador fPeso
    pfPeso=pfPeso+1;
    printf("El Valor de fPeso .....................:%f \n",fPeso);
    printf("La Dirección de fPeso .................:%p \n",&fPeso);
    printf("La Dirección en pfPeso ................:%p \n",pfPeso);
    printf("El Valor en la Dirección en pfPeso ....:%f \n\n",*pfPeso);

    // Comparamos Direcciones
    if (pfPeso < piEdad)
       printf("El Peso está almacenado en Memoria antes que la Edad \n");
    else
       printf("El Peso está almacenado en Memoria despues que la Edad \n");

    // Incrementando el Peso
    if (*pfPeso > 100)
       printf("El Peso es mayor de 100 Kilos \n");
    else
       printf("El Peso es menor o igual que 100 Kilos \n");

    // MOdificamos el Peso
    *pfPeso = 90;

    if (*pfPeso > 100)
       printf("El Peso es mayor de 100 Kilos \n",*pfPeso);
    else
       printf("El Peso es menor o igual que 100 Kilos \n",*pfPeso);

    return 0;
}
