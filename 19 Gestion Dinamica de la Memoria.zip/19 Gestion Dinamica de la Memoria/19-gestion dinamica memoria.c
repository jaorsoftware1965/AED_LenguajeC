/*
Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE
www.jaorsoftware.com

Clase 19 - Gestión Dinámica de Memoria

Manejar dinámicamente la memoria, en una aplicación; significa
el poder reservar mas memoria de la que inicialmente se especifique
e inclusive poder disminuirla. Dicho de otra forma; poder declarar
variables en momento de ejecución.

En las Estructuras de Datos vistas anteriormente; Pilas y Filas; la
memoría que se ha manejado ha sido estática; es decir que tiene una
longitud fija la cual no puede incrementarse o disminuirse.

Tanto para las Pilas como para las Filas, se han manejado arreglos;
los cuales han tenido una longitud fija; por lo cual; las Pilas y las
Filas que se han implementado han tenido un tamaño limitado.

Para la presentación de las siguientes Estructuras y Algoritmos; es
necesario hacer uso de la Memoria en forma Dinámica; es decir; que
podamos incrementar o disminuir la memoria; al momento en que el
programa se encuentre ejecutándose.

Para lograr hacer esto en C; la función mas utilizada es: malloc.
La sintaxis de la función malloc es la siguiente:

void* malloc(unsigned size_in_bytes);

La Función malloc, reserva la cantidad de bytes indicada en el parámetro
y devuelve un puntero del tipo void*, el cual apunta a la dirección del
bloque de memoria reservado. En caso de que no exista memoria disponible
para reservar; malloc devuelve NULL.

Para poder hacer uso adecuadamente del puntero devuelto por la función,
es necesario realizar un "cast" del puntero devuelto; al tipo de dato
adecuado que nos permita manejar correctamente la información.

tipo *puntero;
puntero =  (tipo *)malloc(bytes);

Ejemplo:

long *pLong;
pLong = (long *)malloc(32);

Para poder tener una visión mas clara de la cantidad de memoria que
deseamos reservar, es muy útil utilizar el operador sizeof el cual
nos devuelve el número de bytes usado por cualquier tipo de dato
o variable. Si quisieramos reservar memoria para 10 caracteres,
pudieramos realizarlo de la siguiente forma:

char *pCadena;
pCadena = (char *) malloc(1O * sizeof(char)) ;

LIBERACIÓN DE MEMORIA.free
Cuando se ha terminado de utilizar un bloque de memoria previamente
asignado por malloc(), u otras funciones similares, se debe liberar
el espacio de memoria y dejarlo disponible para otros usos, mediante
una llamada a la función free(). El bloque de memoria reservado se
devuelve al espacio de almacenamiento libre, de modo que habrá más
memoria disponible para asignar otros bloques de memoria. El formato
de la llamada es:

free (puntero);

Ejemplo:

// Declara un puntero a entero
int *pEntero;

// Reserva memoria para un Entero
pEntero = (int*)malloc(sizeof(int));

// Libera la memoria
free(pEntero);

*/

// Librerias
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

// Estructura
typedef struct Test
{
    // Variable para manejar el frente y final de la Fila
    char  xChar;
    int   xInt;
}test;


// Función Principal
int main()
{
    // Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 19 - Gestión Dinámica de Memoria \n\n");

    // Declara una variable apuntador a Entero
    int *pEntero;

    // Reserva memoria para la variable
    printf("sizeOf de int :%d\n",sizeof(int));
    pEntero = (int *) malloc(sizeof(int));
    printf("sizeOf de int :%d\n",sizeof(pEntero));

    // Verifica que no haya devuelvo Null
    if (pEntero == NULL)
       printf("No pudo Reservar memoria \n");

    // Coloca un valor en la memoria reservada
    *pEntero = 90;

    // Imprimimos el Valor del Apuntador Entero
    printf("pEntero = %d \n",*pEntero);

    // Libera la Memoria
    free(pEntero);

    // Imprimimos el Valor del Apuntador Entero
    printf("pEntero = %d \n",*pEntero);

    // Declaramos una variable cadena
    char *pCadena;

    // Reservo memoria para la Cadena
    printf("sizeOf de char :%d\n",sizeof(char));
    pCadena = (char*) malloc(13 * sizeof(char));

    // Copio la Variable de Cadena a la Nueva Variable
    strcpy (pCadena, "jaorsoftware");

    // Despliego el Valor de la Variable
    printf ("pCadena = %s \n",pCadena);

    // Libera la Memoria
    free (pCadena) ;

    // Despliego el Valor de la Variable
    printf ("pCadena = %s \n",pCadena);

    // Creamos un apuntador a la estructura
    test *xTest;
    printf("sizeOf de xTest :%d\n",sizeof(xTest));
    xTest = (test *) malloc(sizeof(xTest));

    // Colocamos datos
    xTest->xInt=10;
    xTest->xChar='A';

    printf ("xInt    = %d \n",xTest->xInt);
    printf ("xChar   = %c \n",xTest->xChar);

    // Liberaos
    free(xTest);
    
    printf ("xInt    = %d \n",xTest->xInt);
    printf ("xChar   = %c \n",xTest->xChar);

    // Programa para detectar la memoria libre
    void *pVoid ;
    int  iCuenta;
    long lMemoria = 0;

    // Ciclo para obtener memoria
    for ( iCuenta = 1; ; iCuenta++)
    {
        // Intenta Reservar 1000 Bytes
        pVoid = malloc(1000);

        // Verifica que pudo reservar
        if (pVoid == NULL)

           // Sale del Ciclo en caso de que NO ya podido reservar
           break;

       
        // Incrementa el Contador de Memoria
        lMemoria += 100000;
        //printf("[%u] ",lMemoria);
    }

    // Despliega Memoria asignada
    printf ("\nTotal de Memoria Reservada %ul \n",lMemoria) ;

    // Finaliza
    return 0;

}
