/*

Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE

Clase 08 - Estructuras II

DEFINIENDO UN TIPO DE ESTRUCTURA.
Podemos usar typedef para definir una estructura tal y como se observa
en el siguiente ejemplo:

typedef struct [nombre_estructura]
{
   char          sTitulo[100];
   char          sAutor[75];
   unsigned long ulPrecio;
}libros;

Y posteriormente definir variables de la estructura, como de cualquier otro
tipo, y sin utilizar la palabra struct antes de la definición. Ejemplo:

libros xLibro,yLibro;

ASIGNACIÓN.
El estándar ANSI de C permite la asignación de variables de estructuras
del mismo tipo. Utilizando las variables anteriores, podemos realizar
la siguiente instrucción de asignación:

xLibro = yLibro;

La cual sería equivalente a:

strcpy(xLibro.sTitulo,yLibro.sTitulo);
strcpy(xLibro.sAutor,yLibro.sAutor;
xLibro.ulPrecio = yLibro.ulPrecio;

APUNTADORES a Estructuras.
Podemos definir apuntadores a estructuras; como lo hemos hecho anteriormente
con los tipos de datos; solo que para acceder al contenido de la variable a
la que apunta, se utiliza el operador "->". Ejemplo

libro xLibro,*pLibro;

// Asignando la dirección es de la misma forma
pLibro = &xLibro;

// Accediendo al Contenido
pLibro->ulPrecio = 24.50;
(*pLibro).ulPrecio = 24.50;

Es posible definir arreglos y matrices de estructuras, tal y como se realizan
con los demás tipos de datos.

*/

// Librerias
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Definimos una estructura para Personas
typedef struct stcPersona
{
    char sPersonaNombre[30];
    char sPersonaApellido[30];
    char cPersonaSexo;
    int  iPersonaEdad;
}persona;

// Función Principal
int main()
{
    // Definimos un vector de personas
    persona arrPersonas[2];

    // Definimos un apuntador a personas
    persona *pPersona;

    // Definimos 1 variable desde la estructura
    struct stcPersona xPersona;
    
    // Desplegamos Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 08 - Estructuras II\n\n");

    // Inicializamos la Persona
    strcpy(xPersona.sPersonaNombre,"Juan");
    strcpy(xPersona.sPersonaApellido,"Perez");
    xPersona.cPersonaSexo='H';
    xPersona.iPersonaEdad=33;

    // Otra variable para verificar asignación
    persona xPersona2;
    xPersona2 = xPersona;


    // Imprimimos los datos de la persona
    printf("Datos de la Persona \n");
    printf("------------------- \n");
    printf("Nombre    :%s \n",xPersona.sPersonaNombre);
    printf("Apellido  :%s \n",xPersona.sPersonaApellido);
    printf("Sexo      :%c \n",xPersona.cPersonaSexo);
    printf("Edad      :%d \n\n",xPersona.iPersonaEdad);

    printf("Nombre    :%s \n",xPersona2.sPersonaNombre);
    printf("Apellido  :%s \n",xPersona2.sPersonaApellido);
    printf("Sexo      :%c \n",xPersona2.cPersonaSexo);
    printf("Edad      :%d \n\n",xPersona2.iPersonaEdad);


    // Hacemos que el apuntador tenga la dirección de la Persona
    pPersona = &xPersona;

    // Imprimimos los datos de la persona desde el Apuntador
    printf("Datos de la Persona desde el Apuntador \n");
    printf("-------------------------------------- \n");
    printf("Nombre    :%s \n",  pPersona->sPersonaNombre);
    printf("Nombre    :%s \n",(*pPersona).sPersonaNombre);
    printf("Apellido  :%s \n",  pPersona->sPersonaApellido);
    printf("Sexo      :%c \n",  pPersona->cPersonaSexo);
    printf("Edad      :%d \n\n",pPersona->iPersonaEdad);

    // Cambiamos los datos desde el Apuntador
    strcpy(pPersona->sPersonaNombre,"María");
    strcpy(pPersona->sPersonaApellido,"Morales");
    
    (*pPersona).cPersonaSexo='M';
    (*pPersona).iPersonaEdad=24;

    // Asignamos los datos de la Persona al Vector
    arrPersonas[0]=xPersona;
    arrPersonas[1]=arrPersonas[0];



    // Imprimimos los datos de las personas del Vector
    printf("Datos de la Persona 0\n");
    printf("--------------------- \n");
    printf("Nombre    :%s \n",arrPersonas[0].sPersonaNombre);
    printf("Apellido  :%s \n",arrPersonas[0].sPersonaApellido);
    printf("Sexo      :%c \n",arrPersonas[0].cPersonaSexo);
    printf("Edad      :%d \n\n",arrPersonas[0].iPersonaEdad);

    // Imprimimos los datos de las personas del Vector
    printf("Datos de la Persona 1\n");
    printf("--------------------- \n");
    printf("Nombre    :%s \n",arrPersonas[1].sPersonaNombre);
    printf("Apellido  :%s \n",arrPersonas[1].sPersonaApellido);
    printf("Sexo      :%c \n",arrPersonas[1].cPersonaSexo);
    printf("Edad      :%d \n\n",arrPersonas[1].iPersonaEdad);

    // Finaliza con 0 la aplicación
    return 0;
}

