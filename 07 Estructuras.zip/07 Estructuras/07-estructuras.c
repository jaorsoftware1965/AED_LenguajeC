/*
Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE
www.jaorsoftware.com

Clase 07 - Estructuras

Una estructura es un conjunto de variables que se referencian bajo el mismo
nombre. La sintaxis de la declaración de una estructura en lenguaje C es:

struct [nombre]
{
    tipo nombre_variable_1;
    tipo nombre_variable_2;
    ...
    tipo nombre_variable_n;
}[x,y,z];

Es posible no poner el nombre de la estructura, cuando al realizar la declaración
se indican las variables que se van a utilizar. Si las variables de la estructura
se declaran posteriormente, si es necesario indicar el nombre de la estructura.

Podemos decir que una estructura es como definir un tipo de dato; ya que vamos
a poder declarar variables de esa estructura. Para definir una variable de una
estructura se realiza lo siguiente:

struct nombre_estructura variable;

Para acceder a cada una de las variables definidas, se coloca el nombre de la
variable de la estructura; seguida de un "." y despues la variable definida en
la estructura a la que se desea acceder.

Es posible definir variables de estructuras dentro de la definición de una 
estructura.

Las estructuras son los primeros antecedentes de la actual programación orientada
a objetos. Ejemplo:

struct stcPersona
{
    char strNombre[30];
    char strApellidoPaterno[30];
    char strApellidoMaterno[30];
    char cGenero;
    int  iEdad;
} xPersona;

*/

// Incluimos librerias
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Definimos una estructura para Personas
struct stcPersona
{
    char sPersonaNombre[30];
    char sPersonaApellido[30];
    char cPersonaGenero;
    int  iPersonaEdad;
    struct
    {
         int dia;
         int mes;
         int anio;
    }
}xPersona={"Jaor","Software",'H',34,{12,13,10}};

// Definimos una estructura para Carreras
struct stcCarrera
{
    char sCarreraCve[10];
    char sCarreraNom[30];
}xCarrera;


// Función Principal
int main()
{
    // Local a la Función
    struct stcAlumno
    {
        char   sAlumnoClave[10];
        struct stcPersona xAlumnoPersona;
        struct stcCarrera xAlumnoCarrera;
    };

    // Definimos una variable de la Estructura
    struct stcAlumno xAlumno;

    // Desplegamos Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 07 - Estructuras \n\n");

    // Asigamos valores a la variable de la estructura
    strcpy(xPersona.sPersonaNombre,"Juan");
    strcpy(xPersona.sPersonaApellido,"Perez");
    xPersona.cPersonaGenero = 'H';
    xPersona.iPersonaEdad   = 24;

    // Imprimimos los datos de la persona
    printf("Datos de la Persona \n");
    printf("------------------- \n");
    printf("Nombre    :%s \n",xPersona.sPersonaNombre);
    printf("Apellido  :%s \n",xPersona.sPersonaApellido);
    printf("Sexo      :%c \n",xPersona.cPersonaGenero);
    printf("Edad      :%d \n\n",xPersona.iPersonaEdad);

    // Asignamos valores a variable Carrera
    strcpy(xCarrera.sCarreraCve,"INFME2015");
    strcpy(xCarrera.sCarreraNom,"Informatica");

    // Desplegamos información de Carrera
    printf("Datos de la Carrera \n");
    printf("------------------- \n");
    printf("Clave    :%s \n",xCarrera.sCarreraCve);
    printf("Nombre   :%s \n\n",xCarrera.sCarreraNom);

    // Asignamos Valores al Alumno
    strcpy(xAlumno.sAlumnoClave,"JPRE23455");
    strcpy(xAlumno.xAlumnoCarrera.sCarreraCve,xCarrera.sCarreraCve);
    strcpy(xAlumno.xAlumnoCarrera.sCarreraNom,xCarrera.sCarreraNom);
    strcpy(xAlumno.xAlumnoPersona.sPersonaNombre,xPersona.sPersonaNombre);
    strcpy(xAlumno.xAlumnoPersona.sPersonaApellido,xPersona.sPersonaApellido);
    xAlumno.xAlumnoPersona.cPersonaGenero=xPersona.cPersonaGenero;
    xAlumno.xAlumnoPersona.iPersonaEdad=xPersona.iPersonaEdad;

    // Desplegamos información de Carrera
    printf("Datos del Alumno \n");
    printf("---------------- \n");
    printf("Clave        :%s \n",xAlumno.sAlumnoClave);
    printf("Nombre       :%s \n",xAlumno.xAlumnoPersona.sPersonaNombre);
    printf("Apellido     :%s \n",xAlumno.xAlumnoPersona.sPersonaApellido);
    printf("Sexo         :%c \n",xAlumno.xAlumnoPersona.cPersonaGenero);
    printf("Edad         :%d \n",xAlumno.xAlumnoPersona.iPersonaEdad);
    printf("Carrera Cve  :%s \n",xAlumno.xAlumnoCarrera.sCarreraCve);
    printf("Carrera Nom  :%s \n",xAlumno.xAlumnoCarrera.sCarreraNom);


    return 0;
}
