
// Librerias
#include<stdio.h>
#include<stdlib.h>

// Constantes
#define Max_elementos_cola 10 //máximo elementos de la cola
#define Pos_frente 0          //posicion del frente siempre es 0

int pos_final = -1;           //posicion final de la cola 
int elementos_cola;           //variable para elementos de la cola
int cola[Max_elementos_cola]; //definir la cola

//funcion para insertar un elemento
void insertar(int elemento)
{
    if(pos_final < -1)
    {
        pos_final++;
        cola[pos_final] = elemento;
        printf("El elemento esta en la posision[%d]. \n",pos_final);
    }
    else
    {

        printf("YA no hay espacio en la cola.\n");
    }
    system("pause");
}

void imprimirCola(){
    //verificar que haya datos en la cola
    if(pos_final >= 0){
        
        printf("LOs elementos en la cola son: \n");

        for (int i = 0; i <= pos_final; i++){
            
            printf("Posision[%d]: %d\n",i,cola[i]);
        }    
    }else{
        printf("La cola esta vacia, no hay elementos para desplegar.\n");
    }

system("pause");
}
//funcion para iomprimir el frente de la cola
void colaFrente(){
    //verificar que haya elementos en la cola
    if (pos_final >= 0){
        
        printf("El frente de la cola es: %d",cola[Pos_frente]);
    }else{
        printf("No hay elementos en la cola.\n");
    }
    
system("pause");
}
//funcion para imprimir el final de la cola
void colaFinal(){
    //verificar que haya elementos en la cola
    if (pos_final >= 0){
        
        printf("El final de la cola es: %d",cola[pos_final]);
    }else{
        printf("No hay elementos en la cola.\n");
    }
    
system("pause");
}

//funcion para eliminar un elemento
int eliminarCola(){
    //verificar que la cola no esté vacia
    if(pos_final < 0){
        printf("La cola esta vacia.\n");
    }else{
        //El elemento que se elimina siempre va a ser el de enfrente
        printf("El elemento eliminado es: %d", cola[Pos_frente]);
        //verificar si hay umas de un elemento en el arreglo(cola)
        if(pos_final > 0 ){
            //recorrer los elementos
            for (int i = 0; i < pos_final; i++){
               
               cola[i] = cola[i+1];
            }
            
        }
        //decrementar el valor de la posision final
        pos_final--;
    }    
}
void menu(){
    printf("\t-----\n");
    printf("\tMENU\n");
    printf("\t-----\n");

    printf("Seleccione una opcion:\n");

    printf("\n\t1) Insertar.\n\t2) Eliminar.\n\t3) Mostrar el frente de la cola.\n\t4) Mostrara el final de la cola.\n\t5) Imprimir la cola.\n\t6) Salir.\n");

    printf("Opcion: ");
}

int main(){
    int opc, elemento, tam;

    printf("Indica el tamaño de la cola(MAX = 10): ");
    scanf("%d", &tam);

    //verificar que no s epase de lo estavlecido
    if (tam > Max_elementos_cola)
    {
        printf("El numero de elementos no pude ser mayor a 0.\n");
    system("pause");
    return 0;
    }
    

    do
    {
        menu();
        scanf("%d", &opc);

        switch (opc)
        {
        case 1:
            printf("Digite un elemento a encolar: ");
            fflush(stdin);
            scanf("%d", &elemento);

            insertar(elemento);
        break;

        case 2:
            eliminarCola();
        break;

        case 3:
            colaFrente();
        break;

        case 4:
            colaFinal();
        break;

        case 5:
            imprimirCola(); 
        break;
        
        default:
        printf("Esa opcion no es valida.\n");
        break;
        }
    } while (opc != 6);
printf("\n");
system("pause");
return 0;    
}