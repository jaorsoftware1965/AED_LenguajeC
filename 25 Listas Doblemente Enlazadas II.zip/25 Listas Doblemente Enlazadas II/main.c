/*
Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE
www.jaorsoftware.com

Clase 25 - Listas Doblemente Enlazadas II

En esta Clase Continuaremos Viendo el Tema de las Listas Doblemente
Enlazadas.

Primeramente agregaremos el Apuntador COLA; el cual nos permitirá
tener un acceso mas inmediato al último elemento de la Lista sin tener
que recorrerla toda.

GRÁFICAMENTE.

      CABEZA                                       COLA
         |                                           |
         |                                           |
       Nodo1       Nodo2      Nodo3      Nodo4      Nodo5
nil<--|PAnter|<--|PAnter|<--|PAnter|<--|PAnter|<--|PAnter|
      |Valor1|   |Valor2|   |Valor3|   |Valor4|   |Valor5|
      |PSigte|-->|PSigte|-->|PSigte|-->|PSigte|-->|PSigte|-->nil


Modificaremos la Rutina de Insertar, para que cuando se inserte
el Primer elemento de la Lista,hagamos que al igual que CABEZA,
COLA tambien apunte a este Nodo.

GRAFICAMENTE

    CABEZA COLA
        |   |
        |   |
       NodoNvo
nil<--|PAnter|
      |Valor1|
      |PSigte|-->nil


INSERTAR. Al Final de la Lista (Cuando no está vacía)

a) Crear el Nodo Nvo con el Valor Correspondiente
b) Hacer que el Nodo Nuevo->Siguiente  = nil
c) Hacer que el Nodo Nuevo->Anterior  = COLA

d) Hacer que COLA->Siguiente apunte al Nodo Nuevo
e) Hacer que COLA apunte al Nuevo Nodo

GRAFICAMENTE

       CABEZA      COLA
         |           |
         |           |
       Nodo1      Nodo2
nil<--|PAnter|<--|PAnter|
      |Valor1|   |Valor2|
      |PSigte|-->|pSigte|-->nil

       CABEZA                COLA
         |                     |
         |                     |
       Nodo1      Nodo2      Nuevo
nil<--|PAnter|<--|PAnter|<--|PAnter|
      |Valor1|   |Valor2|   |ValorN|
      |PSigte|-->|pSigte|-->|PSigte|-->nil


ELIMINAR. Al final de la Lista
1) Cuando hay un solo elemento, es decir
COLA=CABEZA

b) Se Libera COLA o CABEZA
c) Se apunta a Null Ambos


2)(Cuando hay mas de un elemento es decir
que COLA es diferente de CABEZA)

a) Liberar la Memoria de COLA
b) Hacer que Cola apunte a Cola->Anterior   <--- Error
c) Hacer que Cola->Siguiente apunte a NULL

0. Aux = Cola
1.- Cola apunte a Cola-panterior
2.- Cola psieuitnge->nill
3.- Liberar Aux

      CABEZA       COLA
         |         |
         |         |
       Nodo1      Nodo2      Nodo3
nil<--|PAnter|<--|PAnter|<--|PAnter|
      |Valor1|   |Valor2|   |ValorN|
      |PSigte|-->|pSigte|-->|PSigte|-->nil

      CABEZA       COLA
         |          |
         |          |
       Nodo1      Nodo2           Nodo3
nil<--|PAnter|<--|PAnter|        |PAnter|
      |Valor1|   |Valor2|        |ValorN|
      |PSigte|-->|pSigte|-->nil  |PSigte|-->nil


DESPLEGAR LA LISTA.
Diseñamos otra rutina que despliega la Lista Doblemente enlazada,en la cual
el recorrido inverso, ya inicie desde COLA


*/
// Librerias
#include <stdlib.h>
#include <stdio.h>

// Constantes
#define TRUE  1
#define FALSE 0

// Define la Estructura para los Nodos
struct stcNodo
{
   int iDato;
   struct stcNodo *pSiguiente;
   struct stcNodo *pAnterior;
};

// Define el tipo de acuerdo a la Estructura
typedef struct stcNodo nodo;

// Funcion para crear un Nodo
nodo *FnNodoCrea(int xDato)
{
   // Defino una variable de tipo Apuntador Nodo
   nodo *xNodo;

   // Reservo la Memoria para el Nodo
   xNodo = (nodo *)malloc(sizeof(nodo));

   
   // Verifico que haya podido reservar memoria
   if (xNodo == NULL)
      // Despliega el Mensaje de Error
      printf("Error. No se pudo reservar memoria para el Nodo");
   else
   {
      // Asigna la Informacion al Nodo
      xNodo->iDato      = xDato; // El Dato
      xNodo->pSiguiente = NULL;  // Apunta a Null
      xNodo->pAnterior  = NULL;
   }

   //Retorna el resultado
   return xNodo;
}

// Funcion para verificar si una Lista Enlazada esta vacia
int FnIntListaVacia(nodo *pCabeza)
{
   // Verifica si esta apuntando a Null
   if (pCabeza==NULL)
   {
      printf("La Lista esta vacia \n");
      return TRUE;
   }
   else
   {
      printf("La Lista no esta vacia \n");
      return FALSE;
   }
}

// Función para Insertar un Elemento al Final de la Lista Doblemente Enlazada
void SbListaDobleInsertarFinal(nodo **pCabeza,nodo **pCola, int xDato)
{

    //a) Crear el Nodo Nuevo con el Valor Correspondiente.
    nodo *pNodoNuevo;

    // Crea un Nuevo Nodo apuntando a Null
    pNodoNuevo=FnNodoCrea(xDato);

    // Verifica si está vacía ( Mandamos con pCola en lugar de pCabeza)
    if (FnIntListaVacia(*pCabeza))
    {
        // b) Siguiente y anterior apunta a NULL
        pNodoNuevo->pSiguiente = NULL;
        pNodoNuevo->pAnterior = NULL;

        // c) Hacer que Cabeza apunte al Nodo Nuevo.
        *pCabeza=pNodoNuevo;

        // d) Hacer que Cola apunte tambien al Nodo Nuevo.
        *pCola=pNodoNuevo;

        // Mensaje
        printf("Inserción Lista Doblemente Enlazada Vacía; Elemento %d en dirección %p \n\n",xDato,pNodoNuevo);
    }
    else
    {
        // b) Hacer que el Nodo Nuevo->Siguiente  = nil
        pNodoNuevo->pSiguiente = NULL;

        // c) Hacer que el Nodo Nuevo->Anterior  = COLA
        pNodoNuevo->pAnterior = *pCola;

        // d) Hacer que COLA->Siguiente apunte al Nodo Nuevo
        (*pCola)->pSiguiente = pNodoNuevo;

        // e) Hacer que COLA apunte al Nuevo Nodo
        *pCola = pNodoNuevo;

        // Mensaje
        printf("Inserción Final Lista Doblemente Enlazada Elemento %d en dirección %p \n\n",xDato,pNodoNuevo);
    }
}

// Función para Eliminar un Elemento del Final de la Lista Doble
nodo FnNodoListaDobleEliminaFinal(nodo **pCabeza,nodo **pCola)
{

    // Definimos un Apuntador a un Nodo
    nodo xNodo;

    // Inicializa
    xNodo.iDato=-1;
    xNodo.pSiguiente=NULL;
    xNodo.pAnterior=NULL;

    // Verifica si está vacía ( Mandamos con pCola en lugar de pCabeza)
    if (FnIntListaVacia(*pCabeza))
    {
        // Mensaje
        printf("La Lista Doblemente Enlazada está vacía, no es posible eliminar Elementos \n\n");
    }
    else
    {
        // Obtenemos la información del Nodo a Eliminar
        xNodo.iDato      = (*pCola)->iDato;
        xNodo.pSiguiente = (*pCola)->pSiguiente;
        xNodo.pAnterior  = (*pCola)->pAnterior;

        // Verificamos que sea el único elemento
        if (*pCola == *pCabeza)
        {
            // a) Liberar el Nodo a que apunta CABEZA o COLA
            free(*pCabeza);

            // Establecemos en NULL ambos
            *pCabeza = NULL;
            *pCola = NULL;

        }
        else
        {
            // a) Liberar la Memoria de COLA
            free(*pCola);

            // b) Hacer que Cola apunte a Cola->Anterior
            //*pCola = (*pCola)->pAnterior; // Error
            *pCola = xNodo.pAnterior;

            // c) Hacer que Cola->Siguiente apunte a NULL
            (*pCola)->pSiguiente = NULL;
        }
        // Mensaje
        printf("Eliminación Final Lista Doblemente Enlazada Elemento:%d Sigte:%p Anter:%p \n\n",xNodo.iDato,xNodo.pSiguiente,xNodo.pAnterior);
    }
    // Retorna el Nodo
    return xNodo;
}

// Función para desplegar los Elementos en Orden Normal e Inverso
void SbListaDobleDespliegaFull(nodo *pCabeza,nodo *pCola,int iOrdenNormal)
{
    // Para Contar los Elementos
    char iContar=0;

    // Verificamos que esté vacía
    if (FnIntListaVacia(pCabeza))
    {
       // Mensaje de Lista Vacía
       printf("La Lista Doblemente Enlazada se encuentra vacía; no hay valores que desplegar");
    }
    else
    {
        // Desplegando los Elementos de la lista
        printf("Desplegando los Elementos de la Lista ");

        // Verifica el Orden
        if (iOrdenNormal)
        {
            // Despliega el Orden
            printf("en orden normal \n");

            // Ciclo para desplegar los Elementos de la Lista
            while (pCabeza!=NULL)
            {
               // Despliega la información del Nodo
               printf("Elemento:%d Valor:%d en dirección:%p pSigte:%p pAnter:%p \n",++iContar,pCabeza->iDato,pCabeza,pCabeza->pSiguiente,pCabeza->pAnterior);

               // Mueve cabeza al siguiente elemento
               pCabeza = pCabeza->pSiguiente;
            }
         }
         else
         {
            // Despliega el Orden
            printf("en orden inverso \n");

            // Ciclo para desplegar los Elementos de la Lista
            while (pCola!=NULL)
            {
               // Despliega la información del Nodo
               printf("Elemento:%d Valor:%d en dirección:%p pSigte:%p pAnter:%p \n",++iContar,pCola->iDato,pCola,pCola->pSiguiente,pCola->pAnterior);

               // Mueve cabeza al siguiente elemento
               pCola = pCola->pAnterior;
            }

         }
    }
    // Deja una Línea
    printf("\n");

}


// Función Principal
int main()
{
    // Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 25 - Listas Doblemente Enlazadas II\n\n");

    // Declaramos apuntadores de Cabeza y Cola
    nodo *pCabeza=NULL;
    nodo *pCola=NULL;

    // Variable Nodo para Eliminar
    nodo xNodo;

    // Inserta un Elemento al Final
    SbListaDobleInsertarFinal(&pCabeza,&pCola,10);

    // Despliega la Lista en Orden Normal
    SbListaDobleDespliegaFull(pCabeza,pCola,TRUE);

    // Inserta un Elemento al Final
    SbListaDobleInsertarFinal(&pCabeza,&pCola,20);

    // Despliega la Lista en Orden Normal
    SbListaDobleDespliegaFull(pCabeza,pCola,TRUE);

    // Inserta un Elemento al Final
    SbListaDobleInsertarFinal(&pCabeza,&pCola,30);

    // Inserta un Elemento al Final
    SbListaDobleInsertarFinal(&pCabeza,&pCola,40);

    // Inserta un Elemento al Final
    SbListaDobleInsertarFinal(&pCabeza,&pCola,50);

    // Despliega la Lista en Orden Normal
    SbListaDobleDespliegaFull(pCabeza,pCola,TRUE);

    // Despliega la Lista en Orden Inverso
    SbListaDobleDespliegaFull(pCabeza,pCola,FALSE);

    // Eliminamos un Elemento
    xNodo = FnNodoListaDobleEliminaFinal(&pCabeza,&pCola);

    // Desplegamos Información del Nodo Eliminado
    printf("Información del Nodo:%d Sigte:%p Anter:%p\n",xNodo.iDato,xNodo.pSiguiente,xNodo.pAnterior);

    // Despliega la Lista en Orden Normal
    SbListaDobleDespliegaFull(pCabeza,pCola,TRUE);

    // Despliega la Lista en Orden INVERSO
    SbListaDobleDespliegaFull(pCabeza,pCola,FALSE);

    // Eliminamos un Elemento
    xNodo = FnNodoListaDobleEliminaFinal(&pCabeza,&pCola);

    // Desplegamos Información del Nodo Eliminado
    printf("Información del Nodo:%d Sigte:%p Anter:%p\n",xNodo.iDato,xNodo.pSiguiente,xNodo.pAnterior);

    // Eliminamos un Elemento
    xNodo = FnNodoListaDobleEliminaFinal(&pCabeza,&pCola);

    // Desplegamos Información del Nodo Eliminado
    printf("Información del Nodo:%d Sigte:%p Anter:%p\n",xNodo.iDato,xNodo.pSiguiente,xNodo.pAnterior);

    // Eliminamos un Elemento
    xNodo = FnNodoListaDobleEliminaFinal(&pCabeza,&pCola);

    // Desplegamos Información del Nodo Eliminado
    printf("Información del Nodo:%d Sigte:%p Anter:%p\n",xNodo.iDato,xNodo.pSiguiente,xNodo.pAnterior);

    // Eliminamos un Elemento
    xNodo = FnNodoListaDobleEliminaFinal(&pCabeza,&pCola);

    // Desplegamos Información del Nodo Eliminado
    printf("Información del Nodo:%d Sigte:%p Anter:%p\n",xNodo.iDato,xNodo.pSiguiente,xNodo.pAnterior);

    // Despliega la Lista en Orden Normal
    SbListaDobleDespliegaFull(pCabeza,pCola,TRUE);

    // Inserta un Elemento al Final
    SbListaDobleInsertarFinal(&pCabeza,&pCola,99);

    // Despliega la Lista en Orden Normal
    SbListaDobleDespliegaFull(pCabeza,pCola,TRUE);

    // Inserta un Elemento al Final
    SbListaDobleInsertarFinal(&pCabeza,&pCola,98);

    // Inserta un Elemento al Final
    SbListaDobleInsertarFinal(&pCabeza,&pCola,97);

    // Inserta un Elemento al Final
    SbListaDobleInsertarFinal(&pCabeza,&pCola,96);

    // Despliega la Lista en Orden Normal
    SbListaDobleDespliegaFull(pCabeza,pCola,TRUE);

    // Mensaje de Acceso a Nodos desde Cabeza
    printf("Accediendo todos los Nodos desde Cabeza \n");

    // Imprimiendo desde Cabeza el Último Elemento
    printf("%d \n",pCabeza->iDato);
    printf("%d \n",pCabeza->pSiguiente->iDato);
    printf("%d \n",pCabeza->pSiguiente->pSiguiente->iDato);
    printf("%d \n",pCabeza->pSiguiente->pSiguiente->pSiguiente->iDato);
    printf("%d \n",pCabeza->pSiguiente->pSiguiente->pSiguiente->pAnterior->iDato);
    printf("%d \n",pCabeza->pSiguiente->pSiguiente->pSiguiente->pAnterior->pAnterior->iDato);
    printf("%d \n",pCabeza->pSiguiente->pSiguiente->pSiguiente->pAnterior->pAnterior->pAnterior->iDato);
    //printf("%d \n",pCabeza->pSiguiente->pSiguiente->pSiguiente->pAnterior->pAnterior->pAnterior->pAnterior->iDato); // Esto ya es error

    // Finaliza la aplicación retornando 0
    return 0;
}




