/*
Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE
www.jaorsoftware.cu.cc

Clase 27- Árboles

Hasta ahora, las Estructuras de Datos que hemos estudiado eran de tipo lineal,
es decir, que existía una relación de Anterior y Siguiente entre los elementos
que la componían, que desde cierto punto de vista, formaban una "linea".

Ahora vamos a estudiar una Estructura de Datos más compleja:los Árboles.

Un Árbol es una Estructura No lineal en la que cada Nodo puede apuntar a
uno o varios Nodos. Gŕaficamente

GRAFO.
                    --------------------------|Nodo 1|---------------------------
                    |                             |                             |
        -------|Nodo 11|-----                 |Nodo 12|             --------|Nodo 13|-------------
        |                   |                     |                 |           |                |
   ---|Nodo 111|---    |Nodo 112|        ---|Nodo  121|---    |Nodo 131|   |Nodo 132|  --- |Nodo 133|---
   |              |                      |               |                             |               |
|Nodo 1111|  |Nodo 1112|            |Nodo 1211|     |Nodo 1222|                   |Nodo 1331|     |Nodo 1332|


DIAGRAMA ENCOLUMNADO
1
  11
     111
         1111
         1112
     112
  12
     121
         1211
         1212
  13
     131
     132
     133
         1331
         1332

Antes de entrar a aspectos de programación, debemos de conocer varios
conceptos con respecto a un Árbol.

NODO PADRE.
Es aquel Nodo que tiene Nodos Hijos a los que apunta.
En el ejemplo, el Nodo 1 es el Nodo Padre del Nodo 11,12, y 13; los
cuales son sus hijos.

NODO HIJO.
Es aquel Nodo que tiene un Nodo Padre.
En el ejemplo, Los Nodos 11,12 y 13 son Hijos del Nodo 1.

NODOS HERMANOS.
Son aquellos Nodos tienen el mismo Padre.

NODO ANCESTRO Y DESCENDIENTE.
Si existe un camino,del Nodo A al nodo B,entonces A es un ancestro de
B y B es un descendiente de A. En el ejemplo:

a) El 1 es Ancestro de todos; y todos son sus Descendientes.
b) El 11 es Ancestro del 111,112,1111 y 1112; y estos a su vez son
   Descendientes de 11.

Los Árboles tienen una característica muy importante. Cada nodo sólo
puede ser apuntado por otro nodo, es decir, cada nodo sólo tiene
un Nodo Padre.

Ahora veamos algunos conceptos en cuanto a la posición de un Nodo
dentro del Árbol:

NODO RAÍZ.
Es el Nodo que no tiene Padre; que no tiene Ancestros; es el nodo inicial
a partir del cual se construye el árbol. En el caso del ejemplo, el Nodo 1.

NODO HOJA.
Es el Nodo que no tiene Hijos; no tiene Descendientes.
En el ejemplo: 112,131,132,1111,1112,1221,1222,1331 y 1332.

Nota. Cuando un Árbol tiene un solo nodo; este único Nodo es RAÍZ, pero
tambien es HOJA.

NODO RAMA.(Nodos Internos)
Son los que tienen Nodo Padre y tienen Nodos Hijos; es decir que no
son RAIZ y no son HOJA. En el ejemplo: 11,12,13,111,121 y 133.

Ahora veremos otros conceptos de Árboles con respecto a su tamaño.

ORDEN DEL ÁRBOL.
Es el número potencial de Hijos que puede tener cada Nodo del Árbol.
De este modo, diremos que un Árbol en el que cada Nodo puede apuntar a
otros 2; es de orden 2; si puede apuntar a 3; será de orden 3; y así
sucesivamente.

En el caso de nuestro ejemplo, podemos SUPONER, que el orden del árbol
es de 3; ya que hay nodos que tienen 3 hijos.

GRADO DEL ÁRBOL.
El Grado de un Árbol, lo determina el Nodo que tenga mas Hijos.
En nuestro ejemplo, el grado es de 3; ya que es el número mayor de hijos 
que tiene un nodo.

De lo anterior concluimos que:

a) El ORDEN de un Árbol, no necesariamente indica el GRADO del mismo; ya que el
hecho de que un Nodo PUEDA tener 3 hijos; no necesariamente indica que los tenga.

b) El GRADO de un Árbol, puede ser menor o igual que el ORDEN; pero no mayor.

GRADO DE UN NODO.
El Número de Hijos que tiene

NIVEL DE UN NODO.
Se define como la Distancia en Nodos; que existe entre un Nodo y el Nodo Raiz.
El nivel del Nodo Raíz es cero y el de sus hijos uno; y así sucesivamente.
En el ejemplo, el nodo 111, tiene nivel 2, y el nodo 1111 tiene nivel 3.

Nota. Existen algunos textos que mencionan que el Nodo Raíz tiene Nivel 1; así que
simplemente hay que decidir como se quiere manejar este nivel.

ALTURA DEL ÁRBOL.(PROFUNDIDAD)
La Altura de un Árbol se define como el nivel del nodo de mayor nivel.
El Árbol del ejemplo tiene altura 3.

ALTURA DE UN NODO.(PROFUNDIDAD)
La Altura de un Nodo se define como el nivel del Nodo de mayor nivel de sus
Descendientes.

Por ejemplo:
a) La Altura de  11 es 2
b) La Altura de 121 es 1
c) La Altura de 131 es 0.

*/
#include <stdlib.h>
#include <stdio.h>

#define TRUE  1
#define FALSE 0

// Función Principal
int main()
{
    // Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 27 - Árboles \n\n");



    // Finaliza la aplicación retornando 0
    return 0;
}

