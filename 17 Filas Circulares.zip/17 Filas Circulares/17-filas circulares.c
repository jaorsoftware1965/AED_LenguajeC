/*

Curso de Algoritmos y Estructuras de Datos en C
Autor: JAOR
Derechos Reservados: JAORSOFTWARE
www.jaorsoftware.com

Clase 17 - Filas Circulares

En esta clase continuaremos viendo la estructura de datos
Fila. Para esta ocasión veremos lo que es una Fila Circular
Implementada con un Vector.

Una Fila Circular es aquella en la cual el Arreglo se maneja
como una estructura en donde al llegar a la parte final del vector
se puede continuar insertando elementos; al principio del vector
si es que estos se encuentra vacíos.

Para la Fila Circular, los Elementos se sacan de la fila, de igual
forma que en el segundo Método estudiado, simplemente moviendo
el índice del Frente a la derecha; es decir incrementandolo el 1.
Ejemplo:

Suponga la siguiente Fila LLena:

          0  1  2   3  4
Fila  ->| 5| 6|17 |12|23 |

Frente-> 0
Final -> 4

Si sacamos 3 elementos, la fila quedaría asi:

          0  1  2   3  4
Fila  ->|  |  |  | 12|23|

Frente-> 3
Final -> 4

En esta circunstancias en donde se demuestra el uso de
la Fila Circular. Si agregamos un Elemento; debido a
que Final está en la posición 4; entonces agregaremos el
elemento en el inicio del Vector; obviamente porque
sabemos que la Fila no está llena y que esta posición
está vacía. Veamos si entra el 34

          0  1  2   3  4
Fila  ->|34|  |  | 12|23|

Frente-> 3
Final -> 0

Cuando realizamos esta inserción; resulta que Final ya
no es mayor que frente; situación que NO ERA POSIBLE en
los anteriores métodos. Una vez que se ha ocupado la
primera posición; la forma de ingresar el siguiente
elemento, sigue siendo la misma; incrementar Final y
asignarlo a esa posición; obviamente mientras que la
Fila no esté llena. Veamos insertar el 45

          0  1  2   3  4
Fila  ->|34|45|  | 12|23|

Frente-> 3
Final -> 1

Con este tipo de manejo de la Fila, el cálculo de los
elementos en la Fila varía y se realiza de las siguientes
2 formas.

ELEMENTOS EN LA FILA
A) Cuando el Apuntador Final es mayor o igual que el Frente
   es el calculo del método 2:Final-Frente +1
   Ejemplo:

    0   1  2   3   4
   |  |  |12| 34 |54

   Final = 4
   Frente = 2
   Elementos = 4-2 +1 = 3


B) Cuando el Apuntador Final es menor que el Frente; el
   cálculo es: FILA_TAMAÑO-Frente + Final +1

     0  1  2   3   4
   |75|  |12| 34| 54

   Elementos = 5 - 2 + 0 + 1 = 4


ELIMINAR UN ELEMENTO DE LA FILA

Eliminar un elemento del Frente de la Fila, sigue siendo
la misma circunstancia que en el Método 2; solo que cuando
se elimina un elemento de la posición final del vector;
entonces Frente pasa a ser 0; obviamente si es que la Fila
tiene mas de un Elemento. Veamos eliminar un elemento de
la Fila hasta que se presente la circunstancia

          0  1  2   3  4
Fila  ->|34|45|  | 12|23|

Frente-> 3
Final -> 1

Sacamos el 12

          0  1  2   3  4
Fila  ->|34|45|  |   |23|

Frente-> 4
Final -> 1

Sacamos el 23

          0  1  2   3  4
Fila  ->|34|45|  |   |  |

Frente-> 0
Final -> 1

Recordemos que cuando Frente y Final son el mismo, es
decir; que hay solo un Elemento; entonces si este se
elimina; Final y Frente pasan a ser -1.

De todos las Funciones vistas en el Método II, las que
se tendrán implementar para la Fila Circular son los
siguientes:

Elementos. Calcular el Número de Elementos de la Fila
Filallena. Saber si la Fila está llena.
Insertar . Insertar un Elemento
Eliminar . Eliminar un Elemento

*/
// Librerias
#include "stdio.h"

// Constantes
#define TRUE  1
#define FALSE 0

// Definimos el Tamaño de la Fila
#define FILA_TAMANIO 5

// Definimos la estructura de la Fila
typedef struct stcFila
{
    // Variable para manejar el frente y final de la Fila
    int  iFilaFrente;
    int  iFilaFinal;

    // El Arreglo para la Fila
    int arrIntFila[FILA_TAMANIO];

}fila;


// Implementamos Inicializar la Fila
void SbFilaInicializa(fila *pFila)
{
   // Para Inicializar la Fila basta con poner el frente y final a -1
   // Ya que el primer elemento ocupa la posición 0
   pFila->iFilaFrente=-1;
   pFila->iFilaFinal =-1;

   // Ciclo para llenar con 0's la fila
   for (int i=0; i<FILA_TAMANIO; i++)   
       pFila->arrIntFila[i]=0;

   // Desplegamos Mensaje
   printf("Fila Inicializada ...\n");
}

// Implementamos Verificar si la Fila está vacía
int FnIntFilaVacia(fila *pFila)
{
    if (pFila->iFilaFinal==-1)
        return TRUE;
    else
        return FALSE;
}

// Implementamos para Obtener el Elemento del Frente de la Fila
int FnIntFilaFrente(fila *pFila)
{
    // Verificamos si la Fila está vacía
    if (!FnIntFilaVacia(pFila))
    {
       return(pFila->arrIntFila[pFila->iFilaFrente]);
    }
    else
    {
       printf("La Fila está vacia; no hay frente\n");
       return (-1);
    }           
}

// Implementamos para Obtener el Elemento del Final de la Fila
int FnIntFilaFinal(fila *pFila)
{
    // Verificamos si la Fila está vacía
    if (FnIntFilaVacia(pFila))
    {
       printf("La Fila está vacia; no hay final\n");
       return (-1);
    }
    else
       return(pFila->arrIntFila[pFila->iFilaFinal]);
}



// Implementamos Obtener cuantos elementos tiene la Fila Circular
int FnIntFilaCircularElementos(fila *pFila)
{
    // Verifica si la Fila está vacía
    if (FnIntFilaVacia(pFila))
        return 0;
    else
       // Verifica si final es mayor o igual que frente
       if (pFila->iFilaFinal >= pFila->iFilaFrente)
          // Retorna en base al Final - Frente + 1
          return pFila->iFilaFinal - pFila->iFilaFrente + 1;
       else
          // Retorna en base al Tamaño - Frente + Final + 1
          return FILA_TAMANIO - pFila->iFilaFrente + pFila->iFilaFinal + 1;
}

// Implementamos Verificar si la Fila está llena
int FnIntFilaCircularLlena(fila *pFila)
{
    if (FnIntFilaCircularElementos(pFila)==FILA_TAMANIO)
       return TRUE;
    else
       return FALSE;
}


// Implementamos Insertar un Elemento en la Fila Circular
void SbFilaCircularInsertar(fila *pFila,int iElemento)
{
    // Verificamos si la Fila está llena
    if (FnIntFilaCircularLlena(pFila))
       printf("La Fila está llena y no es posible agregar el elemento:%d\n",iElemento);
    else
    {
       // Verificamos si la Fila está vacia
       if (pFila->iFilaFinal==-1)
       {
           // Coloca el Frente en 0
           pFila->iFilaFrente=0;

           // Coloca el Final en 0 tambien
           pFila->arrIntFila[++pFila->iFilaFinal]=iElemento;
       }
       else
           // Verificamos que esté ocupado el final
           if (pFila->iFilaFinal +1 == FILA_TAMANIO)
           {
                // Final va a 0
                pFila->iFilaFinal=0;

                // Asigna el Elemento
                pFila->arrIntFila[pFila->iFilaFinal]=iElemento;

           }
           else
             // Si no está en el final, incrementamos FInal y asignamos
             pFila->arrIntFila[++pFila->iFilaFinal]=iElemento;
    }
}


// Implementamos Eliminar un Elemento de la Fila Circular
int FnIntFilaCircularEliminar(fila *pFila)
{
    // El valor a devolver
    int iResult;

    // Verificamos si la Fila está vacía
    if (FnIntFilaVacia(pFila))
    {
       printf("La Fila está vacía no es posible sacar elementos\n");
       iResult=-1;
    }
    else
    {
       // Obtiene el Elemento a Devolver y le coloca 0 para indicar vacio
       iResult = pFila->arrIntFila[pFila->iFilaFrente];
       pFila->arrIntFila[pFila->iFilaFrente] = 0;

       // Verifica si solo hay un elemento
       if (pFila->iFilaFinal == pFila->iFilaFrente)
       {
          // Inicializa
          pFila->iFilaFinal=-1;
          pFila->iFilaFrente=-1;
       }
       else
          // Verifica si el frente está al fina final para mandarlo a 0
          if (pFila->iFilaFrente+1==FILA_TAMANIO)
             // El frente es ahora 0
             pFila->iFilaFrente=0;
          else
            // Mueve el referenciador del Frente
            pFila->iFilaFrente++;
    }

    // Devuelve el resultado
    return(iResult);

}

// Despliega el Vector de la Fila
void SbFilaCirculaDespliegaVector(fila *pFila)
{
   char iIndice;

   printf("Fila->| ");
   for (iIndice=0; iIndice<FILA_TAMANIO;iIndice++)
        printf("%d | ",pFila->arrIntFila[iIndice]);
   printf("\n\n");

}

void fnDespliegaListaCircular(fila *pFila)
{
   if (FnIntFilaVacia(pFila))
      printf("La Fila está vacia \n");
   else
   {
      printf("Fila->|");
      if (pFila->iFilaFrente <= pFila->iFilaFinal)
      {
         // Ciclo para desplegar
         for (int i=pFila->iFilaFrente; i<=pFila->iFilaFinal; i++)
            printf(" %d |",pFila->arrIntFila[i]);
      }
      else
      {
         for (int i=pFila->iFilaFrente; i<= FILA_TAMANIO-1; i++)
            printf(" %d |",pFila->arrIntFila[i]);        
         for (int i=0; i<=pFila->iFilaFinal; i++)      
            printf(" %d |",pFila->arrIntFila[i]);        
      }
   }   
   
}

int main()
{
    // Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 17 - Filas Circulares \n\n");

    // Declara la variable de la Fila
    fila xFila;

    // Coloca -1 en los valores de los elementos
    xFila.arrIntFila[0]=0;
    xFila.arrIntFila[1]=0;
    xFila.arrIntFila[2]=0;
    xFila.arrIntFila[3]=0;
    xFila.arrIntFila[4]=0;

    // Inicializa la Fila
    SbFilaInicializa(&xFila);

    // Verificamos Datos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaCircularElementos(&xFila));
    printf("El Frente de la Fila : %d en pos:%d\n" ,FnIntFilaFrente(&xFila),xFila.iFilaFrente);
    printf("El Final  de la Fila : %d en pos:%d\n"  ,FnIntFilaFinal(&xFila),xFila.iFilaFinal);
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n\n",FnIntFilaCircularLlena(&xFila)? "True" : "False" );
    SbFilaCirculaDespliegaVector(&xFila);
    fnDespliegaListaCircular(&xFila);

    // Agregamos un Elemento a la Fila
    printf("Agregamos el Elemento 10 \n");
    SbFilaCircularInsertar(&xFila,10);
    fnDespliegaListaCircular(&xFila);

    // Verificamos Datos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaCircularElementos(&xFila));
    printf("El Frente de la Fila : %d en pos:%d\n" ,FnIntFilaFrente(&xFila),xFila.iFilaFrente);
    printf("El Final  de la Fila : %d en pos:%d\n"  ,FnIntFilaFinal(&xFila),xFila.iFilaFinal);
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n",FnIntFilaCircularLlena(&xFila)? "True" : "False" );
    SbFilaCirculaDespliegaVector(&xFila);
    fnDespliegaListaCircular(&xFila);


    // Eliminamos un Elemento a la Fila
    printf("Eliminamos un Elemento de la Fila %d \n",FnIntFilaCircularEliminar(&xFila));

    // Verificamos Datos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaCircularElementos(&xFila));
    printf("El Frente de la Fila : %d en pos:%d\n" ,FnIntFilaFrente(&xFila),xFila.iFilaFrente);
    printf("El Final  de la Fila : %d en pos:%d\n"  ,FnIntFilaFinal(&xFila),xFila.iFilaFinal);
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n",FnIntFilaCircularLlena(&xFila)? "True" : "False" );
    SbFilaCirculaDespliegaVector(&xFila);
    fnDespliegaListaCircular(&xFila);

    // Agregamos un Elemento a la Fila
    printf("Agregamos el Elemento 13 \n");
    SbFilaCircularInsertar(&xFila,13);
    fnDespliegaListaCircular(&xFila);

    // Verificamos Datos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaCircularElementos(&xFila));
    printf("El Frente de la Fila : %d en pos:%d\n" ,FnIntFilaFrente(&xFila),xFila.iFilaFrente);
    printf("El Final  de la Fila : %d en pos:%d\n"  ,FnIntFilaFinal(&xFila),xFila.iFilaFinal);
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n",FnIntFilaCircularLlena(&xFila)? "True" : "False" );
    SbFilaCirculaDespliegaVector(&xFila);
    fnDespliegaListaCircular(&xFila);


    // Agregamos un Elemento a la Fila
    printf("Agregamos 5 Elementos 13,24,35,47,78 \n");
    SbFilaCircularInsertar(&xFila,13);
    SbFilaCircularInsertar(&xFila,24);
    SbFilaCircularInsertar(&xFila,35);
    SbFilaCircularInsertar(&xFila,47);
    SbFilaCircularInsertar(&xFila,78);

    // Verificamos Datos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaCircularElementos(&xFila));
    printf("El Frente de la Fila : %d en pos:%d\n" ,FnIntFilaFrente(&xFila),xFila.iFilaFrente);
    printf("El Final  de la Fila : %d en pos:%d\n"  ,FnIntFilaFinal(&xFila),xFila.iFilaFinal);
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n",FnIntFilaCircularLlena(&xFila)? "True" : "False" );
    SbFilaCirculaDespliegaVector(&xFila);
    fnDespliegaListaCircular(&xFila);

    // Eliminamos un Elemento a la Fila
    printf("Eliminamos un Elemento de la Fila %d \n",FnIntFilaCircularEliminar(&xFila));

    // Verificamos Datos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaCircularElementos(&xFila));
    printf("El Frente de la Fila : %d en pos:%d\n" ,FnIntFilaFrente(&xFila),xFila.iFilaFrente);
    printf("El Final  de la Fila : %d en pos:%d\n"  ,FnIntFilaFinal(&xFila),xFila.iFilaFinal);
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n",FnIntFilaCircularLlena(&xFila)? "True" : "False" );
    SbFilaCirculaDespliegaVector(&xFila);
    fnDespliegaListaCircular(&xFila);

    printf("Agregamos 2 Elementos: 78 y 89\n");
    SbFilaCircularInsertar(&xFila,78);
    SbFilaCircularInsertar(&xFila,89);

    // Verificamos Datos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaCircularElementos(&xFila));
    printf("El Frente de la Fila : %d en pos:%d\n" ,FnIntFilaFrente(&xFila),xFila.iFilaFrente);
    printf("El Final  de la Fila : %d en pos:%d\n"  ,FnIntFilaFinal(&xFila),xFila.iFilaFinal);
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n",FnIntFilaCircularLlena(&xFila)? "True" : "False" );
    SbFilaCirculaDespliegaVector(&xFila);
    fnDespliegaListaCircular(&xFila);

    // Eliminamos un Elemento a la Fila
    printf("Eliminamos un Elemento de la Fila %d \n",FnIntFilaCircularEliminar(&xFila));

    // Verificamos Datos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaCircularElementos(&xFila));
    printf("El Frente de la Fila : %d en pos:%d\n" ,FnIntFilaFrente(&xFila),xFila.iFilaFrente);
    printf("El Final  de la Fila : %d en pos:%d\n"  ,FnIntFilaFinal(&xFila),xFila.iFilaFinal);
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n",FnIntFilaCircularLlena(&xFila)? "True" : "False" );
    SbFilaCirculaDespliegaVector(&xFila);
    fnDespliegaListaCircular(&xFila);

    printf("Agregamos 2 Elementos: 89 y 96\n");
    SbFilaCircularInsertar(&xFila,89);
    SbFilaCircularInsertar(&xFila,96);

    // Verificamos Datos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaCircularElementos(&xFila));
    printf("El Frente de la Fila : %d en pos:%d\n" ,FnIntFilaFrente(&xFila),xFila.iFilaFrente);
    printf("El Final  de la Fila : %d en pos:%d\n"  ,FnIntFilaFinal(&xFila),xFila.iFilaFinal);
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n",FnIntFilaCircularLlena(&xFila)? "True" : "False" );
    SbFilaCirculaDespliegaVector(&xFila);
    fnDespliegaListaCircular(&xFila);

    // Eliminamos un Elemento a la Fila
    printf("Eliminamos un Elemento de la Fila %d \n",FnIntFilaCircularEliminar(&xFila));

    // Eliminamos un Elemento a la Fila
    printf("Eliminamos un Elemento de la Fila %d \n",FnIntFilaCircularEliminar(&xFila));

    // Eliminamos un Elemento a la Fila
    printf("Eliminamos un Elemento de la Fila %d \n",FnIntFilaCircularEliminar(&xFila));

    // Verificamos Datos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaCircularElementos(&xFila));
    printf("El Frente de la Fila : %d en pos:%d\n" ,FnIntFilaFrente(&xFila),xFila.iFilaFrente);
    printf("El Final  de la Fila : %d en pos:%d\n"  ,FnIntFilaFinal(&xFila),xFila.iFilaFinal);
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n",FnIntFilaCircularLlena(&xFila)? "True" : "False" );
    SbFilaCirculaDespliegaVector(&xFila);
    fnDespliegaListaCircular(&xFila);

    printf("Agregamos el Elementos 96\n");
    SbFilaCircularInsertar(&xFila,96);
    fnDespliegaListaCircular(&xFila);

    // Verificamos Datos en la Fila
    printf("Elementos en la Fila : %d\n"  ,FnIntFilaCircularElementos(&xFila));
    printf("El Frente de la Fila : %d en pos:%d\n" ,FnIntFilaFrente(&xFila),xFila.iFilaFrente);
    printf("El Final  de la Fila : %d en pos:%d\n"  ,FnIntFilaFinal(&xFila),xFila.iFilaFinal);
    printf("La Fila está vacía   : %s\n"  ,FnIntFilaVacia(&xFila)? "True" : "False" );
    printf("La Fila está llena   : %s\n",FnIntFilaCircularLlena(&xFila)? "True" : "False" );
    SbFilaCirculaDespliegaVector(&xFila);
    fnDespliegaListaCircular(&xFila);

    // Finaliza
    return 0;

}



